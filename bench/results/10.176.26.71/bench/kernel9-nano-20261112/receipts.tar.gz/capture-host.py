from pathlib import Path
import hashlib,json,subprocess,sys
base=Path(__file__).parent;out=base/sys.argv[1];out.mkdir()
raw=(base/'capture-host-read.py').read_bytes()
argv=['ssh','-T','-p','22','-o','BatchMode=yes','-o','ConnectTimeout=10','eric@10.176.26.71','sudo','-n','python3','-B','-']
(out/'command.json').write_text(json.dumps({'argv':argv,'stdin_sha256':hashlib.sha256(raw).hexdigest()},indent=2)+'\n')
with (out/'host.json').open('xb') as f,(out/'stderr.log').open('xb') as e:
 p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=f,stderr=e,start_new_session=True);p.stdin.write(raw);p.stdin.close()
 try:code=p.wait(timeout=45)
 except subprocess.TimeoutExpired:code=None
assert code==0,(code,p.pid,(out/'stderr.log').read_text())
v=json.loads((out/'host.json').read_text());assert v['pins_verified'] and v['frequency_verified']
print(json.dumps({'pins_verified':v['pins_verified'],'frequency_verified':v['frequency_verified'],'performance_accepted':v['performance_accepted'],'qemu_tasks':len(v['qemu'][0]['tasks']),'host_sha256':hashlib.sha256((out/'host.json').read_bytes()).hexdigest()}))
