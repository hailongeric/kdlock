from pathlib import Path
import sys,tarfile
root=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/nano-kernel9-20261112-02')
assert not Path('/dev/kd_rwlock_bench').exists() and not Path('/dev/kd_nano_source').exists()
assert {x.split()[0] for x in Path('/proc/modules').read_text().splitlines()}<={'nls_iso8859_1'}
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='ff9d44b5-bcfc-4ec0-ad0c-2e8798bc8f0c'
paths=[p for p in (root/'build').rglob('*') if p.is_file() and (p.suffix in ('.ko','.mod','.o','.c') or p.name=='Module.symvers')]
assert len(paths)>16 and sum(p.stat().st_size for p in paths)<64*1024**2
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as t:
 for p in sorted(paths):
  assert not p.is_symlink()
  t.add(p,arcname=str(p.relative_to(root)),recursive=False)
