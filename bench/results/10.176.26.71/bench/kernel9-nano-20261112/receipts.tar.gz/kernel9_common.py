"""Exact kernel9 identity and idle checks for the affected rwsem fixture."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import os
import runpy
import struct
import time

BASE = Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01')
ROOT = BASE / 'private-rwsem-regression-02'
BUILD = BASE / 'build'
RELEASE = '7.0.0-38-kdrebuild9'
BOOT = 'ff9d44b5-bcfc-4ec0-ad0c-2e8798bc8f0c'
BUILD_ID = '8198ffae09db584dce9b71d92b5743a4146ba80a'
CORE = '6e486ecec398111fb5d5e30ffc76495f32f557b7'
MANIFEST_SHA = 'ea8c7cc7b502ec250c0933d3c72ebdef93b89a30a2fc6c9389c32f9e85ccb45e'

def need(value, message):
    if not value:
        raise RuntimeError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def checked(path, expected):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path and path.is_file() and
         sha(path) == expected, 'exact input differs: ' + str(path))
    return json.loads(path.read_text())

def save(path, value):
    path = Path(path)
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    os.fsync(fd); os.close(fd)

def available(path):
    value = os.statvfs(path)
    return value.f_bavail * value.f_frsize

def running_id():
    data = Path('/sys/kernel/notes').read_bytes()
    need(len(data) < 1024**2, 'kernel note bound')
    offset, ids = 0, []
    while offset < len(data):
        need(offset + 12 <= len(data), 'truncated kernel note')
        names, size, kind = struct.unpack_from('<III', data, offset)
        start = offset + 12
        desc = start + ((names + 3) & ~3)
        end = desc + ((size + 3) & ~3)
        need(end <= len(data), 'kernel note extent')
        if kind == 3 and data[start:start+names] == b'GNU\0':
            ids.append(data[desc:desc+size].hex())
        offset = end
    need(ids == [BUILD_ID], 'actual running Build ID differs')
    return ids[0]

def idle(taint):
    value = {'boot': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
             'release': os.uname().release,
             'taint': int(Path('/proc/sys/kernel/tainted').read_text()),
             'build_id': running_id(), 'busy': [], 'dthreads': [],
             'modules': Path('/proc/modules').read_text(), 'unix': time.time()}
    need(value['boot'] == BOOT and value['release'] == RELEASE and value['taint'] == taint,
         'exact kernel9 boot/release/taint differs')
    need({line.split()[0] for line in value['modules'].splitlines()} <= {'nls_iso8859_1'},
         'unexpected module remains')
    need(not any('fixture' in p.name or p.name.startswith(('kd_mmap_api', 'kd_rwsem_api'))
                 for p in Path('/dev').iterdir()), 'fixture/API device remains')
    commands = {'make', 'gmake', 'cc1', 'cc1plus', 'gcc', 'gcc-15', 'clang', 'ld',
                'ld.bfd', 'as', 'objtool', 'fstrim', 'depmod', 'insmod', 'rmmod',
                'mmap-userspace', 'perf'}
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or int(process.name) == os.getpid():
            continue
        try:
            comm = (process / 'comm').read_text().strip()
            argv = [x.decode(errors='replace') for x in (process / 'cmdline').read_bytes().split(b'\0') if x]
            if (comm in commands or any('/tests/kernel/' in x for x in argv) or
                    comm.startswith(('kd-fixture/', 'kd-scene/', 'kd-reader/', 'kd-killable/'))):
                value['busy'].append({'pid': int(process.name), 'comm': comm, 'argv': argv})
            for task in (process / 'task').iterdir():
                if '\nState:\tD ' in '\n' + (task / 'status').read_text():
                    value['dthreads'].append({'pid': int(process.name), 'tid': int(task.name),
                        'comm': (task / 'comm').read_text().strip(), 'wchan': (task / 'wchan').read_text().strip()})
        except (FileNotFoundError, ProcessLookupError):
            pass
    need(not value['busy'] and not value['dthreads'], 'idle not established: ' + json.dumps(value))
    need(available('/') >= 1024**3 and available(BASE) >= 4*1024**3, 'root/output reserve')
    return value

def kernel_inputs(config):
    driver = Path('/mnt/kdlock-builds2/kdlock-main-kernel9-input-6e486ece-01/build.py')
    need(sha(driver) == '0535aa78d56e019b11de988e217416110176645fb9f25fce4dca9427881e0d57',
         'saved build checker changed')
    native = runpy.run_path(str(driver))
    native['environment']()
    plan = checked(driver.parent/'plan.json', '0df23f4f69069b9b8dfcff3c58b69df9b4b6904f7e2abff3073ee9dd71215408')
    built = checked(BASE/'receipts/build-01/result.json', 'c931ed00177c974ff77a0d9d506cb0feceb443cef9c2590f2723e95f2aba637d')
    final = checked(BASE/'receipts/build-01/final-identity.json', 'efa315fbb8a606f29cd357e949ccebd297a1b589956cd87d53e9c206b3c085d9')
    need(built['status'] == 'KERNEL9_BUILD_AND_LINKED_IDENTITY_COMPLETE' and
         built['selected_commit'] == CORE and final['build_id'] == BUILD_ID, 'built core identity')
    native['pins'](BUILD, {name: row['sha256'] for name, row in final['files'].items()})
    need(native['candidate_pins'](plan, BASE/'source') == built['source_after'] and
         native['protected'](plan) == built['protected_after'], 'core/source/protected identities differ')
    post = checked(BASE/'receipts/postboot-kdrebuild9-cohort-01/result.json', config['postboot_sha256'])
    proof = checked(BASE/'receipts/postboot-kdrebuild9-cohort-01/gs-proof.json', config['gs_proof_sha256'])
    need(post['phase'] == 'POSTBOOT_IDENTITY_VERIFIED' and post['boot_id'] == BOOT and
         post['running_build_id'] == BUILD_ID and proof['verified_for_running_kernel'] is True and
         proof['boot_id'] == BOOT and proof['build_id'] == BUILD_ID, 'postboot and GS receipts differ')
    return native, plan, built, final, proof

def source_inputs():
    files = checked(ROOT/'source-sha256.json', MANIFEST_SHA)
    need(len(files) == 143, 'exact 143 source members required')
    found = {}
    for path in sorted((ROOT/'input').rglob('*')):
        need(not path.is_symlink(), 'source link')
        if path.is_file():
            found[str(path.relative_to(ROOT/'input'))] = {
                'bytes': path.stat().st_size, 'sha256': sha(path)}
        else:
            need(path.is_dir(), 'nonregular source member')
    need(found == files, 'frozen source member/hash differs')
    return files

def recovery(native, plan, path, expected):
    return native['recovery_check'](SimpleNamespace(recovery_json=str(path), recovery_sha256=expected), plan)
