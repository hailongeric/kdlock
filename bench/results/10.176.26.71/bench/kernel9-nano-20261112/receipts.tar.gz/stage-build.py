from pathlib import Path
import base64,gzip,hashlib,json,subprocess
base=Path(__file__).parent;out=base/'stage-build';out.mkdir()
files={}
for name,path in [('source.tar.gz',base/'source.tar'),('source-sha256.json',base/'source-sha256.json'),('source-state.json',base/'source-state.json'),('kernel9_common.py',base/'kernel9_common.py'),('kernel-config.json',base/'kernel-config.json'),('recovery.json',base/'recovery-build/recovery.json')]:
 raw=path.read_bytes()
 if name.endswith('.gz'):raw=gzip.compress(raw,mtime=0)
 files[name]={'sha256':hashlib.sha256(raw).hexdigest(),'data':base64.b64encode(raw).decode()}
payload=base64.b64encode(json.dumps(files).encode()).decode()
script=r'''from pathlib import Path,PurePosixPath
import base64,gzip,hashlib,io,json,os,subprocess,sys,tarfile,time
files=json.loads(base64.b64decode(PAYLOAD));data={}
for name,row in files.items():
 raw=base64.b64decode(row['data']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];data[name]=raw
ns={};exec(compile(data['kernel9_common.py'],'kernel9_common.py','exec'),ns)
before=ns['idle'](4096);config=json.loads(data['kernel-config.json'])
native,plan,built,final,proof=ns['kernel_inputs'](config)
root=ns['BASE']/'nano-kernel9-20261112-02';assert not root.exists();root.mkdir(mode=0o700)
control=root/'control';control.mkdir();source=root/'input';source.mkdir()
for name in ('kernel9_common.py','kernel-config.json','recovery.json','source-state.json','source-sha256.json'):
 with (control/name).open('xb') as f:f.write(data[name]);f.flush();os.fsync(f.fileno())
 (control/name).chmod(0o444)
recovery=ns['recovery'](native,plan,control/'recovery.json',files['recovery.json']['sha256'])
expected=json.loads(data['source-sha256.json']);seen=set()
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(data['source.tar.gz'])),mode='r:') as archive:
 for member in archive:
  name=member.name;rel=PurePosixPath(name)
  assert member.isfile() and not rel.is_absolute() and '..' not in rel.parts and name==str(rel) and name in expected and name not in seen
  raw=archive.extractfile(member).read();assert len(raw)==expected[name]['bytes'] and hashlib.sha256(raw).hexdigest()==expected[name]['sha256']
  p=source/name;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  p.chmod(0o444);seen.add(name)
assert seen==set(expected)
meta={'status':'NANO_SOURCE_STAGED','source_manifest_sha256':files['source-sha256.json']['sha256'],'files':len(seen),'before':before,'recovery':recovery,'build_id':final['build_id']}
ns['save'](root/'stage.json',meta)
python='/mnt/kdlock-builds/venvs/kdlock-translation-7.0-20261027/bin/python3'
assert ns['sha'](Path(python).resolve())=='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
argv=[python,'-B',str(source/'bench/nano/build.py'),'--repo',str(source),'--kernel-source',str(ns['BASE']/'source'),'--kernel-output',str(ns['BUILD']),'--output',str(root/'build')]
with (root/'build.stdout').open('xb') as stdout,(root/'build.stderr').open('xb') as stderr:
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=child.wait(timeout=900)
 except subprocess.TimeoutExpired:code=None
reply={'returncode':code,'pid':child.pid,'argv':argv,'files':{}}
if code is not None:
 after=ns['idle'](4096);ns['kernel_inputs'](config)
 actual={str(p.relative_to(source)):{'bytes':p.stat().st_size,'sha256':ns['sha'](p)} for p in source.rglob('*') if p.is_file()}
 assert actual==expected
 ns['save'](root/'build-final.json',{'returncode':code,'after':after,'source_preserved':True,'kernel_preserved':True})
 paths=[root/'stage.json',root/'build-final.json',root/'build.stdout',root/'build.stderr']
 if (root/'build').exists():paths += [p for p in (root/'build').iterdir() if p.is_file() and p.suffix in ('.json','.log')]
 total=0
 for p in paths:
  raw=p.read_bytes();total+=len(raw);assert total<64*1024**2
  reply['files'][str(p.relative_to(root))]={'data':base64.b64encode(raw).decode(),'sha256':hashlib.sha256(raw).hexdigest()}
print(json.dumps(reply))
'''.replace('PAYLOAD',repr(payload))
(out/'dispatch.py').write_text(script)
argv=['ssh','-T','-p','2222','-o','BatchMode=yes','-o','ConnectTimeout=10','root@10.176.26.71','python3','-B','-']
(out/'command.json').write_text(json.dumps({'argv':argv,'stdin_sha256':hashlib.sha256(script.encode()).hexdigest()},indent=2)+'\n')
with (out/'reply.json').open('xb') as f,(out/'stderr.log').open('xb') as e:
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=f,stderr=e,start_new_session=True)
 child.stdin.write(script.encode());child.stdin.close()
 try:code=child.wait(timeout=960)
 except subprocess.TimeoutExpired:code=None
print(json.dumps({'ssh_returncode':code,'pid':child.pid}),flush=True)
if code!=0:
 print((out/'stderr.log').read_text());raise SystemExit('Observer ended; retain state.')
reply=json.loads((out/'reply.json').read_text());target=out/'collected';target.mkdir()
for name,row in reply['files'].items():
 raw=base64.b64decode(row['data']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps({'build_returncode':reply['returncode'],'files':len(reply['files'])}),flush=True)
print((target/'build.stdout').read_text(),flush=True)
if reply['returncode']!=0:print((target/'build.stderr').read_text(),flush=True)
