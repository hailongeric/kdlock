from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).parent;out=root/sys.argv[1];out.mkdir()
source=(root/'recovery-read.py').read_bytes()
argv=['ssh','-T','-p','22','-o','BatchMode=yes','-o','ConnectTimeout=10','eric@10.176.26.71','sudo','-n','python3','-B','-']
(out/'command.json').write_text(json.dumps({'argv':argv,'stdin_sha256':hashlib.sha256(source).hexdigest()},indent=2)+'\n')
with (out/'recovery.json').open('xb') as f,(out/'stderr.log').open('xb') as e:
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=f,stderr=e,start_new_session=True)
 child.stdin.write(source);child.stdin.close()
 try:code=child.wait(timeout=45)
 except subprocess.TimeoutExpired:code=None
assert code==0,(code,child.pid)
data=json.loads((out/'recovery.json').read_text())
assert all(r['host_available']>=40*1024**3 for r in data['images'])
for disk in ('drive_system','drive_data1','drive_kdlock_builds2'):
 r=next(x for x in data['hmp'] if x['command']=='info block -v '+disk)
 assert all(t in r['output'] for t in ('kdlock-builddisk-clean-20261031','kd-mm-step-failed-20261111-01'))
print(json.dumps({'recovery_sha256':hashlib.sha256((out/'recovery.json').read_bytes()).hexdigest(),'host_available':min(r['host_available'] for r in data['images']),'snapshot_copies_verified':6}))
