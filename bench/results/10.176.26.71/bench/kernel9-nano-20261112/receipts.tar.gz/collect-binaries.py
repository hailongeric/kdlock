from pathlib import Path
import hashlib,json,subprocess,tarfile
base=Path(__file__).parent;out=base/'binaries';out.mkdir()
source='''from pathlib import Path
import sys,tarfile
root=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/nano-kernel9-20261112-02')
assert not Path('/dev/kd_rwlock_bench').exists() and not Path('/dev/kd_nano_source').exists()
assert {x.split()[0] for x in Path('/proc/modules').read_text().splitlines()}<={'nls_iso8859_1'}
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='ff9d44b5-bcfc-4ec0-ad0c-2e8798bc8f0c'
paths=[p for p in (root/'build').rglob('*') if p.is_file() and (p.suffix in ('.ko','.mod','.o','.c') or p.name=='Module.symvers')]
assert len(paths)>16 and sum(p.stat().st_size for p in paths)<64*1024**2
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as t:
 for p in sorted(paths):
  assert not p.is_symlink()
  t.add(p,arcname=str(p.relative_to(root)),recursive=False)
'''
(out/'collector.py').write_text(source)
argv=['ssh','-T','-p','2222','-o','BatchMode=yes','-o','ConnectTimeout=10','root@10.176.26.71','python3','-B','-']
(out/'command.json').write_text(json.dumps({'argv':argv,'stdin_sha256':hashlib.sha256(source.encode()).hexdigest()},indent=2)+'\n')
with (out/'modules.tar.gz').open('xb') as f,(out/'stderr.log').open('xb') as e:
 p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=f,stderr=e,start_new_session=True);p.stdin.write(source.encode());p.stdin.close()
 try:code=p.wait(timeout=60)
 except subprocess.TimeoutExpired:code=None
assert code==0,(code,p.pid)
manifest={}
with tarfile.open(out/'modules.tar.gz') as t:
 for m in t:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  raw=t.extractfile(m).read();manifest[m.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'bytes':sum(v['bytes'] for v in manifest.values()),'archive_sha256':hashlib.sha256((out/'modules.tar.gz').read_bytes()).hexdigest()}))
