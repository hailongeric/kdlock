from pathlib import Path
import base64,gzip,hashlib,json,subprocess,sys,tarfile,io
base=Path(__file__).parent;stage=sys.argv[1];assert stage in ('functional','timing');out=base/stage;out.mkdir()
recovery=(base/('recovery-'+stage)/'recovery.json').read_bytes()
built=base/'stage-build/collected/build/result.json'
payload={'recovery':base64.b64encode(recovery).decode(),'recovery_sha256':hashlib.sha256(recovery).hexdigest(),'build_sha256':hashlib.sha256(built.read_bytes()).hexdigest(),'stage':stage}
script=r'''from pathlib import Path
import base64,hashlib,io,json,os,subprocess,sys,tarfile,time
p=PAYLOAD
base=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01');root=base/'nano-kernel9-20261112-02';control=root/'control';sys.path.insert(0,str(control));import kernel9_common as c
before=c.idle(4096);config=json.loads((control/'kernel-config.json').read_text());native,plan,built,final,proof=c.kernel_inputs(config)
assert c.sha(root/'build/result.json')==p['build_sha256']
assert json.loads((root/'build/result.json').read_text())['status']=='NANO_MODULES_BUILT_SIGNED'
expected=json.loads((control/'source-sha256.json').read_text())
def sources():
 actual={str(q.relative_to(root/'input')):{'bytes':q.stat().st_size,'sha256':c.sha(q)} for q in (root/'input').rglob('*') if q.is_file()}
 assert actual==expected
sources()
raw=base64.b64decode(p['recovery']);assert hashlib.sha256(raw).hexdigest()==p['recovery_sha256']
recovery_path=control/('recovery-'+p['stage']+'.json')
with recovery_path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
recovery=c.recovery(native,plan,recovery_path,p['recovery_sha256'])
topology={'online':Path('/sys/devices/system/cpu/online').read_text().strip(),'numa':{q.name:(q/'cpulist').read_text().strip() for q in Path('/sys/devices/system/node').glob('node[0-9]*')}}
assert topology=={'online':'0-63','numa':{'node0':'0-31','node1':'32-63'}}
run=root/p['stage'];run.mkdir()
report={'stage':p['stage'],'before':before,'recovery':recovery,'topology':topology,'commands':[],'status':'STARTED'};c.save(run/'started.json',report)
python='/mnt/kdlock-builds/venvs/kdlock-translation-7.0-20261027/bin/python3'
prerequisites=[]
if p['stage']=='timing':
 for family in ('mutex','rwsem'):
  for backend in ('native','kdlock','tclock'):
   prerequisites.extend(['--prerequisite',str(root/'functional'/(family+'-'+backend)/'result.json')])
code=0
try:
 for family in ('mutex','rwsem'):
  for backend in ('native','kdlock','tclock'):
   c.idle(4096)
   label=family+'-'+backend;argv=[python,'-B',str(root/'input/bench/nano/run.py'),'--repo',str(root/'input'),'--build-receipt',str(root/'build/result.json'),'--output',str(run/label),'--family',family,'--backend',backend,'--stage',p['stage'],'--boot-id',c.BOOT,'--kernel-elf',str(c.BUILD/'vmlinux'),'--gs-proof',str(base/'receipts/postboot-kdrebuild9-cohort-01/gs-proof.json'),*prerequisites]
   command={'label':label,'argv':argv,'started_unix':time.time()};report['commands'].append(command)
   with (run/(label+'.stdout')).open('xb') as stdout,(run/(label+'.stderr')).open('xb') as stderr:
    child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
    command['pid']=child.pid;c.save(run/(label+'-started.json'),command)
    try:code=child.wait(timeout=600)
    except subprocess.TimeoutExpired:code=None
   command.update(returncode=code,elapsed_seconds=time.time()-command['started_unix']);c.save(run/(label+'-command.json'),command)
   if code!=0:raise RuntimeError('phase failed/incomplete; no unload inferred: '+label)
 sources();c.kernel_inputs(config);report.update(status='COMPLETE',after=c.idle(4096))
except BaseException as error:
 report.update(status='FAILED_OR_INCOMPLETE_RETAINED',error=repr(error));code=code if code else 1
report['observed_final']={'release':os.uname().release,'boot':Path('/proc/sys/kernel/random/boot_id').read_text(),'taint':Path('/proc/sys/kernel/tainted').read_text(),'modules':Path('/proc/modules').read_text()};c.save(run/'supervisor-result.json',report)
paths=sorted(q for q in run.rglob('*') if q.is_file());assert sum(q.stat().st_size for q in paths)<256*1024**2
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as t:
 for q in paths:t.add(q,arcname=str(q.relative_to(run)),recursive=False)
raw=buffer.getvalue();print(json.dumps({'status':report['status'],'code':code,'files':len(paths),'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive':base64.b64encode(raw).decode()}))
'''.replace('PAYLOAD',repr(payload))
(out/'dispatch.py').write_text(script)
argv=['ssh','-T','-p','2222','-o','BatchMode=yes','-o','ConnectTimeout=10','root@10.176.26.71','python3','-B','-']
(out/'command.json').write_text(json.dumps({'argv':argv,'stdin_sha256':hashlib.sha256(script.encode()).hexdigest()},indent=2)+'\n')
with (out/'reply.json').open('xb') as f,(out/'stderr.log').open('xb') as e:
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=f,stderr=e,start_new_session=True)
 child.stdin.write(script.encode());child.stdin.close()
 try:code=child.wait(timeout=3700)
 except subprocess.TimeoutExpired:code=None
print(json.dumps({'ssh_returncode':code,'pid':child.pid}),flush=True)
if code!=0:
 print((out/'stderr.log').read_text());raise SystemExit('Observer ended; retain state.')
reply=json.loads((out/'reply.json').read_text());raw=base64.b64decode(reply.pop('archive'));assert hashlib.sha256(raw).hexdigest()==reply['archive_sha256'];(out/'receipts.tar.gz').write_bytes(raw)
target=out/'collected';target.mkdir();manifest={}
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for member in t:
  rel=Path(member.name);assert member.isfile() and not rel.is_absolute() and '..' not in rel.parts
  data=t.extractfile(member).read();manifest[member.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  q=target/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(reply),flush=True)
for q in sorted(target.glob('*.stdout')):print(q.name+'\n'+q.read_text(),flush=True)
for q in sorted(target.glob('*.stderr')):
 if q.stat().st_size:print(q.name+'\n'+q.read_text(),flush=True)
