#!/usr/bin/env python3
"""Compare rwlocks, sleeping rwsems and proc spin snapshots in the guest."""
import argparse
import importlib.metadata
import itertools
import json
import os
from pathlib import Path
import shutil
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'bench/spin_cacheline'))
from bench_runtime import Failure, command, digest, idle as common_idle, require, capture_topology
from summarize import write_json
import kernel_identity
from provider.prepare import prepare as prepare_provider
sys.path.insert(0, str(ROOT / 'bench/tclock_compare'))
from context_audit import audit
# Import our session explicitly from this directory, not the spin/mutex runner.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from session import RWSession
from parity import assess
import boot_policy

FULL_THREADS = [1, 2, 3, 4, 5, 6, 7, 8, 12, 16, 20, 24, 28, 32, 36]


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path)
    p.add_argument('--backends', nargs='+', choices=('native', 'tclock', 'kdlock'),
                   default=['native', 'tclock', 'kdlock'])
    p.add_argument('--workloads', nargs='+', choices=('cacheline', 'rcuht', 'taskname', 'argbounds',
                                                   'nano'), default=['rcuht'])
    p.add_argument('--lock-kind', choices=('rwlock', 'spin', 'rwsem', 'mutex'), default='rwlock')
    p.add_argument('--helper-waves', type=int, default=8,
                   help='maximum drain-separated task-name helper-learning rounds; 0 diagnoses the initial image')
    p.add_argument('--helper-workers', type=int, default=8,
                   help='separate task-name preparation cohort, including single-worker timing')
    p.add_argument('--cachelines', nargs='+', type=int, choices=(1, 2, 4, 8, 16), default=[1])
    p.add_argument('--write-percent', nargs='+', type=int, default=[1, 20])
    p.add_argument('--threads', nargs='+', type=int, default=FULL_THREADS)
    p.add_argument('--full-matrix', action='store_true', help='select the existing 15-point thread set')
    p.add_argument('--cpus', nargs='+', type=int, help='ordered worker CPU list; cohorts take prefixes')
    p.add_argument('--collector-cpu', type=int, default=38)
    p.add_argument('--repeats', type=int, default=3)
    p.add_argument('--duration-ms', type=int, default=2000)
    p.add_argument('--peak-window-ms', type=int, default=300)
    p.add_argument('--peak-settle-ms', type=int, default=300)
    p.add_argument('--sample-ms', type=int, default=10)
    p.add_argument('--iterations', type=int, default=50000, help='per worker for fixed/functional runs')
    p.add_argument('--post-work-rounds', type=int, default=4)
    p.add_argument('--spin-entry-ratio-limit', type=int, default=2)
    p.add_argument('--mutex-batch-limit', type=int, default=1024,
                   help='KD mutex total service cap; default 1024')
    p.add_argument('--mutex-numa-boundary', type=int, default=1024,
                   help='KD mutex NUMA cohort boundary; default 1024')
    p.add_argument('--delegate', choices=('on', 'off'), default='on',
                   help='KD local control when off; rwsem uses callable local API symbols')
    p.add_argument('--require-jit', action='store_true',
                   help='require complete delegation in each eligible multithread KD case')
    p.add_argument('--require-parity', action='store_true',
                   help='fail after the full comparison if KD is slower on peak or median whole-run throughput')
    p.add_argument('--functional', action='store_true', help='one fixed-iteration round, no performance scores')
    p.add_argument('--dry-run', action='store_true', help='print plan without builds, modules or timing')
    kernel_identity.benchmark_arguments(p)
    return p


def mutex_policy(args):
    cap, boundary = args.mutex_batch_limit, args.mutex_numa_boundary
    require(type(cap) is int and type(boundary) is int and 1 <= cap <= 32767 and 1 <= boundary <= 32767,
            'mutex policy requires total cap and NUMA boundary in 1..32767')
    require((cap, boundary) == (1024, 1024) or
            (args.lock_kind == 'mutex' and 'kdlock' in args.backends and args.delegate == 'on'),
            'nondefault mutex policy requires a public KD mutex experiment')
    return dict(total_cap=cap, numa_boundary=boundary, deferred_handoff=8, scan_budget=64)


def make_plan(args):
    kernel_identity.benchmark_profile(args)
    policy = mutex_policy(args)
    require(0 <= args.helper_waves <= 16, 'helper waves must be 0..16')
    require(2 <= args.helper_workers <= 16, 'helper workers must be 2..16')
    snapshots = {'taskname', 'argbounds'}
    require((args.lock_kind == 'spin') == set(args.workloads).issubset(snapshots),
            'snapshot workloads require --lock-kind spin; other workloads use rwlock/rwsem')
    require(not (set(args.workloads) & snapshots) or set(args.workloads).issubset(snapshots),
            'run snapshots separately from rwlock/rwsem payloads')
    require(args.lock_kind != 'mutex' or (args.workloads in (['nano'], ['cacheline']) and
            args.write_percent == [100]),
            'mutex nano requires an all-writer pair or padded-counter profile')
    require('nano' not in args.workloads or args.lock_kind in ('mutex', 'rwsem'),
            'nano profiles use mutex or rwsem')
    threads = FULL_THREADS if args.full_matrix else args.threads
    for values, name in ((threads, 'threads'), (args.backends, 'backends'), (args.workloads, 'workloads'),
                         (args.cachelines, 'cachelines'), (args.write_percent, 'write percentages')):
        require(values and len(values) == len(set(values)), 'empty/duplicate ' + name)
    require(all(1 <= n <= 64 for n in threads), 'threads must be 1..64')
    require(all(0 <= p <= 100 for p in args.write_percent), 'write percentages must be 0..100')
    require(1 <= args.post_work_rounds <= 256 and 0 < args.iterations <= 100000000,
            'invalid post-work or iterations')
    require(args.repeats == 1 if args.functional else args.repeats in (1, 3),
            'use one functional round or one/three performance rounds')
    parity_backends = ({'native', 'kdlock'} if args.lock_kind == 'rwsem' and 'tclock' not in args.backends
                       else {'native', 'tclock', 'kdlock'})
    require(not args.require_parity or (not args.functional and args.repeats == 3 and
                                       set(args.backends) == parity_backends),
            '--require-parity needs ' + ', '.join(sorted(parity_backends)) + ' and three timed rounds')
    require(args.spin_entry_ratio_limit in (0, *(1 << n for n in range(1, 32))), 'invalid entry ratio limit')
    require(not args.require_jit or (args.delegate == 'on' and 'kdlock' in args.backends and
            max(threads) > 1 and (min(args.write_percent) < 100 if args.lock_kind == 'spin'
                                 else max(args.write_percent) > 0)), '--require-jit needs contended eligible operations')
    learns_helpers = ('taskname' in args.workloads and 'kdlock' in args.backends and
                      args.delegate == 'on' and args.helper_waves and min(args.write_percent) < 100)
    required_cpus = max(max(threads), args.helper_workers if learns_helpers else 0)
    cpus = args.cpus if args.cpus is not None else list(range(required_cpus))
    require(len(cpus) >= required_cpus and len(set(cpus)) == len(cpus) and all(c >= 0 for c in cpus),
            'need distinct nonnegative worker CPUs')
    require(args.collector_cpu >= 0 and args.collector_cpu not in cpus[:required_cpus],
            'collector must have a separate CPU')
    duration = 0 if args.functional else args.duration_ms
    require(args.functional or 0 < duration <= 10000, 'performance runs require a timed interval')
    require(0 < args.sample_ms <= args.peak_window_ms and args.peak_settle_ms >= 0 and
            (not duration or args.peak_settle_ms + args.peak_window_ms < duration), 'invalid peak intervals')
    cases = [(workload, lines) for workload in args.workloads
             for lines in (args.cachelines if workload == 'cacheline' else
                           [2] if workload == 'nano' else [0])]
    plan = []
    for (workload, lines), percent, n, repeat in itertools.product(cases, args.write_percent, threads, range(args.repeats)):
        offset = repeat % len(args.backends)
        for arm in args.backends[offset:] + args.backends[:offset]:
            variant = (f'nano-pair-{arm}' if workload == 'nano' else
                       f'{workload}-c{lines:02d}-{arm}')
            if args.lock_kind != 'rwlock':
                variant = args.lock_kind + '-' + variant
            rwsem_direct = args.lock_kind == 'rwsem' and arm == 'kdlock' and args.delegate == 'on'
            mutex_direct = args.lock_kind == 'mutex' and arm == 'kdlock' and args.delegate == 'on'
            if args.lock_kind in ('rwsem', 'mutex') and arm == 'kdlock' and args.delegate == 'off':
                variant += '-local'
            entry_abi = (2 if rwsem_direct or mutex_direct else None) if args.lock_kind in ('rwsem', 'mutex') else \
                {'rwlock': 3, 'spin': 1}[args.lock_kind]
            plan.append(dict(name=f'{variant}-w{percent:03d}-t{n:02d}-r{repeat:02d}', variant=variant,
                arm=arm, workload=workload, cachelines=lines, write_percent=percent, threads=n, repeat=repeat,
                cpus=cpus[:n], collector_cpu=args.collector_cpu, iterations=args.iterations,
                duration_ms=duration, peak_window_ms=args.peak_window_ms, peak_settle_ms=args.peak_settle_ms,
                sample_ms=args.sample_ms, functional=args.functional, post_work_rounds=args.post_work_rounds,
                warmup_iterations_per_worker=48000, mix_policy='evenly_spaced_worker_phase17',
                helper_waves=args.helper_waves if workload == 'taskname' and arm == 'kdlock'
                    and percent < 100 and args.delegate == 'on' else 0,
                helper_cpus=cpus[:args.helper_workers] if workload == 'taskname' and arm == 'kdlock'
                    and percent < 100 and args.delegate == 'on' and args.helper_waves else [],
                helper_iterations_per_worker=240000,
                lock_kind=args.lock_kind, entry_abi=entry_abi,
                **(dict(nano_words=2, nano_record_bytes=64, call_shell='bulk_ioctl',
                         mutex_api=('public' if args.delegate == 'on' else 'callable-local')
                             if args.lock_kind == 'mutex' and arm == 'kdlock' else None)
                   if workload == 'nano' else {}),
                **(dict(call_shell='bulk_ioctl', nano_working_set_bytes=64 * lines,
                         nano_layout=f'{lines}_aligned_counters',
                         mutex_api=('public' if args.delegate == 'on' else 'callable-local')
                             if args.lock_kind == 'mutex' and arm == 'kdlock' else None)
                   if workload == 'cacheline' else {}),
                caller_abi='clobber' if arm == 'kdlock' and
                    (args.lock_kind not in ('rwsem', 'mutex') or rwsem_direct or mutex_direct) else 'c',
                delegate=args.delegate == 'on' if arm == 'kdlock' else False,
                rwsem_writer_shell=('upstream-stack' if arm == 'tclock' else
                    'public-prepared-direct-abi2' if rwsem_direct else 'callable-local')
                    if args.lock_kind == 'rwsem' else None,
                require_jit=args.require_jit and arm == 'kdlock' and
                    (percent < 100 if args.lock_kind == 'spin' else percent > 0) and n > 1,
                spin_entry_ratio_limit=args.spin_entry_ratio_limit if arm == 'kdlock' else None,
                numa_policy='on' if arm != 'native' and (args.lock_kind != 'rwsem' or rwsem_direct or arm == 'tclock')
                    else 'not_applicable',
                provider_ubsan='off',
                provider_mutex_policy=dict(policy) if arm == 'kdlock' else None,
                delegation_batch_limit=policy['total_cap'] if mutex_direct else 1024 if arm != 'native' and
                    (args.lock_kind not in ('rwsem', 'mutex') or rwsem_direct or mutex_direct or arm == 'tclock') else None))
    return plan


def valid(row):
    return (row.get('execution_status') == 'OK' and row.get('drained') is True and
            row.get('measurement', {}).get('data_ok') is True and
            row.get('measurement', {}).get('complete') is True)


def execution_class(row):
    if row['arm'] != 'kdlock':
        return 'NATIVE'
    bodies, completed = row.get('jit_bodies'), row.get('jit_completions')
    if bodies is None or completed is None:
        return 'UNMEASURED'
    require(type(bodies) is int and type(completed) is int and
            0 <= completed <= bodies <= row['measurement'][
                'reads' if row.get('lock_kind') == 'spin' else 'writes'],
            'invalid entry/completion evidence')
    return 'RETURNED_JIT' if completed else 'PARTIAL_JIT' if bodies else 'NO_JIT'


def report(out):
    records, groups = [], {}
    for spec in json.loads((out / 'plan.json').read_text()):
        path = out / spec['name'] / 'session.json'
        row = json.loads(path.read_text()) if path.exists() else dict(spec, execution_status='NOT_RUN', drained=False)
        records.append(row)
        if not valid(row) or row['functional']:
            continue
        m = row['measurement']
        row['whole_ops_s'] = m['completed'] * 1e9 / m['wall_ns']
        row['read_ops_s'] = m['reads'] * 1e9 / m['wall_ns']
        row['write_ops_s'] = m['writes'] * 1e9 / m['wall_ns']
        row['peak_ops_s'] = m['peak']['throughput_ops_s']
        evidence = execution_class(row)
        if evidence is not None:
            row['execution_class'] = evidence
            row['score_eligible'] = evidence not in ('PARTIAL_JIT', 'UNMEASURED')
            if not row['score_eligible']:
                continue
        # No pooling of JIT positives and native-admitted runs, or different
        # placement/mixes/post-work. This report consumes one frozen plan only.
        key = (row['variant'], row['write_percent'], row['threads'], row['jit_status'])
        groups.setdefault(key, []).append(row)
    summary = []
    for key, rows in groups.items():
        peaks = [row['peak_ops_s'] for row in rows]
        whole = [row['whole_ops_s'] for row in rows]
        summary.append(dict(variant=key[0], write_percent=key[1], threads=key[2], jit_status=key[3],
            score_eligible=True,
            valid_rounds=len(rows), expected_rounds=3, complete=len(rows) == 3,
            best_peak_ops_s=max(peaks), peak_min_ops_s=min(peaks), peak_median_ops_s=statistics.median(peaks),
            peak_max_ops_s=max(peaks), peak_spread_pct=(max(peaks) - min(peaks)) * 100 / min(peaks),
            whole_min_ops_s=min(whole), whole_median_ops_s=statistics.median(whole), whole_max_ops_s=max(whole),
            whole_spread_pct=(max(whole) - min(whole)) * 100 / min(whole),
            samples=[row['name'] for row in rows]))
    write_json(out / 'records.json', records)
    write_json(out / 'summary.json', summary)
    parity = assess(json.loads((out / 'plan.json').read_text()), summary)
    write_json(out / 'parity.json', parity)
    return parity


def idle():
    common_idle()
    for module in ('rwlock_bench', 'rwlock_test', 'tclock_backend_km', 'tclock_mutex_backend_km',
                   'tclock_rwlock_backend_km', 'tclock_rwsem_backend_km', 'tc_allocator_guard'):
        require(not Path('/sys/module', module).exists(), 'existing module: ' + module)
    for path in Path('/proc').glob('[0-9]*/task/[0-9]*/comm'):
        try:
            require(path.read_text().strip() != 'rb_worker', 'existing rwlock worker')
        except FileNotFoundError:
            pass


def sources():
    result = {}
    for directory in ('include', 'kernel_module', 'daemon', 'disassem', 'tclock_backend',
                      'workload_modules/rwlock_bench', 'workload_modules/spin_cacheline',
                      'bench/rwlock_compare', 'bench/spin_cacheline', 'bench/tclock_compare', 'bench/nano',
                      'tests/protocols', 'kernel_baseline', 'kernel_integration/linux70',
                      'kernel_integration/real_api'):
        for path in (ROOT / directory).rglob('*'):
            relative = path.relative_to(ROOT)
            if (path.is_file() and not any(part.startswith('.') or part in ('__pycache__', 'results')
                                          for part in relative.parts) and not path.name.endswith('.mod.c') and
                    (path.suffix in ('.c', '.h', '.inc', '.S', '.def', '.py', '.patch', '.json') or
                     path.name in ('Makefile', 'requirements.txt', 'guest.config'))):
                result[str(relative)] = digest(path)
    return result


def build(args, out, plan, *, mutex_diag=False):
    policy = mutex_policy(args)
    source = out / 'source'
    builds = out / 'build'
    builds.mkdir()
    binaries = dict(workloads={})
    guard = builds / 'guard'
    shutil.copytree(source / 'bench/tclock_compare/allocator_guard', guard)
    command(['make', '-C', guard, f'KDIR={args.kernel_source}'], out / 'build-guard.log', timeout=180)
    binaries['guard'] = guard / 'tc_allocator_guard.ko'
    if 'kdlock' in args.backends:
        provider = builds / 'provider'
        prepare_provider(provider, source)
        command(['make', '-C', provider / 'kernel_module', f'KDIR={args.kernel_source}', 'W=1',
                 'KDLOCK_SELFTEST=0', 'KDLOCK_NUMA=1', 'KDLOCK_SPIN_BATCH=1024',
                 f'KDLOCK_MUTEX_BATCH={policy["total_cap"]}',
                 f'KDLOCK_MUTEX_NUMA_BOUNDARY={policy["numa_boundary"]}',
                 f'KDLOCK_MUTEX_DIAGNOSTICS={int(mutex_diag)}', 'UBSAN_SANITIZE=n'],
                out / 'build-kdlock.log', timeout=180)
        binaries['kdlock'] = provider / 'kernel_module/kdlock_km.ko'
        command(['make', '-C', source / 'daemon', 'CFLAGS=-O2 -Wall -Wextra -Werror'],
                out / 'build-daemon.log', timeout=120)
        binaries['daemon'] = source / 'daemon/daemon'
        for field, expected in (('spin_numa', '1'), ('spin_batch', '1024'),
                                ('mutex_batch', str(policy['total_cap'])),
                                ('mutex_numa_boundary', str(policy['numa_boundary'])),
                                ('mutex_batch_diag', str(int(mutex_diag)))):
            require(command(['modinfo', '-F', field, binaries['kdlock']], out / (field + '.txt')).strip() == expected,
                    'KD compiled policy differs')
    if 'tclock' in args.backends:
        tc = builds / 'tclock'
        shutil.copytree(source / 'tclock_backend', tc)
        tc_kind = args.lock_kind
        command(['make', '-C', tc, f'KDIR={args.kernel_source}',
                 f'TCLOCK_RWLOCK={int(tc_kind == "rwlock")}',
                 f'TCLOCK_RWSEM={int(tc_kind == "rwsem")}',
                 f'TCLOCK_MUTEX={int(tc_kind == "mutex")}', 'TCLOCK_NUMA=1'],
                out / 'build-tclock.log', timeout=180)
        binaries['tclock'] = tc / ({'rwlock': 'tclock_rwlock_backend_km.ko', 'rwsem': 'tclock_rwsem_backend_km.ko',
                                   'spin': 'tclock_backend_km.ko',
                                   'mutex': 'tclock_mutex_backend_km.ko'}[tc_kind])
        require(command(['modinfo', '-F', tc_kind + '_numa', binaries['tclock']], out / 'tc-numa.txt').strip() == '1',
                'TCLock compiled policy differs')
        disasm = command(['objdump', '-dr', '--no-show-raw-insn', binaries['tclock']], out / 'tclock-context.txt')
        write_json(out / 'tclock-context-audit.json', audit(disasm, tc_kind))
    for spec in plan:
        variant, backend = spec['variant'], spec['arm']
        if variant in binaries['workloads']:
            continue
        folder = builds / variant
        shutil.copytree(source / 'workload_modules/rwlock_bench', folder)
        extra = [] if backend == 'native' else [f'KBUILD_EXTRA_SYMBOLS={binaries[backend].parent / "Module.symvers"}']
        command(['make', '-C', folder, f'KDIR={args.kernel_source}', f'RB_BACKEND={backend}',
                 f'RB_WORKLOAD={spec["workload"]}', f'RB_LINES={spec["cachelines"]}',
                 f'RB_LOCK_KIND={spec["lock_kind"]}',
                 f'RB_RWSEM_DELEGATE={int(spec["lock_kind"] == "rwsem" and spec["delegate"])}',
                 f'RB_MUTEX_DELEGATE={int(spec["lock_kind"] == "mutex" and spec["delegate"])}',
                 f'RB_POST_WORK_ROUNDS={spec["post_work_rounds"]}',
                 f'KDLOCK_INCLUDE={source / "include"}', f'TCLOCK_INCLUDE={source / "tclock_backend/include"}',
                 f'RB_SHARED={source / "workload_modules/spin_cacheline"}', *extra],
                out / ('build-' + variant + '.log'), timeout=180)
        binary = folder / 'rwlock_bench.ko'
        binaries['workloads'][variant] = binary
        imports = command(['nm', '-u', binary], out / ('imports-' + variant + '.txt'))
        expected = {'native': (), 'tclock': ('komb_read_lock', 'komb_read_unlock', 'komb_write_lock', 'komb_write_unlock'),
                    'kdlock': ('kd_spin_prepare', 'kd_rwlock_lock_pinned_clobber_v1', 'kd_spin_unlock_clobber_v1')}[backend]
        if spec['lock_kind'] == 'spin':
            expected = {'native': (), 'tclock': ('komb_spin_lock', 'komb_spin_unlock'),
                        'kdlock': ('kd_spin_prepare', 'kd_spin_lock_pinned_clobber_v1', 'kd_spin_unlock_clobber_v1')}[backend]
        elif spec['lock_kind'] == 'rwsem':
            expected = {'native': ('down_read', 'up_read', 'down_write', 'up_write'),
                        'tclock': ('komb_rwsem_down_read', 'komb_rwsem_up_read',
                                   'komb_rwsem_down_write', 'komb_rwsem_up_write',
                                   'tc_rwsem_worker_register'),
                        'kdlock': ('kd_down_read', 'kd_up_read', 'kd_down_write', 'kd_up_write')}[backend]
            if backend == 'kdlock' and spec['delegate']:
                expected = ('kd_down_read', 'kd_up_read', 'kd_rwsem_prepare',
                            'kd_rwsem_down_write_clobber_v1',
                            'kd_rwsem_up_write_clobber_v1')
                from mutex_api_audit import audit_public_entries
                write_json(out / ('public-entry-' + variant + '.json'),
                           audit_public_entries(binary, {'rb_entry': 'rb_write'},
                               lock_symbol='kd_rwsem_down_write_clobber_v1',
                               unlock_symbol='kd_rwsem_up_write_clobber_v1'))
        elif spec['lock_kind'] == 'mutex':
            expected = {'native': ('mutex_lock', 'mutex_unlock'),
                        'tclock': ('komb_mutex_lock', 'komb_mutex_unlock', 'tc_mutex_worker_register',
                                   'tc_mutex_workers_drain'),
                        'kdlock': ('kd_mutex_prepare', 'kd_mutex_direct_lock_clobber_v1',
                                   'kd_mutex_direct_unlock_clobber_v1', 'kd_mutex_is_idle')}[backend]
            if backend == 'kdlock' and not spec['delegate']:
                expected = ('kd_mutex_api_lock', 'kd_mutex_api_unlock', 'kd_mutex_is_idle')
            if backend == 'kdlock' and spec['delegate']:
                from mutex_api_audit import audit_public_entries
                write_json(out / ('public-entry-' + variant + '.json'),
                           audit_public_entries(binary, {'rb_entry': 'rb_write'}))
        missing = sorted(set(expected) - set(imports.split()))
        require(not missing, f'{variant}: missing direct API imports: {missing}')
        require(backend != 'native' or not any(name in imports for name in ('kd_', 'komb_')), 'native imports a delegate')
        command(['objdump', '-dr', binary], out / ('caller-' + variant + '.txt'))
    all_binaries = [value for key, value in binaries.items() if key != 'workloads'] + list(binaries['workloads'].values())
    for binary in all_binaries:
        if binary.suffix == '.ko':
            imports = command(['nm', '-u', binary], out / (binary.parent.name + '-ubsan.txt'))
            require('__ubsan_' not in imports, 'benchmark module imports UBSAN handlers')
    hashes = {str(path): digest(path) for path in all_binaries}
    write_json(out / 'binary-sha256.json', hashes)
    return binaries, hashes


def main(argv=None):
    args = parser().parse_args(argv)
    plan = make_plan(args)
    if args.dry_run:
        print(json.dumps(plan, indent=2))
        return 0
    require(args.output is not None, '--output is required')
    kernel_identity.benchmark_profile(args, release=os.uname().release)
    require(os.geteuid() == 0 and str(ROOT).startswith('/root/') and
            os.environ.get('KDLOCK_RECOVERY_CONFIRMED') == '1' and os.environ.get('KDLOCK_SNAPSHOT_TAG'),
            'confirmed recovery guest and recorded snapshot tag required')
    out = args.output.resolve()
    require(not out.exists() and not out.is_relative_to(ROOT), 'use a new output directory outside source')
    idle()
    out.mkdir(parents=True)
    write_json(out / 'plan.json', plan)
    try:
        identity = kernel_identity.capture(args, out, command)
        require(command(['findmnt', '-T', ROOT, '-n', '-o', 'FSTYPE'], out / 'mount.txt').strip() == 'ext4', 'ext4 required')
        require(identity.get('schema') == 2 and identity.get('runtime_policy_verified') is True,
                'exact Linux 7 kernel and runtime policy verification required')
        policy = boot_policy.capture(args.kernel_source, out, command)
        packages = {p: importlib.metadata.version(p) for p in ('miasm', 'future', 'pyparsing', 'pyelftools')}
        require(packages == dict(miasm='0.1.5', future='1.0.0', pyparsing='2.4.7', pyelftools='0.27'), 'dependencies differ')
        cpus = max((cohort for spec in plan for cohort in (spec['cpus'], spec['helper_cpus'])), key=len)
        topology = capture_topology(cpus + [args.collector_cpu])
        for spec in plan:
            spec['cpu_nodes'] = topology['role_nodes'][:spec['threads']]
            spec['helper_cpu_nodes'] = topology['role_nodes'][:len(spec['helper_cpus'])]
        write_json(out / 'plan.json', plan)
        write_json(out / 'environment.json', dict(kernel_identity=identity, boot_policy=policy,
            topology=topology, packages=packages, argv=sys.argv, python=sys.executable,
            snapshot_tag=os.environ['KDLOCK_SNAPSHOT_TAG'], cmdline=Path('/proc/cmdline').read_text(),
            preemption=Path('/sys/kernel/debug/sched/preempt').read_text(), uname=list(os.uname())))
        frozen = sources()
        for relative in frozen:
            target = out / 'source' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, target)
        require(frozen == {relative: digest(out / 'source' / relative) for relative in frozen}, 'source copy changed')
        write_json(out / 'source-sha256.json', frozen)
        binaries, hashes = build(args, out, plan)
        for index, spec in enumerate(plan):
            require(not (out / 'STOP').exists(), 'STOP requested at drained case boundary', 'STOPPED')
            require(sources() == frozen and
                    all(digest(out / 'source' / path) == value for path, value in frozen.items()) and
                    all(digest(Path(path)) == value for path, value in hashes.items()),
                    'frozen inputs changed')
            idle()
            print(f'[{index + 1}/{len(plan)}] {spec["name"]}', flush=True)
            session = RWSession(out, spec, binaries)
            session.execute()
            print(f'  reads={session.record["measurement"]["reads"]} writes={session.record["measurement"]["writes"]} '
                  f'JIT_entries={session.record["jit_bodies"]} '
                  f'JIT_complete={session.record["jit_completions"]} drained=True', flush=True)
        idle()
        parity = report(out)
        require(not args.require_parity or parity['status'] == 'PASS',
                'KD throughput parity target not met; see parity.json', 'PERFORMANCE_REGRESSION')
        return 0
    except (Failure, OSError, ValueError, KeyError, AssertionError) as error:
        write_json(out / 'failure.json', dict(error=str(error), status=getattr(error, 'status', 'FAILED')))
        report(out)
        print(f'STOP: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
