/* Constructed metadata only; source/code retention and publication are caller-owned. */
#include "kernel/feedback_publish.h"

#ifdef kd_nano_image
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_epoch
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_producer
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_entry
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_emission_receipt
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_observations
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_entry_sites
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_sites
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_version
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_version_length
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_inputs
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_0
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_1
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_2
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_3
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_4
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_5
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_6
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_7
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_8
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_9
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_10
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_11
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_12
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_13
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_14
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_15
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_16
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_17
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_18
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_19
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_20
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_21
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_22
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_23
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_24
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_25
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_26
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_27
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_28
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_29
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_30
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_31
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_32
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_33
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_34
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_35
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_36
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_37
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_38
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_39
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_40
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_41
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_42
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_43
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_44
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_45
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_46
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_47
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_48
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_49
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_50
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_51
#error "artifact symbol collides with a macro"
#endif
#ifdef kd_nano_image_source_bytes_52
#error "artifact symbol collides with a macro"
#endif

struct kd_jit_source_epoch;
extern struct kd_jit_source_epoch kd_nano_epoch;
extern struct kd_jit_feedback_producer kd_nano_producer;
extern void kd_nano_entry(struct kd_regs *, struct kd_jit_io *);

_Static_assert(KD_JIT_ABI_VERSION == 1U, "constructed image ABI");
_Static_assert(sizeof(struct kd_regs) == 168U, "constructed packet size");
_Static_assert(sizeof(struct kd_jit_io) == 56U, "constructed IO size");

const unsigned char kd_nano_image_source_version[] = {
	0x6e, 0x61, 0x6e, 0x6f, 0x2d, 0x32, 0x32, 0x61, 0x31, 0x39, 0x37, 0x33, 0x34, 0x66, 0x31, 0x37,
	0x35, 0x33, 0x31, 0x63, 0x66, 0x65, 0x65, 0x31, 0x61, 0x35, 0x34, 0x30, 0x37, 0x65, 0x35, 0x30,
	0x39, 0x37, 0x63, 0x64, 0x31, 0x64, 0x31, 0x39, 0x32, 0x36, 0x62, 0x62, 0x33, 0x30, 0x66, 0x37,
	0x38, 0x61, 0x65, 0x38, 0x62, 0x37, 0x36, 0x34, 0x66, 0x31, 0x32, 0x39, 0x30, 0x32, 0x37, 0x31,
	0x62, 0x38, 0x61, 0x33, 0x65, 0x2d, 0x30, 0x66, 0x65, 0x30, 0x66, 0x65, 0x39, 0x33, 0x30, 0x65,
	0x33, 0x39, 0x31, 0x62, 0x62, 0x32, 0x36, 0x33, 0x66, 0x64, 0x63, 0x66, 0x61, 0x34, 0x62, 0x61,
	0x39, 0x39, 0x34, 0x30, 0x65, 0x65, 0x65, 0x32, 0x32, 0x35, 0x32, 0x38, 0x30, 0x61, 0x36, 0x36,
	0x38, 0x30, 0x32, 0x31, 0x63, 0x62, 0x31, 0x31, 0x61, 0x32, 0x36, 0x39, 0x61, 0x36, 0x39, 0x31,
	0x63, 0x62, 0x38, 0x63, 0x31, 0x35,
};
const unsigned long kd_nano_image_source_version_length = 134UL;

static const unsigned long kd_nano_image_entry_sites[] = {
	0xffffffffc000b03bUL,
	0xffffffffc000b066UL,
	0xffffffffc000b0cfUL,
	0xffffffffc000b0feUL,
};

static const struct kd_jit_source_site kd_nano_image_source_sites[] = {
	{ .ip = 0xffffffff8276eee0UL, .next_ip = 0xffffffff8276eee1UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b03bUL, .next_ip = 0xffffffffc000b042UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b042UL, .next_ip = 0xffffffffc000b049UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b049UL, .next_ip = 0xffffffffc000b04dUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b04dUL, .next_ip = 0xffffffffc000b054UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b054UL, .next_ip = 0xffffffffc000b057UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b057UL, .next_ip = 0xffffffffc000b05eUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b05eUL, .next_ip = 0xffffffffc000b061UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b061UL, .next_ip = 0xffffffffc000b066UL, .kind = KD_JIT_SITE_CALL },
	{ .ip = 0xffffffffc000b066UL, .next_ip = 0xffffffffc000b067UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b067UL, .next_ip = 0xffffffffc000b069UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b069UL, .next_ip = 0xffffffffc000b06bUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b06bUL, .next_ip = 0xffffffffc000b06dUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b06dUL, .next_ip = 0xffffffffc000b06fUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b06fUL, .next_ip = 0xffffffffc000b070UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b070UL, .next_ip = 0xffffffffc000b072UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b072UL, .next_ip = 0xffffffffc000b074UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b074UL, .next_ip = 0xffffffffc000b076UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b076UL, .next_ip = 0xffffffffc000b078UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b078UL, .next_ip = 0xffffffffc000b07aUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b07aUL, .next_ip = 0xffffffffc000b07dUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b07dUL, .next_ip = 0xffffffffc000b080UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b080UL, .next_ip = 0xffffffffc000b083UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b083UL, .next_ip = 0xffffffffc000b086UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b086UL, .next_ip = 0xffffffffc000b08bUL, .kind = KD_JIT_SITE_JUMP },
	{ .ip = 0xffffffffc000b0cfUL, .next_ip = 0xffffffffc000b0d6UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0d6UL, .next_ip = 0xffffffffc000b0ddUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0ddUL, .next_ip = 0xffffffffc000b0e4UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0e4UL, .next_ip = 0xffffffffc000b0e8UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0e8UL, .next_ip = 0xffffffffc000b0ecUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0ecUL, .next_ip = 0xffffffffc000b0efUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0efUL, .next_ip = 0xffffffffc000b0f6UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0f6UL, .next_ip = 0xffffffffc000b0f9UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b0f9UL, .next_ip = 0xffffffffc000b0feUL, .kind = KD_JIT_SITE_CALL },
	{ .ip = 0xffffffffc000b0feUL, .next_ip = 0xffffffffc000b102UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b102UL, .next_ip = 0xffffffffc000b106UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b106UL, .next_ip = 0xffffffffc000b109UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b109UL, .next_ip = 0xffffffffc000b10dUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b10dUL, .next_ip = 0xffffffffc000b10eUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b10eUL, .next_ip = 0xffffffffc000b110UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b110UL, .next_ip = 0xffffffffc000b112UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b112UL, .next_ip = 0xffffffffc000b114UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b114UL, .next_ip = 0xffffffffc000b116UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b116UL, .next_ip = 0xffffffffc000b117UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b117UL, .next_ip = 0xffffffffc000b119UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b119UL, .next_ip = 0xffffffffc000b11bUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b11bUL, .next_ip = 0xffffffffc000b11dUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b11dUL, .next_ip = 0xffffffffc000b11fUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b11fUL, .next_ip = 0xffffffffc000b122UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b122UL, .next_ip = 0xffffffffc000b125UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b125UL, .next_ip = 0xffffffffc000b128UL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b128UL, .next_ip = 0xffffffffc000b12bUL, .kind = KD_JIT_SITE_OTHER },
	{ .ip = 0xffffffffc000b12bUL, .next_ip = 0xffffffffc000b12cUL, .kind = KD_JIT_SITE_OTHER },
};

static const unsigned char kd_nano_image_source_bytes_0[] = { 0xc3 };
static const unsigned char kd_nano_image_source_bytes_1[] = { 0x48, 0x8b, 0x05, 0xfe, 0xd9, 0x5f, 0x00 };
static const unsigned char kd_nano_image_source_bytes_2[] = { 0x48, 0xc7, 0xc7, 0x40, 0x8e, 0x60, 0xc0 };
static const unsigned char kd_nano_image_source_bytes_3[] = { 0x48, 0x83, 0xc0, 0x01 };
static const unsigned char kd_nano_image_source_bytes_4[] = { 0x48, 0x89, 0x05, 0xec, 0xd9, 0x5f, 0x00 };
static const unsigned char kd_nano_image_source_bytes_5[] = { 0x48, 0x89, 0xe6 };
static const unsigned char kd_nano_image_source_bytes_6[] = { 0x48, 0x8d, 0x15, 0x08, 0x00, 0x00, 0x00 };
static const unsigned char kd_nano_image_source_bytes_7[] = { 0x48, 0x89, 0xe9 };
static const unsigned char kd_nano_image_source_bytes_8[] = { 0xe8, 0xaa, 0x43, 0x52, 0xc1 };
static const unsigned char kd_nano_image_source_bytes_9[] = { 0x5b };
static const unsigned char kd_nano_image_source_bytes_10[] = { 0x41, 0x5c };
static const unsigned char kd_nano_image_source_bytes_11[] = { 0x41, 0x5d };
static const unsigned char kd_nano_image_source_bytes_12[] = { 0x41, 0x5e };
static const unsigned char kd_nano_image_source_bytes_13[] = { 0x41, 0x5f };
static const unsigned char kd_nano_image_source_bytes_14[] = { 0x5d };
static const unsigned char kd_nano_image_source_bytes_15[] = { 0x31, 0xc0 };
static const unsigned char kd_nano_image_source_bytes_16[] = { 0x31, 0xd2 };
static const unsigned char kd_nano_image_source_bytes_17[] = { 0x31, 0xc9 };
static const unsigned char kd_nano_image_source_bytes_18[] = { 0x31, 0xf6 };
static const unsigned char kd_nano_image_source_bytes_19[] = { 0x31, 0xff };
static const unsigned char kd_nano_image_source_bytes_20[] = { 0x45, 0x31, 0xc0 };
static const unsigned char kd_nano_image_source_bytes_21[] = { 0x45, 0x31, 0xc9 };
static const unsigned char kd_nano_image_source_bytes_22[] = { 0x45, 0x31, 0xd2 };
static const unsigned char kd_nano_image_source_bytes_23[] = { 0x45, 0x31, 0xdb };
static const unsigned char kd_nano_image_source_bytes_24[] = { 0xe9, 0x55, 0x3e, 0x76, 0xc2 };
static const unsigned char kd_nano_image_source_bytes_25[] = { 0x48, 0x8b, 0x05, 0x6a, 0xd9, 0x5f, 0x00 };
static const unsigned char kd_nano_image_source_bytes_26[] = { 0x48, 0x8b, 0x1d, 0x63, 0xd9, 0x5f, 0x00 };
static const unsigned char kd_nano_image_source_bytes_27[] = { 0x48, 0xc7, 0xc7, 0x40, 0x8e, 0x60, 0xc0 };
static const unsigned char kd_nano_image_source_bytes_28[] = { 0x48, 0x89, 0x45, 0xd0 };
static const unsigned char kd_nano_image_source_bytes_29[] = { 0x48, 0x89, 0x5d, 0xc8 };
static const unsigned char kd_nano_image_source_bytes_30[] = { 0x48, 0x89, 0xe6 };
static const unsigned char kd_nano_image_source_bytes_31[] = { 0x48, 0x8d, 0x15, 0x08, 0x00, 0x00, 0x00 };
static const unsigned char kd_nano_image_source_bytes_32[] = { 0x48, 0x89, 0xe9 };
static const unsigned char kd_nano_image_source_bytes_33[] = { 0xe8, 0x12, 0x43, 0x52, 0xc1 };
static const unsigned char kd_nano_image_source_bytes_34[] = { 0x48, 0x8b, 0x5d, 0xc8 };
static const unsigned char kd_nano_image_source_bytes_35[] = { 0x48, 0x39, 0x5d, 0xd0 };
static const unsigned char kd_nano_image_source_bytes_36[] = { 0x0f, 0x95, 0xc0 };
static const unsigned char kd_nano_image_source_bytes_37[] = { 0x48, 0x83, 0xc4, 0x10 };
static const unsigned char kd_nano_image_source_bytes_38[] = { 0x5b };
static const unsigned char kd_nano_image_source_bytes_39[] = { 0x41, 0x5c };
static const unsigned char kd_nano_image_source_bytes_40[] = { 0x41, 0x5d };
static const unsigned char kd_nano_image_source_bytes_41[] = { 0x41, 0x5e };
static const unsigned char kd_nano_image_source_bytes_42[] = { 0x41, 0x5f };
static const unsigned char kd_nano_image_source_bytes_43[] = { 0x5d };
static const unsigned char kd_nano_image_source_bytes_44[] = { 0x31, 0xd2 };
static const unsigned char kd_nano_image_source_bytes_45[] = { 0x31, 0xc9 };
static const unsigned char kd_nano_image_source_bytes_46[] = { 0x31, 0xf6 };
static const unsigned char kd_nano_image_source_bytes_47[] = { 0x31, 0xff };
static const unsigned char kd_nano_image_source_bytes_48[] = { 0x45, 0x31, 0xc0 };
static const unsigned char kd_nano_image_source_bytes_49[] = { 0x45, 0x31, 0xc9 };
static const unsigned char kd_nano_image_source_bytes_50[] = { 0x45, 0x31, 0xd2 };
static const unsigned char kd_nano_image_source_bytes_51[] = { 0x45, 0x31, 0xdb };
static const unsigned char kd_nano_image_source_bytes_52[] = { 0xc3 };

static const struct kd_jit_image_source_bytes kd_nano_image_source_bytes[] = {
	{ .ip = 0xffffffff8276eee0UL, .bytes = kd_nano_image_source_bytes_0, .length = 1U },
	{ .ip = 0xffffffffc000b03bUL, .bytes = kd_nano_image_source_bytes_1, .length = 7U },
	{ .ip = 0xffffffffc000b042UL, .bytes = kd_nano_image_source_bytes_2, .length = 7U },
	{ .ip = 0xffffffffc000b049UL, .bytes = kd_nano_image_source_bytes_3, .length = 4U },
	{ .ip = 0xffffffffc000b04dUL, .bytes = kd_nano_image_source_bytes_4, .length = 7U },
	{ .ip = 0xffffffffc000b054UL, .bytes = kd_nano_image_source_bytes_5, .length = 3U },
	{ .ip = 0xffffffffc000b057UL, .bytes = kd_nano_image_source_bytes_6, .length = 7U },
	{ .ip = 0xffffffffc000b05eUL, .bytes = kd_nano_image_source_bytes_7, .length = 3U },
	{ .ip = 0xffffffffc000b061UL, .bytes = kd_nano_image_source_bytes_8, .length = 5U },
	{ .ip = 0xffffffffc000b066UL, .bytes = kd_nano_image_source_bytes_9, .length = 1U },
	{ .ip = 0xffffffffc000b067UL, .bytes = kd_nano_image_source_bytes_10, .length = 2U },
	{ .ip = 0xffffffffc000b069UL, .bytes = kd_nano_image_source_bytes_11, .length = 2U },
	{ .ip = 0xffffffffc000b06bUL, .bytes = kd_nano_image_source_bytes_12, .length = 2U },
	{ .ip = 0xffffffffc000b06dUL, .bytes = kd_nano_image_source_bytes_13, .length = 2U },
	{ .ip = 0xffffffffc000b06fUL, .bytes = kd_nano_image_source_bytes_14, .length = 1U },
	{ .ip = 0xffffffffc000b070UL, .bytes = kd_nano_image_source_bytes_15, .length = 2U },
	{ .ip = 0xffffffffc000b072UL, .bytes = kd_nano_image_source_bytes_16, .length = 2U },
	{ .ip = 0xffffffffc000b074UL, .bytes = kd_nano_image_source_bytes_17, .length = 2U },
	{ .ip = 0xffffffffc000b076UL, .bytes = kd_nano_image_source_bytes_18, .length = 2U },
	{ .ip = 0xffffffffc000b078UL, .bytes = kd_nano_image_source_bytes_19, .length = 2U },
	{ .ip = 0xffffffffc000b07aUL, .bytes = kd_nano_image_source_bytes_20, .length = 3U },
	{ .ip = 0xffffffffc000b07dUL, .bytes = kd_nano_image_source_bytes_21, .length = 3U },
	{ .ip = 0xffffffffc000b080UL, .bytes = kd_nano_image_source_bytes_22, .length = 3U },
	{ .ip = 0xffffffffc000b083UL, .bytes = kd_nano_image_source_bytes_23, .length = 3U },
	{ .ip = 0xffffffffc000b086UL, .bytes = kd_nano_image_source_bytes_24, .length = 5U },
	{ .ip = 0xffffffffc000b0cfUL, .bytes = kd_nano_image_source_bytes_25, .length = 7U },
	{ .ip = 0xffffffffc000b0d6UL, .bytes = kd_nano_image_source_bytes_26, .length = 7U },
	{ .ip = 0xffffffffc000b0ddUL, .bytes = kd_nano_image_source_bytes_27, .length = 7U },
	{ .ip = 0xffffffffc000b0e4UL, .bytes = kd_nano_image_source_bytes_28, .length = 4U },
	{ .ip = 0xffffffffc000b0e8UL, .bytes = kd_nano_image_source_bytes_29, .length = 4U },
	{ .ip = 0xffffffffc000b0ecUL, .bytes = kd_nano_image_source_bytes_30, .length = 3U },
	{ .ip = 0xffffffffc000b0efUL, .bytes = kd_nano_image_source_bytes_31, .length = 7U },
	{ .ip = 0xffffffffc000b0f6UL, .bytes = kd_nano_image_source_bytes_32, .length = 3U },
	{ .ip = 0xffffffffc000b0f9UL, .bytes = kd_nano_image_source_bytes_33, .length = 5U },
	{ .ip = 0xffffffffc000b0feUL, .bytes = kd_nano_image_source_bytes_34, .length = 4U },
	{ .ip = 0xffffffffc000b102UL, .bytes = kd_nano_image_source_bytes_35, .length = 4U },
	{ .ip = 0xffffffffc000b106UL, .bytes = kd_nano_image_source_bytes_36, .length = 3U },
	{ .ip = 0xffffffffc000b109UL, .bytes = kd_nano_image_source_bytes_37, .length = 4U },
	{ .ip = 0xffffffffc000b10dUL, .bytes = kd_nano_image_source_bytes_38, .length = 1U },
	{ .ip = 0xffffffffc000b10eUL, .bytes = kd_nano_image_source_bytes_39, .length = 2U },
	{ .ip = 0xffffffffc000b110UL, .bytes = kd_nano_image_source_bytes_40, .length = 2U },
	{ .ip = 0xffffffffc000b112UL, .bytes = kd_nano_image_source_bytes_41, .length = 2U },
	{ .ip = 0xffffffffc000b114UL, .bytes = kd_nano_image_source_bytes_42, .length = 2U },
	{ .ip = 0xffffffffc000b116UL, .bytes = kd_nano_image_source_bytes_43, .length = 1U },
	{ .ip = 0xffffffffc000b117UL, .bytes = kd_nano_image_source_bytes_44, .length = 2U },
	{ .ip = 0xffffffffc000b119UL, .bytes = kd_nano_image_source_bytes_45, .length = 2U },
	{ .ip = 0xffffffffc000b11bUL, .bytes = kd_nano_image_source_bytes_46, .length = 2U },
	{ .ip = 0xffffffffc000b11dUL, .bytes = kd_nano_image_source_bytes_47, .length = 2U },
	{ .ip = 0xffffffffc000b11fUL, .bytes = kd_nano_image_source_bytes_48, .length = 3U },
	{ .ip = 0xffffffffc000b122UL, .bytes = kd_nano_image_source_bytes_49, .length = 3U },
	{ .ip = 0xffffffffc000b125UL, .bytes = kd_nano_image_source_bytes_50, .length = 3U },
	{ .ip = 0xffffffffc000b128UL, .bytes = kd_nano_image_source_bytes_51, .length = 3U },
	{ .ip = 0xffffffffc000b12bUL, .bytes = kd_nano_image_source_bytes_52, .length = 1U },
};

const struct kd_jit_image kd_nano_image = {
	.source_identity = &kd_nano_epoch,
	.feedback_producer = &kd_nano_producer,
	.abi_version = 1U,
	.packet_size = 168U,
	.io_size = 56U,
	.entry = kd_nano_entry,
	.entry_sites = kd_nano_image_entry_sites,
	.entry_count = 4U,
	.source_sites = kd_nano_image_source_sites,
	.source_count = 53U,
};

const struct kd_jit_image_inputs kd_nano_image_inputs = {
	.image = &kd_nano_image,
	.source_version = kd_nano_image_source_version,
	.source_version_length = sizeof(kd_nano_image_source_version),
	.current_task_gs_offset = 0xffffffff84425018UL,
	.source_bytes = kd_nano_image_source_bytes,
	.source_count = 53U,
};

const struct kd_jit_feedback_emission_receipt kd_nano_image_emission_receipt = {
	.inputs = &kd_nano_image_inputs,
	.observations = NULL,
	.observation_count = 0U,
};
