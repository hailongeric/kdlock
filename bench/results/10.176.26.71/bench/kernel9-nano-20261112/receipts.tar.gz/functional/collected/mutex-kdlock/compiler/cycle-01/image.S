/* SPDX-License-Identifier: GPL-2.0-only */
/* Per-image entry template for the original UB-derived KD mapping. Lowering
 * substitutes kd_nano_entry and KD_GENERATED_BODY for one image's own code.
 * All source state remains in its original thread's one canonical packet.
 * The caller supplies fresh origin GS/task inputs, exclusive source execution,
 * valid source/code bindings and the declared sleepable physical context.
 * The distinct executor's native stack and all origin waiting/control stacks
 * must be admitted disjoint from the stopped source stack; this template does
 * not establish or allocate that context and cannot execute an origin's own
 * source on overlapping native frames.
 * General flags/SIMD use AS01; this unrun wrapper is no equivalence evidence.
 */


	.intel_syntax noprefix
	.text
	.p2align 4
	.globl kd_nano_entry
	.type kd_nano_entry, @function
kd_nano_entry:
	endbr64
	/* Preserve the executor's native callee-saved state. Logical source
	 * BP/SP are separate and never replace physical RBP/RSP here. */
	push rbp
	mov rbp, rsp
	push rbx
	push r12
	push r13
	push r14
	push r15
	/* Allocate every private slot before stores, without using a red zone
	 * or changing the assumed source flags during packet import. */
	lea rsp, [rsp - 80]
	mov QWORD PTR[RBP - 64], rsi
	mov R11, rdi
	mov r14, QWORD PTR[rsi + 0]
	mov QWORD PTR[RBP - 48], r14
	mov r14, QWORD PTR[rsi + 8]
	mov QWORD PTR[RBP - 56], r14
	/* Source R11--R15 already have canonical backing. Only the resident
	 * source GPRs and stable BP/SP caches need importing. */
	mov rbx, QWORD PTR[R11 + 64]
	mov r10, QWORD PTR[R11 + 72]
	mov r9, QWORD PTR[R11 + 80]
	mov r8, QWORD PTR[R11 + 88]
	mov rax, QWORD PTR[R11 + 96]
	mov rcx, QWORD PTR[R11 + 104]
	mov rdx, QWORD PTR[R11 + 112]
	mov rsi, QWORD PTR[R11 + 120]
	mov rdi, QWORD PTR[R11 + 128]
	mov r12, QWORD PTR[R11 + 16]
	mov r13, QWORD PTR[R11 + 8]
	jmp .Lkd_dispatch

.Lkd_dispatch:
MOVABS R14, 1000000
MOV QWORD PTR[RBP - 120], R14
MOV R14, QWORD PTR[R11 + 0]
PUSHFQ
MOVABS R15, 0xffffffffc000b03b
CMP R14, R15
JE .Lkd_enter_ffffffffc000b03b
MOVABS R15, 0xffffffffc000b066
CMP R14, R15
JE .Lkd_enter_ffffffffc000b066
MOVABS R15, 0xffffffffc000b0cf
CMP R14, R15
JE .Lkd_enter_ffffffffc000b0cf
MOVABS R15, 0xffffffffc000b0fe
CMP R14, R15
JE .Lkd_enter_ffffffffc000b0fe
POPFQ
JMP .Lkd_exit_0
.Lkd_enter_ffffffffc000b03b:
POPFQ
JMP .Lkd_src_ffffffffc000b03b
.Lkd_enter_ffffffffc000b066:
POPFQ
JMP .Lkd_src_ffffffffc000b066
.Lkd_enter_ffffffffc000b0cf:
POPFQ
JMP .Lkd_src_ffffffffc000b0cf
.Lkd_enter_ffffffffc000b0fe:
POPFQ
JMP .Lkd_src_ffffffffc000b0fe
.Lkd_src_ffffffff8276eee0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8276eee0
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R15, R15
MOV             QWORD PTR[RBP - 88], R15
MOV             R14, QWORD PTR[RBP - 88]
PUSHFQ
POPFQ
JMP .Lkd_exit_2
.Lkd_runtime_ffffffff8276eee0:
POPFQ
JMP .Lkd_exit_1
.Lkd_src_ffffffffc000b03b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b03b
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [0xFFFFFFFFC0608A40]
JMP .Lkd_src_ffffffffc000b042
.Lkd_runtime_ffffffffc000b03b:
POPFQ
JMP .Lkd_exit_3
.Lkd_src_ffffffffc000b042:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b042
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDI, 0xFFFFFFFFC0608E40
JMP .Lkd_src_ffffffffc000b049
.Lkd_runtime_ffffffffc000b042:
POPFQ
JMP .Lkd_exit_4
.Lkd_src_ffffffffc000b049:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b049
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             RAX, 0x1
JMP .Lkd_src_ffffffffc000b04d
.Lkd_runtime_ffffffffc000b049:
POPFQ
JMP .Lkd_exit_5
.Lkd_src_ffffffffc000b04d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b04d
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [0xFFFFFFFFC0608A40], RAX
JMP .Lkd_src_ffffffffc000b054
.Lkd_runtime_ffffffffc000b04d:
POPFQ
JMP .Lkd_exit_6
.Lkd_src_ffffffffc000b054:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b054
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RSI, R13
JMP .Lkd_src_ffffffffc000b057
.Lkd_runtime_ffffffffc000b054:
POPFQ
JMP .Lkd_exit_7
.Lkd_src_ffffffffc000b057:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b057
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          RDX, 0xFFFFFFFFC000B066
JMP .Lkd_src_ffffffffc000b05e
.Lkd_runtime_ffffffffc000b057:
POPFQ
JMP .Lkd_exit_8
.Lkd_src_ffffffffc000b05e:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b05e
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RCX, R12
JMP .Lkd_src_ffffffffc000b061
.Lkd_runtime_ffffffffc000b05e:
POPFQ
JMP .Lkd_exit_9
.Lkd_src_ffffffffc000b061:
JMP .Lkd_exit_10
.Lkd_src_ffffffffc000b066:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b066
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             RBX, R15
JMP .Lkd_src_ffffffffc000b067
.Lkd_runtime_ffffffffc000b066:
POPFQ
JMP .Lkd_exit_11
.Lkd_src_ffffffffc000b067:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b067
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 48]
MOV             R14, R15
MOV             QWORD PTR[R11 + 48], R14
JMP .Lkd_src_ffffffffc000b069
.Lkd_runtime_ffffffffc000b067:
POPFQ
JMP .Lkd_exit_12
.Lkd_src_ffffffffc000b069:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b069
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 40]
MOV             R14, R15
MOV             QWORD PTR[R11 + 40], R14
JMP .Lkd_src_ffffffffc000b06b
.Lkd_runtime_ffffffffc000b069:
POPFQ
JMP .Lkd_exit_13
.Lkd_src_ffffffffc000b06b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b06b
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 32]
MOV             R14, R15
MOV             QWORD PTR[R11 + 32], R14
JMP .Lkd_src_ffffffffc000b06d
.Lkd_runtime_ffffffffc000b06b:
POPFQ
JMP .Lkd_exit_14
.Lkd_src_ffffffffc000b06d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b06d
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 24]
MOV             R14, R15
MOV             QWORD PTR[R11 + 24], R14
JMP .Lkd_src_ffffffffc000b06f
.Lkd_runtime_ffffffffc000b06d:
POPFQ
JMP .Lkd_exit_15
.Lkd_src_ffffffffc000b06f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b06f
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R12, R15
JMP .Lkd_src_ffffffffc000b070
.Lkd_runtime_ffffffffc000b06f:
POPFQ
JMP .Lkd_exit_16
.Lkd_src_ffffffffc000b070:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b070
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EAX, EAX
JMP .Lkd_src_ffffffffc000b072
.Lkd_runtime_ffffffffc000b070:
POPFQ
JMP .Lkd_exit_17
.Lkd_src_ffffffffc000b072:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b072
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDX, EDX
JMP .Lkd_src_ffffffffc000b074
.Lkd_runtime_ffffffffc000b072:
POPFQ
JMP .Lkd_exit_18
.Lkd_src_ffffffffc000b074:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b074
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ECX, ECX
JMP .Lkd_src_ffffffffc000b076
.Lkd_runtime_ffffffffc000b074:
POPFQ
JMP .Lkd_exit_19
.Lkd_src_ffffffffc000b076:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b076
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ESI, ESI
JMP .Lkd_src_ffffffffc000b078
.Lkd_runtime_ffffffffc000b076:
POPFQ
JMP .Lkd_exit_20
.Lkd_src_ffffffffc000b078:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b078
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDI, EDI
JMP .Lkd_src_ffffffffc000b07a
.Lkd_runtime_ffffffffc000b078:
POPFQ
JMP .Lkd_exit_21
.Lkd_src_ffffffffc000b07a:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b07a
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R8D, R8D
JMP .Lkd_src_ffffffffc000b07d
.Lkd_runtime_ffffffffc000b07a:
POPFQ
JMP .Lkd_exit_22
.Lkd_src_ffffffffc000b07d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b07d
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R9D, R9D
JMP .Lkd_src_ffffffffc000b080
.Lkd_runtime_ffffffffc000b07d:
POPFQ
JMP .Lkd_exit_23
.Lkd_src_ffffffffc000b080:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b080
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R10D, R10D
JMP .Lkd_src_ffffffffc000b083
.Lkd_runtime_ffffffffc000b080:
POPFQ
JMP .Lkd_exit_24
.Lkd_src_ffffffffc000b083:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b083
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[R11 + 56]
XOR             R15d, R15d
MOV             QWORD PTR[R11 + 56], R15
JMP .Lkd_src_ffffffffc000b086
.Lkd_runtime_ffffffffc000b083:
POPFQ
JMP .Lkd_exit_25
.Lkd_src_ffffffffc000b086:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b086
DEC QWORD PTR[RBP - 120]
POPFQ
JMP .Lkd_src_ffffffff8276eee0
.Lkd_runtime_ffffffffc000b086:
POPFQ
JMP .Lkd_exit_26
.Lkd_src_ffffffffc000b0cf:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0cf
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [0xFFFFFFFFC0608A40]
JMP .Lkd_src_ffffffffc000b0d6
.Lkd_runtime_ffffffffc000b0cf:
POPFQ
JMP .Lkd_exit_27
.Lkd_src_ffffffffc000b0d6:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0d6
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RBX, QWORD PTR [0xFFFFFFFFC0608A40]
JMP .Lkd_src_ffffffffc000b0dd
.Lkd_runtime_ffffffffc000b0d6:
POPFQ
JMP .Lkd_exit_28
.Lkd_src_ffffffffc000b0dd:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0dd
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDI, 0xFFFFFFFFC0608E40
JMP .Lkd_src_ffffffffc000b0e4
.Lkd_runtime_ffffffffc000b0dd:
POPFQ
JMP .Lkd_exit_29
.Lkd_src_ffffffffc000b0e4:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0e4
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD0], RAX
JMP .Lkd_src_ffffffffc000b0e8
.Lkd_runtime_ffffffffc000b0e4:
POPFQ
JMP .Lkd_exit_30
.Lkd_src_ffffffffc000b0e8:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0e8
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [R12 + 0xFFFFFFFFFFFFFFC8], RBX
JMP .Lkd_src_ffffffffc000b0ec
.Lkd_runtime_ffffffffc000b0e8:
POPFQ
JMP .Lkd_exit_31
.Lkd_src_ffffffffc000b0ec:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0ec
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RSI, R13
JMP .Lkd_src_ffffffffc000b0ef
.Lkd_runtime_ffffffffc000b0ec:
POPFQ
JMP .Lkd_exit_32
.Lkd_src_ffffffffc000b0ef:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0ef
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          RDX, 0xFFFFFFFFC000B0FE
JMP .Lkd_src_ffffffffc000b0f6
.Lkd_runtime_ffffffffc000b0ef:
POPFQ
JMP .Lkd_exit_33
.Lkd_src_ffffffffc000b0f6:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0f6
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RCX, R12
JMP .Lkd_src_ffffffffc000b0f9
.Lkd_runtime_ffffffffc000b0f6:
POPFQ
JMP .Lkd_exit_34
.Lkd_src_ffffffffc000b0f9:
JMP .Lkd_exit_35
.Lkd_src_ffffffffc000b0fe:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b0fe
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RBX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFC8]
JMP .Lkd_src_ffffffffc000b102
.Lkd_runtime_ffffffffc000b0fe:
POPFQ
JMP .Lkd_exit_36
.Lkd_src_ffffffffc000b102:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b102
DEC QWORD PTR[RBP - 120]
POPFQ
CMP             QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD0], RBX
JMP .Lkd_src_ffffffffc000b106
.Lkd_runtime_ffffffffc000b102:
POPFQ
JMP .Lkd_exit_37
.Lkd_src_ffffffffc000b106:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b106
DEC QWORD PTR[RBP - 120]
POPFQ
SETNZ           AL
JMP .Lkd_src_ffffffffc000b109
.Lkd_runtime_ffffffffc000b106:
POPFQ
JMP .Lkd_exit_38
.Lkd_src_ffffffffc000b109:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b109
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             R13, 0x10
JMP .Lkd_src_ffffffffc000b10d
.Lkd_runtime_ffffffffc000b109:
POPFQ
JMP .Lkd_exit_39
.Lkd_src_ffffffffc000b10d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b10d
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             RBX, R15
JMP .Lkd_src_ffffffffc000b10e
.Lkd_runtime_ffffffffc000b10d:
POPFQ
JMP .Lkd_exit_40
.Lkd_src_ffffffffc000b10e:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b10e
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 48]
MOV             R14, R15
MOV             QWORD PTR[R11 + 48], R14
JMP .Lkd_src_ffffffffc000b110
.Lkd_runtime_ffffffffc000b10e:
POPFQ
JMP .Lkd_exit_41
.Lkd_src_ffffffffc000b110:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b110
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 40]
MOV             R14, R15
MOV             QWORD PTR[R11 + 40], R14
JMP .Lkd_src_ffffffffc000b112
.Lkd_runtime_ffffffffc000b110:
POPFQ
JMP .Lkd_exit_42
.Lkd_src_ffffffffc000b112:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b112
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 32]
MOV             R14, R15
MOV             QWORD PTR[R11 + 32], R14
JMP .Lkd_src_ffffffffc000b114
.Lkd_runtime_ffffffffc000b112:
POPFQ
JMP .Lkd_exit_43
.Lkd_src_ffffffffc000b114:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b114
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 24]
MOV             R14, R15
MOV             QWORD PTR[R11 + 24], R14
JMP .Lkd_src_ffffffffc000b116
.Lkd_runtime_ffffffffc000b114:
POPFQ
JMP .Lkd_exit_44
.Lkd_src_ffffffffc000b116:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b116
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R12, R15
JMP .Lkd_src_ffffffffc000b117
.Lkd_runtime_ffffffffc000b116:
POPFQ
JMP .Lkd_exit_45
.Lkd_src_ffffffffc000b117:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b117
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDX, EDX
JMP .Lkd_src_ffffffffc000b119
.Lkd_runtime_ffffffffc000b117:
POPFQ
JMP .Lkd_exit_46
.Lkd_src_ffffffffc000b119:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b119
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ECX, ECX
JMP .Lkd_src_ffffffffc000b11b
.Lkd_runtime_ffffffffc000b119:
POPFQ
JMP .Lkd_exit_47
.Lkd_src_ffffffffc000b11b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b11b
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ESI, ESI
JMP .Lkd_src_ffffffffc000b11d
.Lkd_runtime_ffffffffc000b11b:
POPFQ
JMP .Lkd_exit_48
.Lkd_src_ffffffffc000b11d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b11d
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDI, EDI
JMP .Lkd_src_ffffffffc000b11f
.Lkd_runtime_ffffffffc000b11d:
POPFQ
JMP .Lkd_exit_49
.Lkd_src_ffffffffc000b11f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b11f
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R8D, R8D
JMP .Lkd_src_ffffffffc000b122
.Lkd_runtime_ffffffffc000b11f:
POPFQ
JMP .Lkd_exit_50
.Lkd_src_ffffffffc000b122:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b122
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R9D, R9D
JMP .Lkd_src_ffffffffc000b125
.Lkd_runtime_ffffffffc000b122:
POPFQ
JMP .Lkd_exit_51
.Lkd_src_ffffffffc000b125:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b125
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R10D, R10D
JMP .Lkd_src_ffffffffc000b128
.Lkd_runtime_ffffffffc000b125:
POPFQ
JMP .Lkd_exit_52
.Lkd_src_ffffffffc000b128:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b128
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[R11 + 56]
XOR             R15d, R15d
MOV             QWORD PTR[R11 + 56], R15
JMP .Lkd_src_ffffffffc000b12b
.Lkd_runtime_ffffffffc000b128:
POPFQ
JMP .Lkd_exit_53
.Lkd_src_ffffffffc000b12b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b12b
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R15, R15
MOV             QWORD PTR[RBP - 88], R15
MOV             R14, QWORD PTR[RBP - 88]
PUSHFQ
POPFQ
JMP .Lkd_exit_55
.Lkd_runtime_ffffffffc000b12b:
POPFQ
JMP .Lkd_exit_54
.Lkd_exit_0:
MOV QWORD PTR[RBP - 72], R14
MOV QWORD PTR[RBP - 80], R14
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 6
MOV QWORD PTR[RBP - 104], 0
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_1:
MOVABS R15, 0xffffffff8276eee0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8276eee0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_2:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffff8276eee0
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 11
MOV QWORD PTR[RBP - 112], 3
JMP .Lkd_export
.Lkd_exit_3:
MOVABS R15, 0xffffffffc000b03b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b03b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_4:
MOVABS R15, 0xffffffffc000b042
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b042
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_5:
MOVABS R15, 0xffffffffc000b049
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b049
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_6:
MOVABS R15, 0xffffffffc000b04d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b04d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_7:
MOVABS R15, 0xffffffffc000b054
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b054
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_8:
MOVABS R15, 0xffffffffc000b057
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b057
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_9:
MOVABS R15, 0xffffffffc000b05e
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b05e
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_10:
MOVABS R15, 0xffffffffc000b061
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b061
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffff8152f410
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 1
MOV QWORD PTR[RBP - 104], 2
MOV QWORD PTR[RBP - 112], 1
JMP .Lkd_export
.Lkd_exit_11:
MOVABS R15, 0xffffffffc000b066
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b066
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_12:
MOVABS R15, 0xffffffffc000b067
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b067
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_13:
MOVABS R15, 0xffffffffc000b069
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b069
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_14:
MOVABS R15, 0xffffffffc000b06b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b06b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_15:
MOVABS R15, 0xffffffffc000b06d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b06d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_16:
MOVABS R15, 0xffffffffc000b06f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b06f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_17:
MOVABS R15, 0xffffffffc000b070
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b070
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_18:
MOVABS R15, 0xffffffffc000b072
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b072
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_19:
MOVABS R15, 0xffffffffc000b074
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b074
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_20:
MOVABS R15, 0xffffffffc000b076
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b076
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_21:
MOVABS R15, 0xffffffffc000b078
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b078
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_22:
MOVABS R15, 0xffffffffc000b07a
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b07a
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_23:
MOVABS R15, 0xffffffffc000b07d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b07d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_24:
MOVABS R15, 0xffffffffc000b080
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b080
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_25:
MOVABS R15, 0xffffffffc000b083
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b083
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_26:
MOVABS R15, 0xffffffffc000b086
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b086
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_27:
MOVABS R15, 0xffffffffc000b0cf
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0cf
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_28:
MOVABS R15, 0xffffffffc000b0d6
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0d6
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_29:
MOVABS R15, 0xffffffffc000b0dd
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0dd
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_30:
MOVABS R15, 0xffffffffc000b0e4
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0e4
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_31:
MOVABS R15, 0xffffffffc000b0e8
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0e8
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_32:
MOVABS R15, 0xffffffffc000b0ec
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0ec
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_33:
MOVABS R15, 0xffffffffc000b0ef
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0ef
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_34:
MOVABS R15, 0xffffffffc000b0f6
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0f6
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_35:
MOVABS R15, 0xffffffffc000b0f9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0f9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffff8152f410
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 1
MOV QWORD PTR[RBP - 104], 2
MOV QWORD PTR[RBP - 112], 1
JMP .Lkd_export
.Lkd_exit_36:
MOVABS R15, 0xffffffffc000b0fe
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b0fe
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_37:
MOVABS R15, 0xffffffffc000b102
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b102
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_38:
MOVABS R15, 0xffffffffc000b106
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b106
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_39:
MOVABS R15, 0xffffffffc000b109
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b109
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_40:
MOVABS R15, 0xffffffffc000b10d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b10d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_41:
MOVABS R15, 0xffffffffc000b10e
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b10e
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_42:
MOVABS R15, 0xffffffffc000b110
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b110
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_43:
MOVABS R15, 0xffffffffc000b112
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b112
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_44:
MOVABS R15, 0xffffffffc000b114
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b114
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_45:
MOVABS R15, 0xffffffffc000b116
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b116
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_46:
MOVABS R15, 0xffffffffc000b117
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b117
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_47:
MOVABS R15, 0xffffffffc000b119
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b119
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_48:
MOVABS R15, 0xffffffffc000b11b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b11b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_49:
MOVABS R15, 0xffffffffc000b11d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b11d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_50:
MOVABS R15, 0xffffffffc000b11f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b11f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_51:
MOVABS R15, 0xffffffffc000b122
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b122
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_52:
MOVABS R15, 0xffffffffc000b125
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b125
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_53:
MOVABS R15, 0xffffffffc000b128
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b128
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_54:
MOVABS R15, 0xffffffffc000b12b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b12b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_55:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffffc000b12b
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 11
MOV QWORD PTR[RBP - 112], 3
JMP .Lkd_export


.Lkd_export:
	/* The generated exit has already flushed mapped source GPRs, recovered
	 * physical R12/R13 as BP/SP and written the exact control result slots.
	 * Save all resident source values before reusing RAX/R14 for control. */
	mov QWORD PTR[R11 + 16], r12
	mov QWORD PTR[R11 + 8], r13
	mov QWORD PTR[R11 + 64], rbx
	mov QWORD PTR[R11 + 72], r10
	mov QWORD PTR[R11 + 80], r9
	mov QWORD PTR[R11 + 88], r8
	mov QWORD PTR[R11 + 96], rax
	mov QWORD PTR[R11 + 104], rcx
	mov QWORD PTR[R11 + 112], rdx
	mov QWORD PTR[R11 + 120], rsi
	mov QWORD PTR[R11 + 128], rdi
	mov rax, QWORD PTR[RBP - 72]
	mov QWORD PTR[R11 + 0], rax
	mov r14, QWORD PTR[RBP - 64]
	mov rax, QWORD PTR[RBP - 96]
	mov QWORD PTR[r14 + 16], rax
	mov rax, QWORD PTR[RBP - 104]
	mov QWORD PTR[r14 + 24], rax
	mov rax, QWORD PTR[RBP - 80]
	mov QWORD PTR[r14 + 32], rax
	mov rax, QWORD PTR[RBP - 88]
	mov QWORD PTR[r14 + 40], rax
	mov rax, QWORD PTR[RBP - 112]
	mov QWORD PTR[r14 + 48], rax
	/* Keep all private slots allocated through their final read. Returning
	 * publishes no ownership transfer by itself; lock code owns that order. */
	lea rsp, [rbp - 40]
	pop r15
	pop r14
	pop r13
	pop r12
	pop rbx
	pop rbp
	ret
	.size kd_nano_entry, .-kd_nano_entry
	.section .note.GNU-stack, "", @progbits
