#!/usr/bin/env python3
"""Profile ordinary mutex workers in a dedicated, otherwise idle guest session."""
import argparse
import collections
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile

ROOT = Path('/mnt/kdlock-builds2/main-spin-local-4669a085-20261117')
REPO = ROOT / 'main-final-repo'
VMLINUX = ROOT / 'main-final-out/vmlinux'
PERF = '/usr/bin/perf'
RELEASE = '7.0.0-38-kdlocalspin6'
BOOT = 'fc8104fd-5e0c-406f-b93e-e7c6e6cabf6d'
SOURCE = '18dad4a1c372d77a1155db671d56c148918344da'
SIGNED_SHA = 'e91e6a66f077fc2d59d6f682ccdf3125fa97889de1e7f583d715d5008bb656c7'
NANO_SHA = 'f2b8df01d4a8909bdf4cdf4379a2cbc7d3671f5443aa766eae20cfe800589637'
PROVIDERS = [('spin','tclock_backend_km'), ('mutex','tclock_mutex_backend_km'),
             ('rwlock','tclock_rwlock_backend_km'), ('rwsem','tclock_rwsem_backend_km')]
MODULES = [REPO / 'local-tclock' / family / (name+'.ko') for family, name in PROVIDERS]
MODULES.append(REPO / 'bench/kd_bench.ko')
COUNTS = ('offered','delegated','handback','sessions')
MS = 3000


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(path):
    return Path(path).read_text().strip()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def stats():
    return {k:int(v) for k,v in (line.split() for line in read('/sys/kernel/debug/kdlock_stats').splitlines())}


def modules():
    return {line.split()[0] for line in read('/proc/modules').splitlines()}


def guest():
    check(os.uname().release == RELEASE and read('/proc/sys/kernel/random/boot_id') == BOOT,
          'running kernel or boot ID differs')
    for disk, serial in [('vda','kd16-root'), ('vdb','kd16-builds-current')]:
        check(read('/sys/class/block/'+disk+'/serial') == serial, 'unexpected '+disk+' serial')


def check_idle():
    # Run only after the preceding live test has drained. Do not unload in use.
    active = []
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if int(proc.name) == os.getpid():
                continue
            comm = read(proc / 'comm')
            argv = [os.fsdecode(arg) for arg in (proc/'cmdline').read_bytes().split(b'\0') if arg]
            filenames = [os.path.basename(arg) for arg in argv if len(arg)<512]
            scripts = ('run_nano.py','run_grid.py','run_corr.py','kd_daemon.py','run_oversub.py')
            if (comm.startswith(('kdb/','locktorture','will-it-scale')) or comm in ('perf','make','cc1')
                    or any(name in scripts or (name.startswith('main-mutex-') and name.endswith('.py'))
                           for name in filenames)):
                active.append((proc.name,comm))
                continue
            for fd in (proc/'fd').iterdir():
                try:
                    if os.readlink(fd) in ('/dev/kdbench','/dev/kdlock'):
                        active.append((proc.name,comm))
                        break
                except FileNotFoundError:
                    pass
        except (FileNotFoundError,ProcessLookupError):
            pass
    check(not active, 'tasks have not drained: '+repr(active))


def command(folder, label, args, timeout=45, keep_stdout=True):
    args = list(map(str,args))
    save(folder/(label+'.argv.json'),args)
    try:
        p = subprocess.run(args, capture_output=True, text=True, errors='replace', timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        (folder/(label+'.err')).write_bytes(exc.stderr or b'')
        raise RuntimeError('command timed out; drain must be confirmed: '+label) from exc
    (folder/(label+'.err')).write_text(p.stderr)
    if keep_stdout or p.returncode:
        (folder/(label+'.txt')).write_text(p.stdout)
    check(p.returncode == 0, f'{label} returned {p.returncode}: {p.stderr.strip()[:500]} {p.stdout.strip()[:250]}')
    return p.stdout


def kernel_log(folder, label):
    log = command(folder,label,['dmesg'])
    check(not re.search(r'BUG:|WARNING:|soft lockup|hard LOCKUP|Oops:',log),'kernel warning in '+label)


def quiescent(loaded):
    for _,name in PROVIDERS:
        if name in loaded:
            check(read('/sys/module/'+name+'/parameters/quiescent') == '1', name+' has active work')


def task(backend, workers, ms, dest):
    sys.path.insert(0,str(REPO/'bench'))
    import run_nano as n
    guest()
    before = stats()
    check(before['delegation'] == 0,'delegation enabled')
    values = (n.FAMILY['mutex'],n.BACKEND[backend],1,100,256,workers,0,ms,workers,0)
    data = bytearray(struct.calcsize(n.RUN_FMT))
    struct.pack_into(n.IN_FMT,data,0,*values)
    with open('/dev/kdbench','r+b',buffering=0) as f:
        fcntl.ioctl(f,n.IOC,data,True)
    after = stats()
    reply = struct.unpack(n.RUN_FMT,data)
    elapsed,ops,writes,bad,delta = reply[10:15]
    per_worker = list(reply[15:15+workers])
    per_writer = list(reply[15+n.MAXW:15+n.MAXW+workers])
    diffs = {k:after[k]-v for k,v in before.items() if k!='delegation'}
    ok = (elapsed > 0 and all(per_worker) and sum(per_worker)==ops==writes==delta
          and per_worker==per_writer and bad==0 and after['delegation']==0
          and all(diffs[k]==0 for k in COUNTS))
    save(dest,dict(ok=ok,backend=backend,workers=workers,lines=1,post=256,family='mutex',
                   ms=ms,elapsed_ns=elapsed,ops=ops,writes=writes,torn_reads=bad,sum_delta=delta,
                   worker_ops=per_worker,worker_writes=per_writer,kd_delta=diffs,
                   delegation=after['delegation']))
    check(ok,'worker correctness or execution counters failed')


def kernel_build_id():
    notes = Path('/sys/kernel/notes').read_bytes()
    pos = 0
    while pos+12 <= len(notes):
        namesz,descsz,kind = struct.unpack_from('<III', notes, pos)
        pos += 12
        name = notes[pos:pos+namesz].rstrip(b'\0')
        pos += (namesz+3)&~3
        desc = notes[pos:pos+descsz]
        pos += (descsz+3)&~3
        if name == b'GNU' and kind == 3:
            return desc.hex()
    raise RuntimeError('cannot identify running vmlinux build ID')


def analyze(folder,data,workers):
    cpus = list(range(workers))
    names = ['kdb/%d.0'%i for i in cpus]
    base = ['-i',data,'--vmlinux',VMLINUX]
    raw = command(folder,'record-dump',[PERF,'report','-D','--stdio',*base],keep_stdout=False)
    lost = [line.strip() for line in raw.splitlines() if 'PERF_RECORD_LOST' in line]
    sample_records = sum('PERF_RECORD_SAMPLE(' in line or 'PERF_RECORD_SAMPLE ' in line
                         for line in raw.splitlines())
    # perf script reports each sample independently, including unknown symbols.
    script = command(folder,'worker-samples',[PERF,'script',*base,'-F','comm,ip,sym,dso'],
                     keep_stdout=False)
    command(folder,'worker-report',[PERF,'report','--stdio','-n','--percent-limit','0',
                                    '--comms',','.join(names),'--percentage','relative',
                                    '--sort','dso,symbol',*base])
    all_comms = collections.Counter()
    by_worker = collections.Counter()
    by_symbol = collections.Counter()
    worker_ips = collections.Counter()
    unresolved = 0
    unparsed = []
    for line in script.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        sample = re.match(r'^\s*(.*?)\s+([0-9a-fA-F]+)\s+(.*?)\s+\((.*)\)\s*$',line)
        if not sample:
            unparsed.append(line)
            continue
        comm,ip,symbol,dso = sample.groups()
        all_comms[comm] += 1
        if comm in names:
            by_worker[comm] += 1
            by_symbol[(dso,symbol)] += 1
            worker_ips[(symbol,ip)] += 1
            if not symbol or symbol in ('[unknown]','unknown') or re.fullmatch(r'(?:0x)?[0-9a-fA-F]{8,}',symbol):
                unresolved += 1
    count = sum(by_worker.values())
    save(folder/'samples.json',dict(event='cpu-clock:k',frequency_hz=199,expected_workers=names,
         all_cpu_samples=sum(all_comms.values()),comm_samples=all_comms,worker_samples=count,
         worker_counts=by_worker,unresolved_worker_samples=unresolved,raw_sample_records=sample_records,
         lost_records=lost,unparsed_count=len(unparsed),unparsed_examples=unparsed[:8],
         worker_symbols=[dict(dso=d,symbol=s,samples=n,fraction_of_worker_samples=n/count)
                         for (d,s),n in by_symbol.most_common()],
         top_worker_ips=[dict(symbol=s,ip=ip,samples=n) for (s,ip),n in worker_ips.most_common(25)]))
    check(not lost and not unparsed and set(by_worker)==set(names),'worker sample coverage or lost record')
    check(sample_records==sum(all_comms.values()),'sample counts disagree with raw records')
    check(unresolved < count,'no resolved worker symbols')


def main(out):
    guest()
    out.mkdir(exist_ok=False)
    loaded = []
    initial = modules()
    outcome = {'complete':False,'boot_id':BOOT,'release':RELEASE,'source':SOURCE,'points':[]}
    try:
        command(out,'perf-version',[PERF,'--version'])
        os.sched_setaffinity(0,{38,39})
        check_idle()
        check(initial <= {'nls_iso8859_1'},'unexpected loaded modules: '+repr(initial))
        check(read('/sys/kernel/debug/tracing/current_tracer')=='nop','active tracer')
        check(int(read('/proc/sys/kernel/tainted')) in (0,4096),'unexpected kernel taint')
        check(stats()['delegation']==0,'daemon or images active')
        check(command(out,'system-jobs',['systemctl','list-jobs','--no-legend','--plain','--no-pager']).strip()
              in ('','No jobs running.'),'pending guest jobs')
        kernel_log(out,'dmesg-before')
        check(shutil.disk_usage(ROOT).free > 64*1024*1024,'build disk cannot hold temporary profiles')
        check(VMLINUX.is_file(),'matching vmlinux unavailable')
        kernel_id = kernel_build_id()
        notes = command(out,'vmlinux-notes',['readelf','-n',VMLINUX])
        check(re.search(r'Build ID:\s*'+kernel_id+r'\b',notes), 'vmlinux build ID mismatch')
        signed_file = ROOT/'signed-artifacts-main-final.json'
        check(sha(signed_file)==SIGNED_SHA,'signed artifact receipt differs')
        signed = json.loads(signed_file.read_text())
        expected = {Path(row['path']):row['signed_sha256'] for row in signed['modules']}
        hashes = {str(p):sha(p) for p in MODULES}
        check(signed['release']==RELEASE and all(hashes[str(p)]==expected[p] for p in MODULES),
              'module or release differs')
        check(sha(REPO/'bench/run_nano.py')==NANO_SHA,'benchmark ioctl definitions differ')
        check(json.loads((ROOT/'main-final-identity.json').read_text())['commit']==SOURCE,'source differs')
        save(out/'identity.json',dict(boot_id=BOOT,release=RELEASE,build=os.uname().version,
             source=SOURCE,vmlinux=str(VMLINUX),vmlinux_build_id=kernel_id,module_sha256=hashes,
             initial_modules=sorted(initial),delegation=stats()['delegation'],cpus=read('/sys/devices/system/cpu/online'),
             perf_event_paranoid=read('/proc/sys/kernel/perf_event_paranoid')))
        with tempfile.TemporaryDirectory(prefix='mutex-samples-',dir=ROOT) as tmp:
            # Verify the software event before inserting benchmark modules.
            command(out,'event-check',[PERF,'record','--no-buildid-cache','-e','cpu-clock:k','-F','199',
                                       '-C','0','-o',Path(tmp)/'event.data','--','sleep','0.2'])
            for module in MODULES:
                command(out,'insmod-'+module.stem,['insmod',module])
                loaded.append(module.stem)
            quiescent(loaded)
            for workers,backend in [(3,'native'),(3,'kd'),(5,'kd'),(5,'native')]:
                folder = out/(backend+'-'+str(workers))
                folder.mkdir()
                child = [sys.executable,'-B',Path(__file__).resolve(),'--measure',backend,str(workers)]
                command(folder,'warmup',child+['300',folder/'warmup.json'])
                data = Path(tmp)/(folder.name+'.data')
                command(folder,'record',[PERF,'record','--no-buildid-cache','-e','cpu-clock:k','-F','199',
                                         '-C',f'0-{workers-1}','-o',data,'--',*child,str(MS),folder/'work.json'])
                check(json.loads((folder/'work.json').read_text())['ok'],'profiled benchmark did not finish')
                analyze(folder,data,workers)
                quiescent(loaded)
                kernel_log(folder,'dmesg')
                outcome['points'].append(folder.name)
        outcome['complete']=True
    except Exception as exc:
        outcome['reason']=str(exc)
    finally:
        try:
            if loaded:
                check_idle()
                quiescent(loaded)
                while loaded:
                    name=loaded[-1]
                    command(out,'rmmod-'+name,['rmmod',name])
                    loaded.pop()
            guest()
            check(modules()==initial and stats()['delegation']==0,'final guest state differs')
            kernel_log(out,'dmesg-after')
        except Exception as exc:
            outcome['cleanup_error']=str(exc)
            outcome['complete']=False
        outcome['remaining_owned_modules']=loaded
        outcome['final_modules']=sorted(modules())
        save(out/'status.json',outcome)
    print(json.dumps(outcome),flush=True)
    return 0 if outcome['complete'] else 1


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--output',type=Path,help='fresh independent guest evidence directory')
    mode.add_argument('--measure',nargs=4,metavar=('BACKEND','WORKERS','MS','RESULT'),help=argparse.SUPPRESS)
    a=ap.parse_args()
    if a.measure:
        be,w,ms,path=a.measure
        check(be in ('native','kd') and w in ('3','5') and int(ms) in (300,MS),'unexpected profile point')
        task(be,int(w),int(ms),Path(path))
    else:
        raise SystemExit(main(a.output))
