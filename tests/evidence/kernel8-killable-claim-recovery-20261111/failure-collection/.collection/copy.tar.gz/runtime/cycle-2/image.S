/* SPDX-License-Identifier: GPL-2.0-only */
/* Per-image entry template for the original UB-derived KD mapping. Lowering
 * substitutes kd_fixture_entry and KD_GENERATED_BODY for one image's own code.
 * All source state remains in its original thread's one canonical packet.
 * The caller supplies fresh origin GS/task inputs, exclusive source execution,
 * valid source/code bindings and the declared sleepable physical context.
 * The distinct executor's native stack and all origin waiting/control stacks
 * must be admitted disjoint from the stopped source stack; this template does
 * not establish or allocate that context and cannot execute an origin's own
 * source on overlapping native frames.
 * General flags/SIMD use AS01; this unrun wrapper is no equivalence evidence.
 */


	.intel_syntax noprefix
	.text
	.p2align 4
	.globl kd_fixture_entry
	.type kd_fixture_entry, @function
kd_fixture_entry:
	endbr64
	/* Preserve the executor's native callee-saved state. Logical source
	 * BP/SP are separate and never replace physical RBP/RSP here. */
	push rbp
	mov rbp, rsp
	push rbx
	push r12
	push r13
	push r14
	push r15
	/* Allocate every private slot before stores, without using a red zone
	 * or changing the assumed source flags during packet import. */
	lea rsp, [rsp - 80]
	mov QWORD PTR[RBP - 64], rsi
	mov R11, rdi
	mov r14, QWORD PTR[rsi + 0]
	mov QWORD PTR[RBP - 48], r14
	mov r14, QWORD PTR[rsi + 8]
	mov QWORD PTR[RBP - 56], r14
	/* Source R11--R15 already have canonical backing. Only the resident
	 * source GPRs and stable BP/SP caches need importing. */
	mov rbx, QWORD PTR[R11 + 64]
	mov r10, QWORD PTR[R11 + 72]
	mov r9, QWORD PTR[R11 + 80]
	mov r8, QWORD PTR[R11 + 88]
	mov rax, QWORD PTR[R11 + 96]
	mov rcx, QWORD PTR[R11 + 104]
	mov rdx, QWORD PTR[R11 + 112]
	mov rsi, QWORD PTR[R11 + 120]
	mov rdi, QWORD PTR[R11 + 128]
	mov r12, QWORD PTR[R11 + 16]
	mov r13, QWORD PTR[R11 + 8]
	jmp .Lkd_dispatch

.Lkd_dispatch:
MOVABS R14, 4000
MOV QWORD PTR[RBP - 120], R14
MOV R14, QWORD PTR[R11 + 0]
PUSHFQ
MOVABS R15, 0xffffffffc000b39e
CMP R14, R15
JE .Lkd_enter_ffffffffc000b39e
MOVABS R15, 0xffffffffc000b407
CMP R14, R15
JE .Lkd_enter_ffffffffc000b407
MOVABS R15, 0xffffffffc000b48e
CMP R14, R15
JE .Lkd_enter_ffffffffc000b48e
MOVABS R15, 0xffffffffc000b504
CMP R14, R15
JE .Lkd_enter_ffffffffc000b504
POPFQ
JMP .Lkd_exit_0
.Lkd_enter_ffffffffc000b39e:
POPFQ
JMP .Lkd_src_ffffffffc000b39e
.Lkd_enter_ffffffffc000b407:
POPFQ
JMP .Lkd_src_ffffffffc000b407
.Lkd_enter_ffffffffc000b48e:
POPFQ
JMP .Lkd_src_ffffffffc000b48e
.Lkd_enter_ffffffffc000b504:
POPFQ
JMP .Lkd_src_ffffffffc000b504
.Lkd_src_ffffffffc000b010:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b010
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [RDI + 0x90]
JMP .Lkd_src_ffffffffc000b017
.Lkd_runtime_ffffffffc000b010:
POPFQ
JMP .Lkd_exit_1
.Lkd_src_ffffffffc000b017:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b017
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             RAX, 0x1
JMP .Lkd_src_ffffffffc000b01b
.Lkd_runtime_ffffffffc000b017:
POPFQ
JMP .Lkd_exit_2
.Lkd_src_ffffffffc000b01b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b01b
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [RDI + 0x90], RAX
JMP .Lkd_src_ffffffffc000b022
.Lkd_runtime_ffffffffc000b01b:
POPFQ
JMP .Lkd_exit_3
.Lkd_src_ffffffffc000b022:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b022
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EAX, EAX
JMP .Lkd_src_ffffffffc000b024
.Lkd_runtime_ffffffffc000b022:
POPFQ
JMP .Lkd_exit_4
.Lkd_src_ffffffffc000b024:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b024
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDI, EDI
JMP .Lkd_src_ffffffffc000b026
.Lkd_runtime_ffffffffc000b024:
POPFQ
JMP .Lkd_exit_5
.Lkd_src_ffffffffc000b026:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b026
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R15, R15
MOV             QWORD PTR[RBP - 88], R15
MOV             R14, QWORD PTR[RBP - 88]
PUSHFQ
MOVABS R15, 0xffffffffc000b4c9
CMP R14, R15
JE .Lkd_ret_ffffffffc000b026_ffffffffc000b4c9
POPFQ
JMP .Lkd_exit_7
.Lkd_ret_ffffffffc000b026_ffffffffc000b4c9:
POPFQ
JMP .Lkd_src_ffffffffc000b4c9
.Lkd_runtime_ffffffffc000b026:
POPFQ
JMP .Lkd_exit_6
.Lkd_src_ffffffffc000b39e:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b39e
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RBX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD0]
JMP .Lkd_src_ffffffffc000b3a2
.Lkd_runtime_ffffffffc000b39e:
POPFQ
JMP .Lkd_exit_8
.Lkd_src_ffffffffc000b3a2:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3a2
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             DWORD PTR [R12 + 0xFFFFFFFFFFFFFFCC], EAX
JMP .Lkd_src_ffffffffc000b3a5
.Lkd_runtime_ffffffffc000b3a2:
POPFQ
JMP .Lkd_exit_9
.Lkd_src_ffffffffc000b3a5:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3a5
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             DWORD PTR [RBX + 0x7C], EAX
JMP .Lkd_src_ffffffffc000b3a8
.Lkd_runtime_ffffffffc000b3a5:
POPFQ
JMP .Lkd_exit_10
.Lkd_src_ffffffffc000b3a8:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3a8
DEC QWORD PTR[RBP - 120]
POPFQ
TEST            EAX, EAX
JMP .Lkd_src_ffffffffc000b3aa
.Lkd_runtime_ffffffffc000b3a8:
POPFQ
JMP .Lkd_exit_11
.Lkd_src_ffffffffc000b3aa:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3aa
DEC QWORD PTR[RBP - 120]
POPFQ
JNZ .Lkd_taken_ffffffffc000b3aa
JMP .Lkd_src_ffffffffc000b3ac
.Lkd_taken_ffffffffc000b3aa:
JMP .Lkd_src_ffffffffc000b407
.Lkd_runtime_ffffffffc000b3aa:
POPFQ
JMP .Lkd_exit_12
.Lkd_src_ffffffffc000b3ac:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3ac
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[RBP - 56]
MOV             RAX, R15
JMP .Lkd_src_ffffffffc000b3b4
.Lkd_runtime_ffffffffc000b3ac:
POPFQ
JMP .Lkd_exit_13
.Lkd_src_ffffffffc000b3b4:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3b4
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDI, RBX
JMP .Lkd_src_ffffffffc000b3b7
.Lkd_runtime_ffffffffc000b3b4:
POPFQ
JMP .Lkd_exit_14
.Lkd_src_ffffffffc000b3b7:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3b7
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [RBX + 0xB0], RAX
JMP .Lkd_src_ffffffffc000b3be
.Lkd_runtime_ffffffffc000b3b7:
POPFQ
JMP .Lkd_exit_15
.Lkd_src_ffffffffc000b3be:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3be
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [RBX + 0x88]
JMP .Lkd_src_ffffffffc000b3c5
.Lkd_runtime_ffffffffc000b3be:
POPFQ
JMP .Lkd_exit_16
.Lkd_src_ffffffffc000b3c5:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3c5
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             RAX, 0x1
JMP .Lkd_src_ffffffffc000b3c9
.Lkd_runtime_ffffffffc000b3c5:
POPFQ
JMP .Lkd_exit_17
.Lkd_src_ffffffffc000b3c9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3c9
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [RBX + 0x88], RAX
JMP .Lkd_src_ffffffffc000b3d0
.Lkd_runtime_ffffffffc000b3c9:
POPFQ
JMP .Lkd_exit_18
.Lkd_src_ffffffffc000b3d0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3d0
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [0xFFFFFFFFC060A268]
JMP .Lkd_src_ffffffffc000b3d7
.Lkd_runtime_ffffffffc000b3d0:
POPFQ
JMP .Lkd_exit_19
.Lkd_src_ffffffffc000b3d7:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b3d7
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          R15, 0xFFFFFFFFC000B3DC
MOV             R15, R15
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
MOVABS          R14, 0xffffffffc000e020
JMP .Lkd_src_ffffffffc000e020
.Lkd_runtime_ffffffffc000b3d7:
POPFQ
JMP .Lkd_exit_20
.Lkd_src_ffffffffc000b407:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b407
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             EAX, DWORD PTR [R12 + 0xFFFFFFFFFFFFFFCC]
JMP .Lkd_src_ffffffffc000b40a
.Lkd_runtime_ffffffffc000b407:
POPFQ
JMP .Lkd_exit_21
.Lkd_src_ffffffffc000b40a:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b40a
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             R13, 0x10
JMP .Lkd_src_ffffffffc000b40e
.Lkd_runtime_ffffffffc000b40a:
POPFQ
JMP .Lkd_exit_22
.Lkd_src_ffffffffc000b40e:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b40e
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             RBX, R15
JMP .Lkd_src_ffffffffc000b40f
.Lkd_runtime_ffffffffc000b40e:
POPFQ
JMP .Lkd_exit_23
.Lkd_src_ffffffffc000b40f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b40f
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 48]
MOV             R14, R15
MOV             QWORD PTR[R11 + 48], R14
JMP .Lkd_src_ffffffffc000b411
.Lkd_runtime_ffffffffc000b40f:
POPFQ
JMP .Lkd_exit_24
.Lkd_src_ffffffffc000b411:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b411
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 40]
MOV             R14, R15
MOV             QWORD PTR[R11 + 40], R14
JMP .Lkd_src_ffffffffc000b413
.Lkd_runtime_ffffffffc000b411:
POPFQ
JMP .Lkd_exit_25
.Lkd_src_ffffffffc000b413:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b413
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 32]
MOV             R14, R15
MOV             QWORD PTR[R11 + 32], R14
JMP .Lkd_src_ffffffffc000b415
.Lkd_runtime_ffffffffc000b413:
POPFQ
JMP .Lkd_exit_26
.Lkd_src_ffffffffc000b415:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b415
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 24]
MOV             R14, R15
MOV             QWORD PTR[R11 + 24], R14
JMP .Lkd_src_ffffffffc000b417
.Lkd_runtime_ffffffffc000b415:
POPFQ
JMP .Lkd_exit_27
.Lkd_src_ffffffffc000b417:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b417
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R12, R15
JMP .Lkd_src_ffffffffc000b418
.Lkd_runtime_ffffffffc000b417:
POPFQ
JMP .Lkd_exit_28
.Lkd_src_ffffffffc000b418:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b418
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDX, EDX
JMP .Lkd_src_ffffffffc000b41a
.Lkd_runtime_ffffffffc000b418:
POPFQ
JMP .Lkd_exit_29
.Lkd_src_ffffffffc000b41a:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b41a
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ECX, ECX
JMP .Lkd_src_ffffffffc000b41c
.Lkd_runtime_ffffffffc000b41a:
POPFQ
JMP .Lkd_exit_30
.Lkd_src_ffffffffc000b41c:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b41c
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ESI, ESI
JMP .Lkd_src_ffffffffc000b41e
.Lkd_runtime_ffffffffc000b41c:
POPFQ
JMP .Lkd_exit_31
.Lkd_src_ffffffffc000b41e:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b41e
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDI, EDI
JMP .Lkd_src_ffffffffc000b420
.Lkd_runtime_ffffffffc000b41e:
POPFQ
JMP .Lkd_exit_32
.Lkd_src_ffffffffc000b420:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b420
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R8D, R8D
JMP .Lkd_src_ffffffffc000b423
.Lkd_runtime_ffffffffc000b420:
POPFQ
JMP .Lkd_exit_33
.Lkd_src_ffffffffc000b423:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b423
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R9D, R9D
JMP .Lkd_src_ffffffffc000b426
.Lkd_runtime_ffffffffc000b423:
POPFQ
JMP .Lkd_exit_34
.Lkd_src_ffffffffc000b426:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b426
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R10D, R10D
JMP .Lkd_src_ffffffffc000b429
.Lkd_runtime_ffffffffc000b426:
POPFQ
JMP .Lkd_exit_35
.Lkd_src_ffffffffc000b429:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b429
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[R11 + 56]
XOR             R15d, R15d
MOV             QWORD PTR[R11 + 56], R15
JMP .Lkd_src_ffffffffc000b42c
.Lkd_runtime_ffffffffc000b429:
POPFQ
JMP .Lkd_exit_36
.Lkd_src_ffffffffc000b42c:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b42c
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R15, R15
MOV             QWORD PTR[RBP - 88], R15
MOV             R14, QWORD PTR[RBP - 88]
PUSHFQ
POPFQ
JMP .Lkd_exit_38
.Lkd_runtime_ffffffffc000b42c:
POPFQ
JMP .Lkd_exit_37
.Lkd_src_ffffffffc000b48e:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b48e
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[RBP - 56]
MOV             RAX, R15
JMP .Lkd_src_ffffffffc000b496
.Lkd_runtime_ffffffffc000b48e:
POPFQ
JMP .Lkd_exit_39
.Lkd_src_ffffffffc000b496:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b496
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RBX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD0]
JMP .Lkd_src_ffffffffc000b49a
.Lkd_runtime_ffffffffc000b496:
POPFQ
JMP .Lkd_exit_40
.Lkd_src_ffffffffc000b49a:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b49a
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             DWORD PTR [RBX + 0x7C], 0x0
JMP .Lkd_src_ffffffffc000b4a1
.Lkd_runtime_ffffffffc000b49a:
POPFQ
JMP .Lkd_exit_41
.Lkd_src_ffffffffc000b4a1:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4a1
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDI, RBX
JMP .Lkd_src_ffffffffc000b4a4
.Lkd_runtime_ffffffffc000b4a1:
POPFQ
JMP .Lkd_exit_42
.Lkd_src_ffffffffc000b4a4:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4a4
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [RBX + 0xB0], RAX
JMP .Lkd_src_ffffffffc000b4ab
.Lkd_runtime_ffffffffc000b4a4:
POPFQ
JMP .Lkd_exit_43
.Lkd_src_ffffffffc000b4ab:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4ab
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [RBX + 0x88]
JMP .Lkd_src_ffffffffc000b4b2
.Lkd_runtime_ffffffffc000b4ab:
POPFQ
JMP .Lkd_exit_44
.Lkd_src_ffffffffc000b4b2:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4b2
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             RAX, 0x1
JMP .Lkd_src_ffffffffc000b4b6
.Lkd_runtime_ffffffffc000b4b2:
POPFQ
JMP .Lkd_exit_45
.Lkd_src_ffffffffc000b4b6:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4b6
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [RBX + 0x88], RAX
JMP .Lkd_src_ffffffffc000b4bd
.Lkd_runtime_ffffffffc000b4b6:
POPFQ
JMP .Lkd_exit_46
.Lkd_src_ffffffffc000b4bd:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4bd
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [0xFFFFFFFFC060A268]
JMP .Lkd_src_ffffffffc000b4c4
.Lkd_runtime_ffffffffc000b4bd:
POPFQ
JMP .Lkd_exit_47
.Lkd_src_ffffffffc000b4c4:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4c4
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          R15, 0xFFFFFFFFC000B4C9
MOV             R15, R15
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
MOVABS          R14, 0xffffffffc000e023
JMP .Lkd_src_ffffffffc000e023
.Lkd_runtime_ffffffffc000b4c4:
POPFQ
JMP .Lkd_exit_48
.Lkd_src_ffffffffc000b4c9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4c9
DEC QWORD PTR[RBP - 120]
POPFQ
MOVZX           EBX, BYTE PTR [RBX + 0x78]
JMP .Lkd_src_ffffffffc000b4cd
.Lkd_runtime_ffffffffc000b4c9:
POPFQ
JMP .Lkd_exit_49
.Lkd_src_ffffffffc000b4cd:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4cd
DEC QWORD PTR[RBP - 120]
POPFQ
CMP             BL, 0x1
JMP .Lkd_src_ffffffffc000b4d0
.Lkd_runtime_ffffffffc000b4cd:
POPFQ
JMP .Lkd_exit_50
.Lkd_src_ffffffffc000b4d0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4d0
DEC QWORD PTR[RBP - 120]
POPFQ
JA .Lkd_taken_ffffffffc000b4d0
JMP .Lkd_src_ffffffffc000b4d6
.Lkd_taken_ffffffffc000b4d0:
JMP .Lkd_exit_52
.Lkd_runtime_ffffffffc000b4d0:
POPFQ
JMP .Lkd_exit_51
.Lkd_src_ffffffffc000b4d6:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4d6
DEC QWORD PTR[RBP - 120]
POPFQ
AND             EBX, 0x1
JMP .Lkd_src_ffffffffc000b4d9
.Lkd_runtime_ffffffffc000b4d6:
POPFQ
JMP .Lkd_exit_53
.Lkd_src_ffffffffc000b4d9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4d9
DEC QWORD PTR[RBP - 120]
POPFQ
JZ .Lkd_taken_ffffffffc000b4d9
JMP .Lkd_src_ffffffffc000b4db
.Lkd_taken_ffffffffc000b4d9:
JMP .Lkd_src_ffffffffc000b4eb
.Lkd_runtime_ffffffffc000b4d9:
POPFQ
JMP .Lkd_exit_54
.Lkd_src_ffffffffc000b4db:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4db
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [0xFFFFFFFFC060A260]
JMP .Lkd_src_ffffffffc000b4e2
.Lkd_runtime_ffffffffc000b4db:
POPFQ
JMP .Lkd_exit_55
.Lkd_src_ffffffffc000b4e2:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4e2
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDI, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD0]
JMP .Lkd_src_ffffffffc000b4e6
.Lkd_runtime_ffffffffc000b4e2:
POPFQ
JMP .Lkd_exit_56
.Lkd_src_ffffffffc000b4e6:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4e6
DEC QWORD PTR[RBP - 120]
POPFQ
PUSH            RAX
MOV             RAX, RAX
MOV             QWORD PTR[RBP - 88], RAX
POP             RAX
MOV R14, QWORD PTR[RBP - 88]
JMP .Lkd_exit_58
.Lkd_runtime_ffffffffc000b4e6:
POPFQ
JMP .Lkd_exit_57
.Lkd_src_ffffffffc000b4eb:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4eb
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDI, 0xFFFFFFFFC0606120
JMP .Lkd_src_ffffffffc000b4f2
.Lkd_runtime_ffffffffc000b4eb:
POPFQ
JMP .Lkd_exit_59
.Lkd_src_ffffffffc000b4f2:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4f2
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RSI, R13
JMP .Lkd_src_ffffffffc000b4f5
.Lkd_runtime_ffffffffc000b4f2:
POPFQ
JMP .Lkd_exit_60
.Lkd_src_ffffffffc000b4f5:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4f5
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          RDX, 0xFFFFFFFFC000B504
JMP .Lkd_src_ffffffffc000b4fc
.Lkd_runtime_ffffffffc000b4f5:
POPFQ
JMP .Lkd_exit_61
.Lkd_src_ffffffffc000b4fc:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b4fc
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RCX, R12
JMP .Lkd_src_ffffffffc000b4ff
.Lkd_runtime_ffffffffc000b4fc:
POPFQ
JMP .Lkd_exit_62
.Lkd_src_ffffffffc000b4ff:
JMP .Lkd_exit_63
.Lkd_src_ffffffffc000b504:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b504
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             R13, 0x8
JMP .Lkd_src_ffffffffc000b508
.Lkd_runtime_ffffffffc000b504:
POPFQ
JMP .Lkd_exit_64
.Lkd_src_ffffffffc000b508:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b508
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             RBX, R15
JMP .Lkd_src_ffffffffc000b509
.Lkd_runtime_ffffffffc000b508:
POPFQ
JMP .Lkd_exit_65
.Lkd_src_ffffffffc000b509:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b509
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 48]
MOV             R14, R15
MOV             QWORD PTR[R11 + 48], R14
JMP .Lkd_src_ffffffffc000b50b
.Lkd_runtime_ffffffffc000b509:
POPFQ
JMP .Lkd_exit_66
.Lkd_src_ffffffffc000b50b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b50b
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 40]
MOV             R14, R15
MOV             QWORD PTR[R11 + 40], R14
JMP .Lkd_src_ffffffffc000b50d
.Lkd_runtime_ffffffffc000b50b:
POPFQ
JMP .Lkd_exit_67
.Lkd_src_ffffffffc000b50d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b50d
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 32]
MOV             R14, R15
MOV             QWORD PTR[R11 + 32], R14
JMP .Lkd_src_ffffffffc000b50f
.Lkd_runtime_ffffffffc000b50d:
POPFQ
JMP .Lkd_exit_68
.Lkd_src_ffffffffc000b50f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b50f
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 24]
MOV             R14, R15
MOV             QWORD PTR[R11 + 24], R14
JMP .Lkd_src_ffffffffc000b511
.Lkd_runtime_ffffffffc000b50f:
POPFQ
JMP .Lkd_exit_69
.Lkd_src_ffffffffc000b511:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b511
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R12, R15
JMP .Lkd_src_ffffffffc000b512
.Lkd_runtime_ffffffffc000b511:
POPFQ
JMP .Lkd_exit_70
.Lkd_src_ffffffffc000b512:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b512
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EAX, EAX
JMP .Lkd_src_ffffffffc000b514
.Lkd_runtime_ffffffffc000b512:
POPFQ
JMP .Lkd_exit_71
.Lkd_src_ffffffffc000b514:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b514
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDX, EDX
JMP .Lkd_src_ffffffffc000b516
.Lkd_runtime_ffffffffc000b514:
POPFQ
JMP .Lkd_exit_72
.Lkd_src_ffffffffc000b516:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b516
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ECX, ECX
JMP .Lkd_src_ffffffffc000b518
.Lkd_runtime_ffffffffc000b516:
POPFQ
JMP .Lkd_exit_73
.Lkd_src_ffffffffc000b518:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b518
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ESI, ESI
JMP .Lkd_src_ffffffffc000b51a
.Lkd_runtime_ffffffffc000b518:
POPFQ
JMP .Lkd_exit_74
.Lkd_src_ffffffffc000b51a:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b51a
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDI, EDI
JMP .Lkd_src_ffffffffc000b51c
.Lkd_runtime_ffffffffc000b51a:
POPFQ
JMP .Lkd_exit_75
.Lkd_src_ffffffffc000b51c:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b51c
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R8D, R8D
JMP .Lkd_src_ffffffffc000b51f
.Lkd_runtime_ffffffffc000b51c:
POPFQ
JMP .Lkd_exit_76
.Lkd_src_ffffffffc000b51f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b51f
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R9D, R9D
JMP .Lkd_src_ffffffffc000b522
.Lkd_runtime_ffffffffc000b51f:
POPFQ
JMP .Lkd_exit_77
.Lkd_src_ffffffffc000b522:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b522
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R10D, R10D
JMP .Lkd_src_ffffffffc000b525
.Lkd_runtime_ffffffffc000b522:
POPFQ
JMP .Lkd_exit_78
.Lkd_src_ffffffffc000b525:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b525
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[R11 + 56]
XOR             R15d, R15d
MOV             QWORD PTR[R11 + 56], R15
JMP .Lkd_src_ffffffffc000b528
.Lkd_runtime_ffffffffc000b525:
POPFQ
JMP .Lkd_exit_79
.Lkd_src_ffffffffc000b528:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000b528
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R15, R15
MOV             QWORD PTR[RBP - 88], R15
MOV             R14, QWORD PTR[RBP - 88]
PUSHFQ
POPFQ
JMP .Lkd_exit_81
.Lkd_runtime_ffffffffc000b528:
POPFQ
JMP .Lkd_exit_80
.Lkd_src_ffffffffc000e020:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000e020
DEC QWORD PTR[RBP - 120]
POPFQ
PUSH            RAX
MOV             RAX, RAX
MOV             QWORD PTR[RBP - 88], RAX
POP             RAX
MOV R14, QWORD PTR[RBP - 88]
JMP .Lkd_exit_83
.Lkd_runtime_ffffffffc000e020:
POPFQ
JMP .Lkd_exit_82
.Lkd_src_ffffffffc000e023:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffffc000e023
DEC QWORD PTR[RBP - 120]
POPFQ
PUSH            RAX
MOV             RAX, RAX
MOV             QWORD PTR[RBP - 88], RAX
POP             RAX
MOV R14, QWORD PTR[RBP - 88]
PUSHFQ
MOVABS R15, 0xffffffffc000b010
CMP R14, R15
JE .Lkd_ijump_ffffffffc000e023_ffffffffc000b010
POPFQ
JMP .Lkd_exit_85
.Lkd_ijump_ffffffffc000e023_ffffffffc000b010:
POPFQ
JMP .Lkd_src_ffffffffc000b010
.Lkd_runtime_ffffffffc000e023:
POPFQ
JMP .Lkd_exit_84
.Lkd_exit_0:
MOV QWORD PTR[RBP - 72], R14
MOV QWORD PTR[RBP - 80], R14
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 6
MOV QWORD PTR[RBP - 104], 0
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_1:
MOVABS R15, 0xffffffffc000b010
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b010
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_2:
MOVABS R15, 0xffffffffc000b017
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b017
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_3:
MOVABS R15, 0xffffffffc000b01b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b01b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_4:
MOVABS R15, 0xffffffffc000b022
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b022
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_5:
MOVABS R15, 0xffffffffc000b024
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b024
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_6:
MOVABS R15, 0xffffffffc000b026
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b026
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_7:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffffc000b026
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 11
MOV QWORD PTR[RBP - 112], 3
JMP .Lkd_export
.Lkd_exit_8:
MOVABS R15, 0xffffffffc000b39e
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b39e
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_9:
MOVABS R15, 0xffffffffc000b3a2
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3a2
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_10:
MOVABS R15, 0xffffffffc000b3a5
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3a5
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_11:
MOVABS R15, 0xffffffffc000b3a8
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3a8
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_12:
MOVABS R15, 0xffffffffc000b3aa
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3aa
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_13:
MOVABS R15, 0xffffffffc000b3ac
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3ac
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_14:
MOVABS R15, 0xffffffffc000b3b4
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3b4
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_15:
MOVABS R15, 0xffffffffc000b3b7
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3b7
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_16:
MOVABS R15, 0xffffffffc000b3be
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3be
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_17:
MOVABS R15, 0xffffffffc000b3c5
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3c5
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_18:
MOVABS R15, 0xffffffffc000b3c9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3c9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_19:
MOVABS R15, 0xffffffffc000b3d0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3d0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_20:
MOVABS R15, 0xffffffffc000b3d7
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b3d7
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_21:
MOVABS R15, 0xffffffffc000b407
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b407
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_22:
MOVABS R15, 0xffffffffc000b40a
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b40a
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_23:
MOVABS R15, 0xffffffffc000b40e
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b40e
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_24:
MOVABS R15, 0xffffffffc000b40f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b40f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_25:
MOVABS R15, 0xffffffffc000b411
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b411
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_26:
MOVABS R15, 0xffffffffc000b413
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b413
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_27:
MOVABS R15, 0xffffffffc000b415
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b415
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_28:
MOVABS R15, 0xffffffffc000b417
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b417
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_29:
MOVABS R15, 0xffffffffc000b418
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b418
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_30:
MOVABS R15, 0xffffffffc000b41a
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b41a
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_31:
MOVABS R15, 0xffffffffc000b41c
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b41c
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_32:
MOVABS R15, 0xffffffffc000b41e
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b41e
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_33:
MOVABS R15, 0xffffffffc000b420
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b420
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_34:
MOVABS R15, 0xffffffffc000b423
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b423
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_35:
MOVABS R15, 0xffffffffc000b426
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b426
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_36:
MOVABS R15, 0xffffffffc000b429
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b429
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_37:
MOVABS R15, 0xffffffffc000b42c
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b42c
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_38:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffffc000b42c
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 11
MOV QWORD PTR[RBP - 112], 3
JMP .Lkd_export
.Lkd_exit_39:
MOVABS R15, 0xffffffffc000b48e
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b48e
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_40:
MOVABS R15, 0xffffffffc000b496
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b496
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_41:
MOVABS R15, 0xffffffffc000b49a
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b49a
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_42:
MOVABS R15, 0xffffffffc000b4a1
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4a1
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_43:
MOVABS R15, 0xffffffffc000b4a4
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4a4
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_44:
MOVABS R15, 0xffffffffc000b4ab
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4ab
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_45:
MOVABS R15, 0xffffffffc000b4b2
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4b2
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_46:
MOVABS R15, 0xffffffffc000b4b6
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4b6
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_47:
MOVABS R15, 0xffffffffc000b4bd
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4bd
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_48:
MOVABS R15, 0xffffffffc000b4c4
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4c4
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_49:
MOVABS R15, 0xffffffffc000b4c9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4c9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_50:
MOVABS R15, 0xffffffffc000b4cd
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4cd
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_51:
MOVABS R15, 0xffffffffc000b4d0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4d0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_52:
MOVABS R15, 0xffffffffc000c6d2
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4d0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffffc000c6d2
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 1
MOV QWORD PTR[RBP - 112], 4
JMP .Lkd_export
.Lkd_exit_53:
MOVABS R15, 0xffffffffc000b4d6
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4d6
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_54:
MOVABS R15, 0xffffffffc000b4d9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4d9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_55:
MOVABS R15, 0xffffffffc000b4db
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4db
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_56:
MOVABS R15, 0xffffffffc000b4e2
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4e2
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_57:
MOVABS R15, 0xffffffffc000b4e6
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4e6
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_58:
MOVABS R15, 0xffffffffc000b4e6
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4e6
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 10
MOV QWORD PTR[RBP - 112], 1
JMP .Lkd_export
.Lkd_exit_59:
MOVABS R15, 0xffffffffc000b4eb
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4eb
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_60:
MOVABS R15, 0xffffffffc000b4f2
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4f2
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_61:
MOVABS R15, 0xffffffffc000b4f5
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4f5
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_62:
MOVABS R15, 0xffffffffc000b4fc
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4fc
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_63:
MOVABS R15, 0xffffffffc000b4ff
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b4ff
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffff8152f5d0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 1
MOV QWORD PTR[RBP - 104], 2
MOV QWORD PTR[RBP - 112], 1
JMP .Lkd_export
.Lkd_exit_64:
MOVABS R15, 0xffffffffc000b504
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b504
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_65:
MOVABS R15, 0xffffffffc000b508
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b508
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_66:
MOVABS R15, 0xffffffffc000b509
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b509
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_67:
MOVABS R15, 0xffffffffc000b50b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b50b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_68:
MOVABS R15, 0xffffffffc000b50d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b50d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_69:
MOVABS R15, 0xffffffffc000b50f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b50f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_70:
MOVABS R15, 0xffffffffc000b511
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b511
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_71:
MOVABS R15, 0xffffffffc000b512
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b512
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_72:
MOVABS R15, 0xffffffffc000b514
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b514
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_73:
MOVABS R15, 0xffffffffc000b516
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b516
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_74:
MOVABS R15, 0xffffffffc000b518
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b518
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_75:
MOVABS R15, 0xffffffffc000b51a
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b51a
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_76:
MOVABS R15, 0xffffffffc000b51c
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b51c
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_77:
MOVABS R15, 0xffffffffc000b51f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b51f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_78:
MOVABS R15, 0xffffffffc000b522
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b522
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_79:
MOVABS R15, 0xffffffffc000b525
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b525
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_80:
MOVABS R15, 0xffffffffc000b528
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000b528
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_81:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffffc000b528
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 11
MOV QWORD PTR[RBP - 112], 3
JMP .Lkd_export
.Lkd_exit_82:
MOVABS R15, 0xffffffffc000e020
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000e020
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_83:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffffc000e020
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 10
MOV QWORD PTR[RBP - 112], 4
JMP .Lkd_export
.Lkd_exit_84:
MOVABS R15, 0xffffffffc000e023
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffffc000e023
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_85:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffffc000e023
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 10
MOV QWORD PTR[RBP - 112], 4
JMP .Lkd_export


.Lkd_export:
	/* The generated exit has already flushed mapped source GPRs, recovered
	 * physical R12/R13 as BP/SP and written the exact control result slots.
	 * Save all resident source values before reusing RAX/R14 for control. */
	mov QWORD PTR[R11 + 16], r12
	mov QWORD PTR[R11 + 8], r13
	mov QWORD PTR[R11 + 64], rbx
	mov QWORD PTR[R11 + 72], r10
	mov QWORD PTR[R11 + 80], r9
	mov QWORD PTR[R11 + 88], r8
	mov QWORD PTR[R11 + 96], rax
	mov QWORD PTR[R11 + 104], rcx
	mov QWORD PTR[R11 + 112], rdx
	mov QWORD PTR[R11 + 120], rsi
	mov QWORD PTR[R11 + 128], rdi
	mov rax, QWORD PTR[RBP - 72]
	mov QWORD PTR[R11 + 0], rax
	mov r14, QWORD PTR[RBP - 64]
	mov rax, QWORD PTR[RBP - 96]
	mov QWORD PTR[r14 + 16], rax
	mov rax, QWORD PTR[RBP - 104]
	mov QWORD PTR[r14 + 24], rax
	mov rax, QWORD PTR[RBP - 80]
	mov QWORD PTR[r14 + 32], rax
	mov rax, QWORD PTR[RBP - 88]
	mov QWORD PTR[r14 + 40], rax
	mov rax, QWORD PTR[RBP - 112]
	mov QWORD PTR[r14 + 48], rax
	/* Keep all private slots allocated through their final read. Returning
	 * publishes no ownership transfer by itself; lock code owns that order. */
	lea rsp, [rbp - 40]
	pop r15
	pop r14
	pop r13
	pop r12
	pop rbx
	pop rbp
	ret
	.size kd_fixture_entry, .-kd_fixture_entry
	.section .note.GNU-stack, "", @progbits
