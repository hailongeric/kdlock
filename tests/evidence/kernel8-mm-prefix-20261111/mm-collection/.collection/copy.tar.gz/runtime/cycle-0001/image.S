/* SPDX-License-Identifier: GPL-2.0-only */
/* Per-image entry template for the original UB-derived KD mapping. Lowering
 * substitutes kd_mm_entry and KD_GENERATED_BODY for one image's own code.
 * All source state remains in its original thread's one canonical packet.
 * The caller supplies fresh origin GS/task inputs, exclusive source execution,
 * valid source/code bindings and the declared sleepable physical context.
 * The distinct executor's native stack and all origin waiting/control stacks
 * must be admitted disjoint from the stopped source stack; this template does
 * not establish or allocate that context and cannot execute an origin's own
 * source on overlapping native frames.
 * General flags/SIMD use AS01; this unrun wrapper is no equivalence evidence.
 */


	.intel_syntax noprefix
	.text
	.p2align 4
	.globl kd_mm_entry
	.type kd_mm_entry, @function
kd_mm_entry:
	endbr64
	/* Preserve the executor's native callee-saved state. Logical source
	 * BP/SP are separate and never replace physical RBP/RSP here. */
	push rbp
	mov rbp, rsp
	push rbx
	push r12
	push r13
	push r14
	push r15
	/* Allocate every private slot before stores, without using a red zone
	 * or changing the assumed source flags during packet import. */
	lea rsp, [rsp - 80]
	mov QWORD PTR[RBP - 64], rsi
	mov R11, rdi
	mov r14, QWORD PTR[rsi + 0]
	mov QWORD PTR[RBP - 48], r14
	mov r14, QWORD PTR[rsi + 8]
	mov QWORD PTR[RBP - 56], r14
	/* Source R11--R15 already have canonical backing. Only the resident
	 * source GPRs and stable BP/SP caches need importing. */
	mov rbx, QWORD PTR[R11 + 64]
	mov r10, QWORD PTR[R11 + 72]
	mov r9, QWORD PTR[R11 + 80]
	mov r8, QWORD PTR[R11 + 88]
	mov rax, QWORD PTR[R11 + 96]
	mov rcx, QWORD PTR[R11 + 104]
	mov rdx, QWORD PTR[R11 + 112]
	mov rsi, QWORD PTR[R11 + 120]
	mov rdi, QWORD PTR[R11 + 128]
	mov r12, QWORD PTR[R11 + 16]
	mov r13, QWORD PTR[R11 + 8]
	jmp .Lkd_dispatch

.Lkd_dispatch:
MOVABS R14, 1000000
MOV QWORD PTR[RBP - 120], R14
MOV R14, QWORD PTR[R11 + 0]
PUSHFQ
MOVABS R15, 0xffffffff817ef5ea
CMP R14, R15
JE .Lkd_enter_ffffffff817ef5ea
MOVABS R15, 0xffffffff8185b00e
CMP R14, R15
JE .Lkd_enter_ffffffff8185b00e
POPFQ
JMP .Lkd_exit_0
.Lkd_enter_ffffffff817ef5ea:
POPFQ
JMP .Lkd_src_ffffffff817ef5ea
.Lkd_enter_ffffffff8185b00e:
POPFQ
JMP .Lkd_src_ffffffff8185b00e
.Lkd_src_ffffffff817ef3cd:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3cd
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD0]
JMP .Lkd_src_ffffffff817ef3d1
.Lkd_runtime_ffffffff817ef3cd:
POPFQ
JMP .Lkd_exit_1
.Lkd_src_ffffffff817ef3d1:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3d1
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[RBP - 48]
MOVABS          R14, 0xffffffff817ef3d9
SUB             RAX, QWORD PTR [R15 + R14 + 0x2C35C2F]
JMP .Lkd_src_ffffffff817ef3d9
.Lkd_runtime_ffffffff817ef3d1:
POPFQ
JMP .Lkd_exit_2
.Lkd_src_ffffffff817ef3d9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3d9
DEC QWORD PTR[RBP - 120]
POPFQ
JNZ .Lkd_taken_ffffffff817ef3d9
JMP .Lkd_src_ffffffff817ef3df
.Lkd_taken_ffffffff817ef3d9:
JMP .Lkd_src_ffffffff817ef66f
.Lkd_runtime_ffffffff817ef3d9:
POPFQ
JMP .Lkd_exit_3
.Lkd_src_ffffffff817ef3df:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3df
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFA8]
JMP .Lkd_src_ffffffff817ef3e3
.Lkd_runtime_ffffffff817ef3df:
POPFQ
JMP .Lkd_exit_4
.Lkd_src_ffffffff817ef3e3:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3e3
DEC QWORD PTR[RBP - 120]
POPFQ
LEA             R13, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD8]
JMP .Lkd_src_ffffffff817ef3e7
.Lkd_runtime_ffffffff817ef3e3:
POPFQ
JMP .Lkd_exit_5
.Lkd_src_ffffffff817ef3e7:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3e7
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             RBX, R15
JMP .Lkd_src_ffffffff817ef3e8
.Lkd_runtime_ffffffff817ef3e7:
POPFQ
JMP .Lkd_exit_6
.Lkd_src_ffffffff817ef3e8:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3e8
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 48]
MOV             R14, R15
MOV             QWORD PTR[R11 + 48], R14
JMP .Lkd_src_ffffffff817ef3ea
.Lkd_runtime_ffffffff817ef3e8:
POPFQ
JMP .Lkd_exit_7
.Lkd_src_ffffffff817ef3ea:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3ea
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 40]
MOV             R14, R15
MOV             QWORD PTR[R11 + 40], R14
JMP .Lkd_src_ffffffff817ef3ec
.Lkd_runtime_ffffffff817ef3ea:
POPFQ
JMP .Lkd_exit_8
.Lkd_src_ffffffff817ef3ec:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3ec
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 32]
MOV             R14, R15
MOV             QWORD PTR[R11 + 32], R14
JMP .Lkd_src_ffffffff817ef3ee
.Lkd_runtime_ffffffff817ef3ec:
POPFQ
JMP .Lkd_exit_9
.Lkd_src_ffffffff817ef3ee:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3ee
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 24]
MOV             R14, R15
MOV             QWORD PTR[R11 + 24], R14
JMP .Lkd_src_ffffffff817ef3f0
.Lkd_runtime_ffffffff817ef3ee:
POPFQ
JMP .Lkd_exit_10
.Lkd_src_ffffffff817ef3f0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3f0
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R12, R15
JMP .Lkd_src_ffffffff817ef3f1
.Lkd_runtime_ffffffff817ef3f0:
POPFQ
JMP .Lkd_exit_11
.Lkd_src_ffffffff817ef3f1:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3f1
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDX, EDX
JMP .Lkd_src_ffffffff817ef3f3
.Lkd_runtime_ffffffff817ef3f1:
POPFQ
JMP .Lkd_exit_12
.Lkd_src_ffffffff817ef3f3:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3f3
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ECX, ECX
JMP .Lkd_src_ffffffff817ef3f5
.Lkd_runtime_ffffffff817ef3f3:
POPFQ
JMP .Lkd_exit_13
.Lkd_src_ffffffff817ef3f5:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3f5
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ESI, ESI
JMP .Lkd_src_ffffffff817ef3f7
.Lkd_runtime_ffffffff817ef3f5:
POPFQ
JMP .Lkd_exit_14
.Lkd_src_ffffffff817ef3f7:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3f7
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDI, EDI
JMP .Lkd_src_ffffffff817ef3f9
.Lkd_runtime_ffffffff817ef3f7:
POPFQ
JMP .Lkd_exit_15
.Lkd_src_ffffffff817ef3f9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3f9
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R8D, R8D
JMP .Lkd_src_ffffffff817ef3fc
.Lkd_runtime_ffffffff817ef3f9:
POPFQ
JMP .Lkd_exit_16
.Lkd_src_ffffffff817ef3fc:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3fc
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R9D, R9D
JMP .Lkd_src_ffffffff817ef3ff
.Lkd_runtime_ffffffff817ef3fc:
POPFQ
JMP .Lkd_exit_17
.Lkd_src_ffffffff817ef3ff:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef3ff
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R10D, R10D
JMP .Lkd_src_ffffffff817ef402
.Lkd_runtime_ffffffff817ef3ff:
POPFQ
JMP .Lkd_exit_18
.Lkd_src_ffffffff817ef402:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef402
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[R11 + 56]
XOR             R15d, R15d
MOV             QWORD PTR[R11 + 56], R15
JMP .Lkd_src_ffffffff817ef405
.Lkd_runtime_ffffffff817ef402:
POPFQ
JMP .Lkd_exit_19
.Lkd_src_ffffffff817ef405:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef405
DEC QWORD PTR[RBP - 120]
POPFQ
JMP .Lkd_src_ffffffff8276eee0
.Lkd_runtime_ffffffff817ef405:
POPFQ
JMP .Lkd_exit_20
.Lkd_src_ffffffff817ef485:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef485
DEC QWORD PTR[RBP - 120]
POPFQ
TEST            EBX, EBX
JMP .Lkd_src_ffffffff817ef487
.Lkd_runtime_ffffffff817ef485:
POPFQ
JMP .Lkd_exit_21
.Lkd_src_ffffffff817ef487:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef487
DEC QWORD PTR[RBP - 120]
POPFQ
JNZ .Lkd_taken_ffffffff817ef487
JMP .Lkd_src_ffffffff817ef489
.Lkd_taken_ffffffff817ef487:
JMP .Lkd_src_ffffffff817ef494
.Lkd_runtime_ffffffff817ef487:
POPFQ
JMP .Lkd_exit_22
.Lkd_src_ffffffff817ef489:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef489
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFA0]
JMP .Lkd_src_ffffffff817ef48d
.Lkd_runtime_ffffffff817ef489:
POPFQ
JMP .Lkd_exit_23
.Lkd_src_ffffffff817ef48d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef48d
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             DWORD PTR [RAX + 0x1D8], 0x1
JMP .Lkd_src_ffffffff817ef494
.Lkd_runtime_ffffffff817ef48d:
POPFQ
JMP .Lkd_exit_24
.Lkd_src_ffffffff817ef494:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef494
DEC QWORD PTR[RBP - 120]
POPFQ
NOP
JMP .Lkd_src_ffffffff817ef499
.Lkd_runtime_ffffffff817ef494:
POPFQ
JMP .Lkd_exit_25
.Lkd_src_ffffffff817ef499:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef499
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             QWORD PTR [R12 + 0xFFFFFFFFFFFFFFA8], 0xFFFFFFFFFFFFFFFC
JMP .Lkd_src_ffffffff817ef4a1
.Lkd_runtime_ffffffff817ef499:
POPFQ
JMP .Lkd_exit_26
.Lkd_src_ffffffff817ef4a1:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4a1
DEC QWORD PTR[RBP - 120]
POPFQ
TEST            EBX, EBX
JMP .Lkd_src_ffffffff817ef4a3
.Lkd_runtime_ffffffff817ef4a1:
POPFQ
JMP .Lkd_exit_27
.Lkd_src_ffffffff817ef4a3:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4a3
DEC QWORD PTR[RBP - 120]
POPFQ
JNZ .Lkd_taken_ffffffff817ef4a3
JMP .Lkd_src_ffffffff817ef4a9
.Lkd_taken_ffffffff817ef4a3:
JMP .Lkd_src_ffffffff817ef3cd
.Lkd_runtime_ffffffff817ef4a3:
POPFQ
JMP .Lkd_exit_28
.Lkd_src_ffffffff817ef4a9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4a9
DEC QWORD PTR[RBP - 120]
POPFQ
LEA             RAX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFC0]
JMP .Lkd_src_ffffffff817ef4ad
.Lkd_runtime_ffffffff817ef4a9:
POPFQ
JMP .Lkd_exit_29
.Lkd_src_ffffffff817ef4ad:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4ad
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R9D, R9D
JMP .Lkd_src_ffffffff817ef4b0
.Lkd_runtime_ffffffff817ef4ad:
POPFQ
JMP .Lkd_exit_30
.Lkd_src_ffffffff817ef4b0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4b0
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, RAX
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
JMP .Lkd_src_ffffffff817ef4b1
.Lkd_runtime_ffffffff817ef4b0:
POPFQ
JMP .Lkd_exit_31
.Lkd_src_ffffffff817ef4b1:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4b1
DEC QWORD PTR[RBP - 120]
POPFQ
LEA             RAX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFB0]
JMP .Lkd_src_ffffffff817ef4b5
.Lkd_runtime_ffffffff817ef4b1:
POPFQ
JMP .Lkd_exit_32
.Lkd_src_ffffffff817ef4b5:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4b5
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, RAX
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
JMP .Lkd_src_ffffffff817ef4b6
.Lkd_runtime_ffffffff817ef4b5:
POPFQ
JMP .Lkd_exit_33
.Lkd_src_ffffffff817ef4b6:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4b6
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF90]
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
JMP .Lkd_src_ffffffff817ef4b9
.Lkd_runtime_ffffffff817ef4b6:
POPFQ
JMP .Lkd_exit_34
.Lkd_src_ffffffff817ef4b9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4b9
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R8, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF70]
JMP .Lkd_src_ffffffff817ef4c0
.Lkd_runtime_ffffffff817ef4b9:
POPFQ
JMP .Lkd_exit_35
.Lkd_src_ffffffff817ef4c0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4c0
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RCX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF78]
JMP .Lkd_src_ffffffff817ef4c7
.Lkd_runtime_ffffffff817ef4c0:
POPFQ
JMP .Lkd_exit_36
.Lkd_src_ffffffff817ef4c7:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4c7
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF88]
JMP .Lkd_src_ffffffff817ef4cb
.Lkd_runtime_ffffffff817ef4c7:
POPFQ
JMP .Lkd_exit_37
.Lkd_src_ffffffff817ef4cb:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4cb
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RSI, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF80]
JMP .Lkd_src_ffffffff817ef4cf
.Lkd_runtime_ffffffff817ef4cb:
POPFQ
JMP .Lkd_exit_38
.Lkd_src_ffffffff817ef4cf:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4cf
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDI, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF98]
JMP .Lkd_src_ffffffff817ef4d3
.Lkd_runtime_ffffffff817ef4cf:
POPFQ
JMP .Lkd_exit_39
.Lkd_src_ffffffff817ef4d3:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef4d3
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          R15, 0xFFFFFFFF817EF4D8
MOV             R15, R15
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
MOVABS          R14, 0xffffffff818321c0
JMP .Lkd_exit_41
.Lkd_runtime_ffffffff817ef4d3:
POPFQ
JMP .Lkd_exit_40
.Lkd_src_ffffffff817ef5ea:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef5ea
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             EBX, EAX
JMP .Lkd_src_ffffffff817ef5ec
.Lkd_runtime_ffffffff817ef5ea:
POPFQ
JMP .Lkd_exit_42
.Lkd_src_ffffffff817ef5ec:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef5ec
DEC QWORD PTR[RBP - 120]
POPFQ
JMP .Lkd_src_ffffffff817ef485
.Lkd_runtime_ffffffff817ef5ec:
POPFQ
JMP .Lkd_exit_43
.Lkd_src_ffffffff817ef66f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff817ef66f
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          R15, 0xFFFFFFFF817EF674
MOV             R15, R15
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
MOVABS          R14, 0xffffffff82758ad0
JMP .Lkd_exit_45
.Lkd_runtime_ffffffff817ef66f:
POPFQ
JMP .Lkd_exit_44
.Lkd_src_ffffffff8185af08:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af08
DEC QWORD PTR[RBP - 120]
POPFQ
TEST            EBX, EBX
JMP .Lkd_src_ffffffff8185af0a
.Lkd_runtime_ffffffff8185af08:
POPFQ
JMP .Lkd_exit_46
.Lkd_src_ffffffff8185af0a:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af0a
DEC QWORD PTR[RBP - 120]
POPFQ
JNZ .Lkd_taken_ffffffff8185af0a
JMP .Lkd_src_ffffffff8185af0c
.Lkd_taken_ffffffff8185af0a:
JMP .Lkd_src_ffffffff8185af1a
.Lkd_runtime_ffffffff8185af0a:
POPFQ
JMP .Lkd_exit_47
.Lkd_src_ffffffff8185af0c:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af0c
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF60]
JMP .Lkd_src_ffffffff8185af13
.Lkd_runtime_ffffffff8185af0c:
POPFQ
JMP .Lkd_exit_48
.Lkd_src_ffffffff8185af13:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af13
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             DWORD PTR [RAX + 0x1D8], 0x1
JMP .Lkd_src_ffffffff8185af1a
.Lkd_runtime_ffffffff8185af13:
POPFQ
JMP .Lkd_exit_49
.Lkd_src_ffffffff8185af1a:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af1a
DEC QWORD PTR[RBP - 120]
POPFQ
NOP
JMP .Lkd_src_ffffffff8185af1f
.Lkd_runtime_ffffffff8185af1a:
POPFQ
JMP .Lkd_exit_50
.Lkd_src_ffffffff8185af1f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af1f
DEC QWORD PTR[RBP - 120]
POPFQ
TEST            EBX, EBX
JMP .Lkd_src_ffffffff8185af21
.Lkd_runtime_ffffffff8185af1f:
POPFQ
JMP .Lkd_exit_51
.Lkd_src_ffffffff8185af21:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af21
DEC QWORD PTR[RBP - 120]
POPFQ
JNZ .Lkd_taken_ffffffff8185af21
JMP .Lkd_src_ffffffff8185af27
.Lkd_taken_ffffffff8185af21:
JMP .Lkd_src_ffffffff8185b106
.Lkd_runtime_ffffffff8185af21:
POPFQ
JMP .Lkd_exit_52
.Lkd_src_ffffffff8185af27:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af27
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             EBX, DWORD PTR [R12 + 0xFFFFFFFFFFFFFF4C]
JMP .Lkd_src_ffffffff8185af2d
.Lkd_runtime_ffffffff8185af27:
POPFQ
JMP .Lkd_exit_53
.Lkd_src_ffffffff8185af2d:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af2d
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RCX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF50]
JMP .Lkd_src_ffffffff8185af34
.Lkd_runtime_ffffffff8185af2d:
POPFQ
JMP .Lkd_exit_54
.Lkd_src_ffffffff8185af34:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af34
DEC QWORD PTR[RBP - 120]
POPFQ
LEA             RDI, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF78]
JMP .Lkd_src_ffffffff8185af3b
.Lkd_runtime_ffffffff8185af34:
POPFQ
JMP .Lkd_exit_55
.Lkd_src_ffffffff8185af3b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af3b
DEC QWORD PTR[RBP - 120]
POPFQ
LEA             R8, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF68]
JMP .Lkd_src_ffffffff8185af42
.Lkd_runtime_ffffffff8185af3b:
POPFQ
JMP .Lkd_exit_56
.Lkd_src_ffffffff8185af42:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af42
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RDX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF58]
JMP .Lkd_src_ffffffff8185af49
.Lkd_runtime_ffffffff8185af42:
POPFQ
JMP .Lkd_exit_57
.Lkd_src_ffffffff8185af49:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af49
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RSI, QWORD PTR [R12 + 0xFFFFFFFFFFFFFF60]
JMP .Lkd_src_ffffffff8185af50
.Lkd_runtime_ffffffff8185af49:
POPFQ
JMP .Lkd_exit_58
.Lkd_src_ffffffff8185af50:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af50
DEC QWORD PTR[RBP - 120]
POPFQ
MOVZX           R9D, BL
JMP .Lkd_src_ffffffff8185af54
.Lkd_runtime_ffffffff8185af50:
POPFQ
JMP .Lkd_exit_59
.Lkd_src_ffffffff8185af54:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af54
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          R15, 0xFFFFFFFF8185AF59
MOV             R15, R15
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
MOVABS          R14, 0xffffffff81858430
JMP .Lkd_exit_61
.Lkd_runtime_ffffffff8185af54:
POPFQ
JMP .Lkd_exit_60
.Lkd_src_ffffffff8185af83:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af83
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             RAX, QWORD PTR [R12 + 0xFFFFFFFFFFFFFFD0]
JMP .Lkd_src_ffffffff8185af87
.Lkd_runtime_ffffffff8185af83:
POPFQ
JMP .Lkd_exit_62
.Lkd_src_ffffffff8185af87:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af87
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[RBP - 48]
MOVABS          R14, 0xffffffff8185af8f
SUB             RAX, QWORD PTR [R15 + R14 + 0x2BCA079]
JMP .Lkd_src_ffffffff8185af8f
.Lkd_runtime_ffffffff8185af87:
POPFQ
JMP .Lkd_exit_63
.Lkd_src_ffffffff8185af8f:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af8f
DEC QWORD PTR[RBP - 120]
POPFQ
JNZ .Lkd_taken_ffffffff8185af8f
JMP .Lkd_src_ffffffff8185af95
.Lkd_taken_ffffffff8185af8f:
JMP .Lkd_src_ffffffff8185b115
.Lkd_runtime_ffffffff8185af8f:
POPFQ
JMP .Lkd_exit_64
.Lkd_src_ffffffff8185af95:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af95
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             EAX, DWORD PTR [R12 + 0xFFFFFFFFFFFFFF58]
JMP .Lkd_src_ffffffff8185af9b
.Lkd_runtime_ffffffff8185af95:
POPFQ
JMP .Lkd_exit_65
.Lkd_src_ffffffff8185af9b:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185af9b
DEC QWORD PTR[RBP - 120]
POPFQ
ADD             R13, 0x98
JMP .Lkd_src_ffffffff8185afa2
.Lkd_runtime_ffffffff8185af9b:
POPFQ
JMP .Lkd_exit_66
.Lkd_src_ffffffff8185afa2:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afa2
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             RBX, R15
JMP .Lkd_src_ffffffff8185afa3
.Lkd_runtime_ffffffff8185afa2:
POPFQ
JMP .Lkd_exit_67
.Lkd_src_ffffffff8185afa3:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afa3
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 48]
MOV             R14, R15
MOV             QWORD PTR[R11 + 48], R14
JMP .Lkd_src_ffffffff8185afa5
.Lkd_runtime_ffffffff8185afa3:
POPFQ
JMP .Lkd_exit_68
.Lkd_src_ffffffff8185afa5:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afa5
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 40]
MOV             R14, R15
MOV             QWORD PTR[R11 + 40], R14
JMP .Lkd_src_ffffffff8185afa7
.Lkd_runtime_ffffffff8185afa5:
POPFQ
JMP .Lkd_exit_69
.Lkd_src_ffffffff8185afa7:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afa7
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 32]
MOV             R14, R15
MOV             QWORD PTR[R11 + 32], R14
JMP .Lkd_src_ffffffff8185afa9
.Lkd_runtime_ffffffff8185afa7:
POPFQ
JMP .Lkd_exit_70
.Lkd_src_ffffffff8185afa9:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afa9
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R14, QWORD PTR[R11 + 24]
MOV             R14, R15
MOV             QWORD PTR[R11 + 24], R14
JMP .Lkd_src_ffffffff8185afab
.Lkd_runtime_ffffffff8185afa9:
POPFQ
JMP .Lkd_exit_71
.Lkd_src_ffffffff8185afab:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afab
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R12, R15
JMP .Lkd_src_ffffffff8185afac
.Lkd_runtime_ffffffff8185afab:
POPFQ
JMP .Lkd_exit_72
.Lkd_src_ffffffff8185afac:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afac
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDX, EDX
JMP .Lkd_src_ffffffff8185afae
.Lkd_runtime_ffffffff8185afac:
POPFQ
JMP .Lkd_exit_73
.Lkd_src_ffffffff8185afae:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afae
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ECX, ECX
JMP .Lkd_src_ffffffff8185afb0
.Lkd_runtime_ffffffff8185afae:
POPFQ
JMP .Lkd_exit_74
.Lkd_src_ffffffff8185afb0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afb0
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             ESI, ESI
JMP .Lkd_src_ffffffff8185afb2
.Lkd_runtime_ffffffff8185afb0:
POPFQ
JMP .Lkd_exit_75
.Lkd_src_ffffffff8185afb2:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afb2
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             EDI, EDI
JMP .Lkd_src_ffffffff8185afb4
.Lkd_runtime_ffffffff8185afb2:
POPFQ
JMP .Lkd_exit_76
.Lkd_src_ffffffff8185afb4:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afb4
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R8D, R8D
JMP .Lkd_src_ffffffff8185afb7
.Lkd_runtime_ffffffff8185afb4:
POPFQ
JMP .Lkd_exit_77
.Lkd_src_ffffffff8185afb7:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afb7
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R9D, R9D
JMP .Lkd_src_ffffffff8185afba
.Lkd_runtime_ffffffff8185afb7:
POPFQ
JMP .Lkd_exit_78
.Lkd_src_ffffffff8185afba:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afba
DEC QWORD PTR[RBP - 120]
POPFQ
XOR             R10D, R10D
JMP .Lkd_src_ffffffff8185afbd
.Lkd_runtime_ffffffff8185afba:
POPFQ
JMP .Lkd_exit_79
.Lkd_src_ffffffff8185afbd:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afbd
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR[R11 + 56]
XOR             R15d, R15d
MOV             QWORD PTR[R11 + 56], R15
JMP .Lkd_src_ffffffff8185afc0
.Lkd_runtime_ffffffff8185afbd:
POPFQ
JMP .Lkd_exit_80
.Lkd_src_ffffffff8185afc0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185afc0
DEC QWORD PTR[RBP - 120]
POPFQ
JMP .Lkd_src_ffffffff8276eee0
.Lkd_runtime_ffffffff8185afc0:
POPFQ
JMP .Lkd_exit_81
.Lkd_src_ffffffff8185b00e:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185b00e
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             EBX, EAX
JMP .Lkd_src_ffffffff8185b010
.Lkd_runtime_ffffffff8185b00e:
POPFQ
JMP .Lkd_exit_82
.Lkd_src_ffffffff8185b010:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185b010
DEC QWORD PTR[RBP - 120]
POPFQ
JMP .Lkd_src_ffffffff8185af08
.Lkd_runtime_ffffffff8185b010:
POPFQ
JMP .Lkd_exit_83
.Lkd_src_ffffffff8185b106:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185b106
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             DWORD PTR [R12 + 0xFFFFFFFFFFFFFF58], 0xFFFFFFFC
JMP .Lkd_src_ffffffff8185b110
.Lkd_runtime_ffffffff8185b106:
POPFQ
JMP .Lkd_exit_84
.Lkd_src_ffffffff8185b110:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185b110
DEC QWORD PTR[RBP - 120]
POPFQ
JMP .Lkd_src_ffffffff8185af83
.Lkd_runtime_ffffffff8185b110:
POPFQ
JMP .Lkd_exit_85
.Lkd_src_ffffffff8185b115:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8185b115
DEC QWORD PTR[RBP - 120]
POPFQ
MOVABS          R15, 0xFFFFFFFF8185B11A
MOV             R15, R15
LEA             R13, QWORD PTR [R13 + 0xFFFFFFFFFFFFFFF8]
MOV             QWORD PTR [R13], R15
MOVABS          R14, 0xffffffff82758ad0
JMP .Lkd_exit_87
.Lkd_runtime_ffffffff8185b115:
POPFQ
JMP .Lkd_exit_86
.Lkd_src_ffffffff8276eee0:
PUSHFQ
CMP QWORD PTR[RBP - 120], 0
JE .Lkd_runtime_ffffffff8276eee0
DEC QWORD PTR[RBP - 120]
POPFQ
MOV             R15, QWORD PTR [R13]
LEA             R13, QWORD PTR [R13 + 0x8]
MOV             R15, R15
MOV             QWORD PTR[RBP - 88], R15
MOV             R14, QWORD PTR[RBP - 88]
PUSHFQ
POPFQ
JMP .Lkd_exit_89
.Lkd_runtime_ffffffff8276eee0:
POPFQ
JMP .Lkd_exit_88
.Lkd_exit_0:
MOV QWORD PTR[RBP - 72], R14
MOV QWORD PTR[RBP - 80], R14
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 6
MOV QWORD PTR[RBP - 104], 0
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_1:
MOVABS R15, 0xffffffff817ef3cd
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3cd
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_2:
MOVABS R15, 0xffffffff817ef3d1
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3d1
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_3:
MOVABS R15, 0xffffffff817ef3d9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3d9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_4:
MOVABS R15, 0xffffffff817ef3df
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3df
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_5:
MOVABS R15, 0xffffffff817ef3e3
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3e3
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_6:
MOVABS R15, 0xffffffff817ef3e7
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3e7
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_7:
MOVABS R15, 0xffffffff817ef3e8
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3e8
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_8:
MOVABS R15, 0xffffffff817ef3ea
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3ea
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_9:
MOVABS R15, 0xffffffff817ef3ec
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3ec
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_10:
MOVABS R15, 0xffffffff817ef3ee
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3ee
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_11:
MOVABS R15, 0xffffffff817ef3f0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3f0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_12:
MOVABS R15, 0xffffffff817ef3f1
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3f1
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_13:
MOVABS R15, 0xffffffff817ef3f3
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3f3
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_14:
MOVABS R15, 0xffffffff817ef3f5
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3f5
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_15:
MOVABS R15, 0xffffffff817ef3f7
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3f7
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_16:
MOVABS R15, 0xffffffff817ef3f9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3f9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_17:
MOVABS R15, 0xffffffff817ef3fc
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3fc
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_18:
MOVABS R15, 0xffffffff817ef3ff
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef3ff
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_19:
MOVABS R15, 0xffffffff817ef402
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef402
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_20:
MOVABS R15, 0xffffffff817ef405
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef405
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_21:
MOVABS R15, 0xffffffff817ef485
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef485
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_22:
MOVABS R15, 0xffffffff817ef487
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef487
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_23:
MOVABS R15, 0xffffffff817ef489
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef489
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_24:
MOVABS R15, 0xffffffff817ef48d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef48d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_25:
MOVABS R15, 0xffffffff817ef494
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef494
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_26:
MOVABS R15, 0xffffffff817ef499
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef499
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_27:
MOVABS R15, 0xffffffff817ef4a1
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4a1
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_28:
MOVABS R15, 0xffffffff817ef4a3
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4a3
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_29:
MOVABS R15, 0xffffffff817ef4a9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4a9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_30:
MOVABS R15, 0xffffffff817ef4ad
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4ad
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_31:
MOVABS R15, 0xffffffff817ef4b0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4b0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_32:
MOVABS R15, 0xffffffff817ef4b1
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4b1
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_33:
MOVABS R15, 0xffffffff817ef4b5
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4b5
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_34:
MOVABS R15, 0xffffffff817ef4b6
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4b6
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_35:
MOVABS R15, 0xffffffff817ef4b9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4b9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_36:
MOVABS R15, 0xffffffff817ef4c0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4c0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_37:
MOVABS R15, 0xffffffff817ef4c7
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4c7
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_38:
MOVABS R15, 0xffffffff817ef4cb
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4cb
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_39:
MOVABS R15, 0xffffffff817ef4cf
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4cf
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_40:
MOVABS R15, 0xffffffff817ef4d3
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4d3
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_41:
MOVABS R15, 0xffffffff818321c0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef4d3
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffff818321c0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 1
MOV QWORD PTR[RBP - 112], 2
JMP .Lkd_export
.Lkd_exit_42:
MOVABS R15, 0xffffffff817ef5ea
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef5ea
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_43:
MOVABS R15, 0xffffffff817ef5ec
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef5ec
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_44:
MOVABS R15, 0xffffffff817ef66f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef66f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_45:
MOVABS R15, 0xffffffff82758ad0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff817ef66f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffff82758ad0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 1
MOV QWORD PTR[RBP - 112], 2
JMP .Lkd_export
.Lkd_exit_46:
MOVABS R15, 0xffffffff8185af08
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af08
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_47:
MOVABS R15, 0xffffffff8185af0a
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af0a
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_48:
MOVABS R15, 0xffffffff8185af0c
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af0c
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_49:
MOVABS R15, 0xffffffff8185af13
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af13
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_50:
MOVABS R15, 0xffffffff8185af1a
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af1a
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_51:
MOVABS R15, 0xffffffff8185af1f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af1f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_52:
MOVABS R15, 0xffffffff8185af21
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af21
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_53:
MOVABS R15, 0xffffffff8185af27
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af27
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_54:
MOVABS R15, 0xffffffff8185af2d
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af2d
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_55:
MOVABS R15, 0xffffffff8185af34
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af34
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_56:
MOVABS R15, 0xffffffff8185af3b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af3b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_57:
MOVABS R15, 0xffffffff8185af42
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af42
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_58:
MOVABS R15, 0xffffffff8185af49
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af49
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_59:
MOVABS R15, 0xffffffff8185af50
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af50
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_60:
MOVABS R15, 0xffffffff8185af54
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af54
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_61:
MOVABS R15, 0xffffffff81858430
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af54
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffff81858430
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 1
MOV QWORD PTR[RBP - 112], 2
JMP .Lkd_export
.Lkd_exit_62:
MOVABS R15, 0xffffffff8185af83
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af83
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_63:
MOVABS R15, 0xffffffff8185af87
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af87
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_64:
MOVABS R15, 0xffffffff8185af8f
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af8f
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_65:
MOVABS R15, 0xffffffff8185af95
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af95
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_66:
MOVABS R15, 0xffffffff8185af9b
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185af9b
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_67:
MOVABS R15, 0xffffffff8185afa2
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afa2
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_68:
MOVABS R15, 0xffffffff8185afa3
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afa3
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_69:
MOVABS R15, 0xffffffff8185afa5
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afa5
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_70:
MOVABS R15, 0xffffffff8185afa7
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afa7
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_71:
MOVABS R15, 0xffffffff8185afa9
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afa9
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_72:
MOVABS R15, 0xffffffff8185afab
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afab
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_73:
MOVABS R15, 0xffffffff8185afac
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afac
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_74:
MOVABS R15, 0xffffffff8185afae
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afae
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_75:
MOVABS R15, 0xffffffff8185afb0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afb0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_76:
MOVABS R15, 0xffffffff8185afb2
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afb2
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_77:
MOVABS R15, 0xffffffff8185afb4
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afb4
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_78:
MOVABS R15, 0xffffffff8185afb7
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afb7
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_79:
MOVABS R15, 0xffffffff8185afba
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afba
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_80:
MOVABS R15, 0xffffffff8185afbd
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afbd
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_81:
MOVABS R15, 0xffffffff8185afc0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185afc0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_82:
MOVABS R15, 0xffffffff8185b00e
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185b00e
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_83:
MOVABS R15, 0xffffffff8185b010
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185b010
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_84:
MOVABS R15, 0xffffffff8185b106
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185b106
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_85:
MOVABS R15, 0xffffffff8185b110
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185b110
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_86:
MOVABS R15, 0xffffffff8185b115
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185b115
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_87:
MOVABS R15, 0xffffffff82758ad0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8185b115
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0xffffffff82758ad0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 1
MOV QWORD PTR[RBP - 112], 2
JMP .Lkd_export
.Lkd_exit_88:
MOVABS R15, 0xffffffff8276eee0
MOV QWORD PTR[RBP - 72], R15
MOVABS R15, 0xffffffff8276eee0
MOV QWORD PTR[RBP - 80], R15
MOVABS R15, 0x0
MOV QWORD PTR[RBP - 88], R15
MOV QWORD PTR[RBP - 96], 5
MOV QWORD PTR[RBP - 104], 9
MOV QWORD PTR[RBP - 112], 0
JMP .Lkd_export
.Lkd_exit_89:
MOV QWORD PTR[RBP - 72], R14
MOVABS R15, 0xffffffff8276eee0
MOV QWORD PTR[RBP - 80], R15
MOV QWORD PTR[RBP - 88], R14
MOV QWORD PTR[RBP - 96], 3
MOV QWORD PTR[RBP - 104], 11
MOV QWORD PTR[RBP - 112], 3
JMP .Lkd_export


.Lkd_export:
	/* The generated exit has already flushed mapped source GPRs, recovered
	 * physical R12/R13 as BP/SP and written the exact control result slots.
	 * Save all resident source values before reusing RAX/R14 for control. */
	mov QWORD PTR[R11 + 16], r12
	mov QWORD PTR[R11 + 8], r13
	mov QWORD PTR[R11 + 64], rbx
	mov QWORD PTR[R11 + 72], r10
	mov QWORD PTR[R11 + 80], r9
	mov QWORD PTR[R11 + 88], r8
	mov QWORD PTR[R11 + 96], rax
	mov QWORD PTR[R11 + 104], rcx
	mov QWORD PTR[R11 + 112], rdx
	mov QWORD PTR[R11 + 120], rsi
	mov QWORD PTR[R11 + 128], rdi
	mov rax, QWORD PTR[RBP - 72]
	mov QWORD PTR[R11 + 0], rax
	mov r14, QWORD PTR[RBP - 64]
	mov rax, QWORD PTR[RBP - 96]
	mov QWORD PTR[r14 + 16], rax
	mov rax, QWORD PTR[RBP - 104]
	mov QWORD PTR[r14 + 24], rax
	mov rax, QWORD PTR[RBP - 80]
	mov QWORD PTR[r14 + 32], rax
	mov rax, QWORD PTR[RBP - 88]
	mov QWORD PTR[r14 + 40], rax
	mov rax, QWORD PTR[RBP - 112]
	mov QWORD PTR[r14 + 48], rax
	/* Keep all private slots allocated through their final read. Returning
	 * publishes no ownership transfer by itself; lock code owns that order. */
	lea rsp, [rbp - 40]
	pop r15
	pop r14
	pop r13
	pop r12
	pop rbx
	pop rbp
	ret
	.size kd_mm_entry, .-kd_mm_entry
	.section .note.GNU-stack, "", @progbits
