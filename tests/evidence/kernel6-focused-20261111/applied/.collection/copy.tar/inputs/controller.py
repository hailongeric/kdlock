#!/usr/bin/env python3
"""VM-only fresh source/O construction and directly affected compilation.

No network, install, module load, boot or cleanup. Fresh caller-pinned inputs,
recovery and budgets are required. Any failure retains all output for review.
A timed-out child is not killed or retried. Do not rerun over partial output.
"""
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
CORE='532b68a65bdf96504e2cede6c23a5bc1476d94e9'
BOOT='51b49fa4-4d99-457e-a73e-632b690eb95e'
RELEASE='7.0.0-38-kdrebuild6'
BASE=Path('/mnt/kdlock-builds2/kdlock-main-kernel6-532b68a6-rwsem-04')
SOURCE,BUILD,OUT=BASE/'source',BASE/'build',BASE/'receipts/focused-01'
NORMAL=Path('/mnt/kdlock-builds/linux-7.0.0-38-kdlock1')
OLD=Path('/mnt/kdlock-builds2/kdlock-main-build-c6becf81-01a1bc4f')
NORMAL_BUNDLE=Path('/root/kdlock-kernel-baselines/linux70-kdlock1-20261027/manifest.json')
NORMAL_MANIFEST_SHA='1d65f61df1be4ab03e358b456d67165d5c9bdc3edd50cf8f15ad651281feca17'
CONFIG_SHA='31d9701e739a1f6a596ecca0a76fa913e3938ec80e90560b68a72d0bf1628483'
NORMAL_PINS={'Makefile': '7b16bd89f6768317eed05f31b8e9ebea901751fea90a731223fd4f990d0dcc32', 'include/linux/sched.h': 'aee5c39f6114cf358e28e64e7ce53c8358f0f90d70467f2c2e643d4128bfea2d', 'init/Kconfig': 'c94d452b20157fd93b4cdce2147d5f4c777f65b97ea7c98bddbd1a6a30c567a7', 'kernel/Makefile': '18ab5bdeb31f60dd99554e807be2042b2733451d3bd10b74c1e7ea8603c5eeda', 'kernel/exit.c': 'c409a652107d68488ffe1bee096025d6b224736c33dab04ea4441bbc88f63a2f', 'kernel/fork.c': '0bccb1f0e882cfcd68d048271ece6bcce00e0f3e115c3d2770072efabe5bc5a0', 'include/linux/rwsem.h': '4630401ebc68d2e4879e2513d8fd8d418ea7423503b2198fe1699914c2e3747c', 'kernel/locking/rwsem.c': '5d030b8ab20d775f3e3cf92d307b56e8309d0a6d9c9a4d626af91a3ccd53ea65'}
OLD_CORE_PINS={'Kbuild': '08418e3f363d3505c1896e1ef69593dc846b1c3c8c53281008a3c2bb2483484c', 'Kconfig': '2546e02759b4bea08d5a27395e58421d0ef21936d5085281ecfb7236f38cd340', 'include/asm_head.h': 'dcae354686db004a515957fb73f6645d19f98bbb1fe3a07f1b73dfaff318455c', 'include/kd_control.h': '403b7ef160f75b5f149abafd35da59bac89215a5f5e22c4138714d6b6dcbad6a', 'include/kd_mutex.h': '56b8541b70beb5c9b952d66b2eab8f89d57ea9e92bdec4617757fdf5eefdad3e', 'include/kd_mutex_api.h': '086a000a572c40b1657412c57e4cd5773c5efdd8b186dd1db2504a68df49b5f0', 'include/kd_regs.h': '72ee3d149d22570e960e536c6a8c2e1e1bae289b8a2c1c17bd2599e64aa4ca1a', 'include/kd_rwlock_api.h': '971e0cd072fe48f15a1dd21c6b3c89e40acbe3d16bdbcc80efadc77db4d759b3', 'include/kd_rwsem_api.h': 'ad85e2b7f1a41fd92db3998fbb12ffb45b289987dcc862c4f8a3acd22679cefa', 'include/kd_spin_api.h': 'bc34bd6327f35172d2671d11e98eab8a5e50b8aeb5508ad49dc095598a843908', 'include/mutex_api.S': '9957255e54a4f38eb7eb871c7fc30d1e78ce1f7c0dfa1233e586e0f60c20382e', 'include/mutex_entry.S': '6e5c771a27e665100a05198c87e6dbfd58a0a5e6a21bfffd55bd7f1f142be108', 'include/native_resume.S': '6c57676d9194a2f2090d602fdf55bba891add8b6f8d560472bfb4fd7bbf4b0dd', 'include/wrapper.S': '42328e050708ab68ac6f94a1a2d76903e4b0d8cffd273082bb1daabb9b789ff5', 'kernel/channel.c': '17803ac448b5f836c311457451106df047fc73e2dd5a3aa32b837159e3c69b03', 'kernel/channel.h': '606ce81101fc1c53805dc22c870747b6faba3b931302fcf003a3b7bd2fd948f3', 'kernel/compiled_image.c': '0ef92a96b335041523341c2918641cef0c7aa7c0cbfc32e5f3ccd0484db47f2d', 'kernel/compiled_image.h': 'ec54afc42d2aa32079c2c28de7af7ba7141abbdece9c0c1e36361ea6ad2b29c9', 'kernel/control.c': 'c50a6de92ef238f387e023473937c418c02314bd7353082db69915a7fb79853d', 'kernel/control.h': '410021ca0e235e57e093b1056af2cb19d9d2199d679a3811efebaeef53002912', 'kernel/episode.c': '222426417f86b23437bfa13d6f1daa69011517376d37729956dab67e83bcdf59', 'kernel/episode.h': '0ba636b0e61c051dfc2dacdd1167497066d13eb13a3644cd9141bd912d6951a7', 'kernel/exports.c': '91155496da21734f1c8522c3694cace2eee1ff6de816a167262ba563415d1149', 'kernel/feedback.c': 'fb00418fd7443ff0cff4ab5af9d1a4ffe0fd691f29f0b17ae33d8baa653960f0', 'kernel/feedback.h': 'e65def1ab23fdc490a7ab0b18a2f1b8bc00f538c17e62e0f1cacbc6c809a0464', 'kernel/feedback_publish.c': 'eab297e4eb31259d1f0ca9b32be051c6604e2f80d5fe7a0c2fa7c89017c96104', 'kernel/feedback_publish.h': '04c14ae7abb8346230fbe2f6eeadf79c57f91be4cf8204676b7e79a1153d4066', 'kernel/image.c': '2045cb89d88175e9b73f7d3b247b72943fbcfa8eaaa3a2ffede0e670968e2bd3', 'kernel/image.h': '49b080029f0abc3ea87e6230cbb925a22f8dbdea50242b42664ce47b135044e5', 'kernel/image_inputs.h': 'a56154b1717dfa494c767a87355128d92f9f710c9bc4ebdc0729a4ca3f8bdc40', 'kernel/image_owner.c': 'c647127502b78d6a3d0d29040d98bf97bc87e666f5418755a876ff0a6b14ff15', 'kernel/image_owner.h': '0bdc71a22db182ee6ffc89834a30c28a348c1724c60ea6649ef53141380ffccb', 'kernel/jit.c': '9c4314c011f9144edd6f98bfd101452b736735ae005cb1754694367e59b9b5a9', 'kernel/jit.h': '66708e4141a3ae97fb848554862f19e390d6285e46538dba6dc142b0da24d5c3', 'kernel/lifecycle.c': '2c687ff078212732b86ba8438b5e04bb0ae9bc0d7f7ef0a2b2693a793e5585dc', 'kernel/lifecycle.h': '946cb5cad5e7a6895efb3617f935f8369a58e03bccf002ca4ed2bb24d02aafdc', 'kernel/mutex.c': '94d276ad7085289e4c72c6841632aa5f1366c3c4021a33326fd7ab828a14343e', 'kernel/mutex.h': '32f08c5fbc4663938e437c890f802cbff9d902213974d18527ed44a4bf61f7b1', 'kernel/mutex_api.c': '501bd160e8405d993f2698688f93b9034e46b4f7df1bc674385c7a566de9481e', 'kernel/mutex_api.h': '822c098acdadaeb4963d6cfbc299598bba28cd7e204e900eab169e720c54fa6b', 'kernel/mutex_release.c': '2d9639fcf6688e0923b1fcc7f6475edff26957710984785212fe40dda5dcc7f8', 'kernel/mutex_release.h': 'a2805d3e5d1bdff89390c54f9ddf66ed02f5c470d07b5ee83ec51b9304a279ce', 'kernel/native_entry.c': '8d452d7c27a955dafe022af389ccf6b55520f8c69e23f35f9fd7c32f31708aa4', 'kernel/native_entry.h': '80d60672aaa65bb4cdf1884b5f25031571c1ab5e2d7f589cf2fce6524bb70c2e', 'kernel/observation.c': '1d9a4ac626de10516682680904c958bd0af1539eae0828b4236b5e0bea2b2e3a', 'kernel/observation.h': '9f174bfcaab86f4e60777e548ef5194b1fc140e9f5cd19b9310e9fac32a1e3a3', 'kernel/owner_progress.c': '8184208d878b467a7a269c2606029aa22cba64d4a45fd56026855b04171178d3', 'kernel/owner_progress.h': 'cc092ec0df8a74b6b993a6a3a7034ee713a896e0bf0f3a2ed32702692cea1052', 'kernel/request_pool.c': '1a058bfad5ea6440f3f2bdc513a266e84e4cbcf5aa5e61b4aeef2b22b41a1986', 'kernel/request_pool.h': 'f1450e3bc166f0a784809fd496d6471ef5ec13baa25c1e71ecf73e78cb6ecc90', 'kernel/runtime.c': '0006ec746aae8d2aead25a39a41f0566e64eca95fb032ddfa8ec4d4e77340616', 'kernel/runtime.h': '2286ea3d88ab01021b8512e6c6971ec7fce2935d162dc28e1542e3c64202f983', 'kernel/rw.c': '97578cfdce915329e1f32da0f6d9b0d8045737d35a8fb241784bbc6d38fbd88f', 'kernel/rw.h': '0e947e9ffd2c9b07969a7037b6e517146943fc72c1e4053cb7244f1776736327', 'kernel/source_epoch.c': '2ef40e9ad005caf758c31f9947bf0b49b67f7bf19eae3a0ec8684090ebe8ff12', 'kernel/source_epoch.h': 'f1838dbd76af0232cbee8909f85dbefe2972bd8bce8271faf909a98ec05fe0bb', 'kernel/source_provider.c': 'c242e5bd9a091461a2c6f9d5d8907102d8986c62897959629c04789f8f0aa49e', 'kernel/source_provider.h': '0bde73385ec8620af476303299b559440d2da181797fb82a1d39a36a26c5f261', 'kernel/source_stack.c': '81141070c7a35a1615d0acff3cb0d6300d2c8ab51d968542ce401cb268fdd302', 'kernel/source_stack.h': '91458b0aa42309ebcf3c8b474bd2420f24574558e3362b1f993f21f0d7d4f16d', 'kernel/state.c': '859f024b50bdc2838f471df486f6e9a749723344018b87fcc85840b8ff7e2c34', 'kernel/state.h': '5d66a68e799d211b9d9ca9487648569ed9d46e93351eb63c2964085a6d36a6a7', 'kernel/target.h': '37c98012e3bca9db2ff3bac401bfb3eefe2c63b0625cb96ec67774bd8e3a225f', 'kernel/task_progress.c': '191d1cf54b30689fe7243e48bd7c3f6e6e34b63ccb3ff9bd2feff034ac307c9e', 'kernel/task_progress.h': 'e51bb0e84a9ce4aed2d575d59f09b3048b16bca4b0d8f8417711cd55635ad4c3', 'kernel/task_setup.c': 'a4a510f30b3dddeff1b9eb8d3f09f25bfd5b98529326aaa3628db7fc4160c30a', 'kernel/task_setup.h': 'bb1e830d13f49f6235dc0587a4828bb3ecf2307fa3a8901698c658399420f975', 'kernel/task_state.c': '6a9c5402fcdb6cdd69d32c892b1873ea3495d3b85c4d2aeede1c84497f19932a', 'kernel/task_state.h': 'e965f08ba0edb079cc2793514d6d813c780f735f79f1a1922bfc10aa196e259f', 'kernel/task_storage.c': '19e6c702ce136a0cff67b905d7e4f7c4d049cf0f2bdbcfba6bbee262ac578caf', 'kernel/task_storage.h': '2f53c1f3899cf311cfc3d9bb6028180d2f40b295ff124ec23b1ccc6388b54b95'}
OLD_FILES={'.config': '31d9701e739a1f6a596ecca0a76fa913e3938ec80e90560b68a72d0bf1628483', 'Module.symvers': '6269dd9fe184e178824740d2f8e44f3238b1c4f10e94f49677ef7f13c7b8e1b3', 'System.map': '127e70c3de6fca251731a5868ff90935e8fcb9c1ee345fd5aaf0b482463e1d07', 'arch/x86/boot/bzImage': 'f68b777ff47360280ef4f8a80ac4e98b662638cef42648b58063b84371972259', 'certs/signing_key.x509': 'd2cc0e225390e9f1b8e355a9b56ac5b7a6532cc49fb724b3d5a56622a23b35a5', 'include/config/auto.conf': 'd731f7137d4af0af8468041db3b03292d174ed184d3916fa9162a29cb8f63243', 'include/config/kernel.release': '6f650592ec28e9b81604b9a96e498daf160e830fe0f0be93bd7b19541a53f161', 'include/generated/autoconf.h': 'ba620d16cd34149765ecae7223c519826d89e1bd51ef996f25af495b7cf18314', 'include/generated/utsrelease.h': 'b646737d9bba8e473f8828fb21a15106611ee53ab9b3c1cdc48c446e28562c6e', 'include/generated/utsversion.h': 'a18f01d70b7d97cb4e0003baf886cd137ecee976dc7dc24d3abd7c762b6bbc3a', 'modules.builtin': 'ef55d7bc5528d2c01f38fc0d8f6473c75e14ec62349898f6529be9bbac871366', 'modules.builtin.modinfo': 'f173376892f5d1a020884e4c6062b51e7cf26718928e1225be5e4fb507c34d0c', 'modules.order': '53585e7c733e6ae2ca38882eb323756a8184adee0d878a49a2489b7f15e62f82', 'vmlinux': '98bda14cfcc4bfa181d73867f8713a51b70f0b834708bb2ed822a59f83c903f6'}
BODY_PINS={'arch/x86/mm/fault.c': '20513a2bde41a23b6ec98a6665899837ac3d452c93561c188f9f8bb6e9913f73', 'include/linux/mm.h': '92c812f7d025c2edafba391fcbda7e2f62ff2763c0d2682dbb02696d194b1f59', 'include/linux/mm_types.h': '6a96679d9cc00ab4c967a9f6693727896903d1a0f0bd0273121385262b95c9aa', 'include/linux/mmap_lock.h': '4c10da7d1cf32d7ffc1f052d93c15403774ecb6a2b4dfd83cabb358d0bcea759', 'mm/memory.c': '8dcd3330503799b97b1cdca547f5720e70b4879be7ccb1aabe0086c9c610a127', 'mm/mmap.c': '26097665c7cfaf7b28c0be7a8b1362b80b51d497033af24278b8a0444d2f1c5b', 'mm/mmap_lock.c': '0694371fa007d5d88d512ce169a05085353f332c44c76eeb2b7b34c2e0b2a455', 'mm/mprotect.c': '982e96216c2e5e258aeba0d4dc891a4ba3567cc22aedd07ac32d814cc8eebaab', 'mm/util.c': 'dcd21ee1618380902d7217afc844dd810ec98213d2c71a225e3049993d551826', 'mm/vma.c': '8dea0340f92be7b964b2d424459155f04447fb0b69075d02f4b64b58291f7f05', 'mm/vma.h': 'c0ac05052b6359a80457f0c82c7037013c7e0c9bc1f687ff09ebed71772fd3bb'}
UNITS=['kernel/mutex.o', 'kernel/rw.o', 'kernel/rw_native.o', 'kernel/linux_rwsem.o', 'kernel/mutex_release.o', 'kernel/state.o', 'kernel/task_state.o', 'kernel/request_pool.o', 'kernel/owner_progress.o', 'kernel/source_epoch.o', 'kernel/source_provider.o', 'kernel/feedback.o', 'kernel/feedback_publish.o', 'kernel/control.o', 'kernel/channel.o', 'kernel/compiled_image.o', 'kernel/runtime.o', 'kernel/exports.o', 'kernel/image.o', 'kernel/image_owner.o', 'kernel/jit.o', 'kernel/native_entry.o', 'kernel/observation.o', 'kernel/episode.o', 'kernel/mutex_api.o', 'kernel/task_progress.o', 'kernel/task_setup.o', 'kernel/task_storage.o', 'kernel/lifecycle.o', 'kernel/source_stack.o', 'include/mutex_api.o', 'include/mutex_entry.o', 'include/native_resume.o']
ENV_KEYS=('KCFLAGS','KAFLAGS','KCPPFLAGS','CFLAGS_KERNEL','CFLAGS_MODULE','AFLAGS_KERNEL','AFLAGS_MODULE','LLVM','LLVM_IAS','CC','LD','HOSTCC','CROSS_COMPILE','KBUILD_OUTPUT','KBUILD_EXTMOD','KCONFIG_CONFIG','ARCH')
record=None

def require(v,m):
 if not v:raise RuntimeError(m)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def put(name,value):
 p=OUT/name;tmp=p.with_name('.'+p.name+'.new');data=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
 with tmp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.replace(tmp,p);fd=os.open(OUT,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def hashes(root,pins):
 out={}
 for name,expected in pins.items():
  p=root/name;require(p.is_file() and not p.is_symlink(),'missing/nonregular pinned file: '+str(p));s=p.stat();value=sha(p);t=p.stat();require((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns),'changing pinned file');require(value==expected,'pinned byte mismatch: '+str(p));out[name]=value
 return out
def headroom(path):
 s=os.statvfs(path);return s.f_bavail*s.f_frsize
def idle():
 value=dict(boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),release=os.uname().release,taint=Path('/proc/sys/kernel/tainted').read_text().strip(),busy=[],dthreads=[])
 require((value['boot'],value['release'],value['taint'])==(BOOT,'7.0.0-38-kdlock1','0'),'normal guest identity differs')
 require(not any('fixture' in s for s in Path('/proc/modules').read_text().splitlines()),'fixture module retained')
 require(not any('fixture' in p.name for p in Path('/dev').iterdir()),'fixture controls retained')
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  try:
   comm=(p/'comm').read_text().strip()
   if comm in ('make','gmake','cc1','cc1plus','gcc','gcc-15','clang','ld','ld.bfd','as','objtool','fstrim','depmod','insmod','rmmod') or comm.startswith(('kd-fixture/','kd-scene/','kd-reader/')):value['busy'].append(dict(pid=int(p.name),comm=comm))
   for t in (p/'task').iterdir():
    status=(t/'status').read_text()
    if '\nState:\tD ' in '\n'+status:value['dthreads'].append(dict(pid=int(p.name),tid=int(t.name),wchan=(t/'wchan').read_text().strip()))
  except (FileNotFoundError,ProcessLookupError):pass
 require(not value['busy'] and not value['dthreads'],'active build/workload or blocked task: '+json.dumps(value,sort_keys=True))
 return value
def recovery(path,expected,minimum):
 require(sha(path)==expected,'recovery receipt SHA mismatch');v=json.loads(path.read_text())
 # Accept the actual reviewed host-read receipt, or the older normalized HMP
 # receipt. Neither form authorizes monitor commands from this guest helper.
 if 'hmp' in v:
  require(v['hostname']=='Super-Server' and v['pid']==257489 and v['exe']=='/usr/bin/qemu-system-x86_64','host/QEMU identity differs')
  captured=datetime.datetime.fromisoformat(v['utc']).timestamp();items=v['hmp'];images=v['images'];require(len(images)==3 and all(r['open_fds'] and r['path']==r['realpath'] for r in images),'three attached image references absent');available=min(r['host_available'] for r in images)
 else:
  captured=v['unix'];items=v['commands'];available=v['host_free_bytes']
 require(0<=time.time()-captured<=900,'fresh recovery receipt required');commands={r['command']:r['output'] for r in items};require('VM status: running' in commands.get('info status',''),'VM not running');listing=commands.get('info snapshots','');require('List of snapshots present on all disks:' in listing,'all-disk list absent');all_disks=listing.split('List of snapshots present on all disks:',1)[1].split('List of partial',1)[0];require('kdlock-builddisk-clean-20261031' in all_disks,'complete recovery tag absent');require(available>=minimum,'host free budget');return dict(captured_unix=captured,host_free_bytes=available,raw=v)
def execute(label,argv,deadline):
 require(time.monotonic()<deadline,'deadline expired before dispatch');log=OUT/(label+'.log');row=dict(label=label,argv=argv,utc=time.time());record['commands'].append(row);put('result.json',record)
 with log.open('xb') as output:
  child=subprocess.Popen(argv,stdout=output,stderr=subprocess.STDOUT,env=dict(os.environ,LC_ALL='C',PYTHONDONTWRITEBYTECODE='1'));row['pid']=child.pid;put('result.json',record)
  while child.poll() is None:
   if time.monotonic()>deadline:
    row['status']='TIMEOUT_CHILD_RETAINED';row['elapsed_seconds']=time.time()-row['utc'];put('result.json',record);raise TimeoutError('child retained; do not retry: '+str(child.pid))
   time.sleep(.25)
  row['returncode']=child.returncode;row['elapsed_seconds']=time.time()-row['utc'];row['log_sha256']=sha(log);put('result.json',record);require(child.returncode==0,label+' failed; retained output')
 return log

def main():
 global record
 ap=argparse.ArgumentParser(description=__doc__)
 for key in ('input','package-manifest','package-manifest-sha','recovery','recovery-sha'):ap.add_argument('--'+key,required=True)
 for key in ('seconds','jobs','root-floor','output-floor','host-floor'):ap.add_argument('--'+key,type=int,required=True)
 args=ap.parse_args();require(os.geteuid()==0,'guest root required');require(args.jobs==8 and 1<=args.seconds<=900,'reviewed8job/900s bounds');require(args.root_floor>=1024**3 and args.output_floor>=48*1024**3 and args.host_floor>=48*1024**3,'reviewed space floors');require(not any(k in os.environ for k in ENV_KEYS) and not any(k.startswith(('CFLAGS','AFLAGS')) or k in ('MAKEFLAGS','MFLAGS') for k in os.environ),'compiler/build environment override present')
 for p in (SOURCE,BUILD,OUT):require(not os.path.lexists(p),'fresh candidate/output required: '+str(p))
 require(BASE.resolve()==BASE and not any(BASE==p or p in BASE.parents for p in (NORMAL,OLD)),'candidate overlaps protected inputs')
 inp=Path(args.input);manifest_path=Path(args.package_manifest);require(inp.resolve(strict=True)==inp and inp.is_dir(),'canonical immutable package input');require(sha(manifest_path)==args.package_manifest_sha,'package manifest SHA mismatch');manifest=json.loads(manifest_path.read_text());require(manifest['core_git_head']==CORE and manifest['intended_kernelrelease']==RELEASE,'core/release identity mismatch');package_before=hashes(inp,manifest['files']);state=idle();require(headroom('/')>=args.root_floor and headroom(BASE.parent)>=args.output_floor,'guest headroom below reviewed budget');rec=recovery(Path(args.recovery),args.recovery_sha,args.host_floor)
 require(sha(NORMAL_BUNDLE)==NORMAL_MANIFEST_SHA,'authenticated normal bundle identity changed');normal_before=hashes(NORMAL/'source',NORMAL_PINS);old_core=hashes(OLD/'source/kernel/kdlock',OLD_CORE_PINS);old_before=hashes(OLD/'build',OLD_FILES);require(sha(OLD/'build/.config')==CONFIG_SHA,'seed config differs');bodies=hashes(NORMAL/'source',BODY_PINS)
 OUT.mkdir(parents=True,mode=0o700);record=dict(status='PREPARED',core_git_head=CORE,source_snapshot_git_head=manifest['source_snapshot_git_head'],kernelrelease=RELEASE,normal_source=str(NORMAL/'source'),normal_manifest_sha256=NORMAL_MANIFEST_SHA,kernel5_preserved=str(OLD),source=str(SOURCE),build=str(BUILD),normal_before=normal_before,kernel5_before=old_before,kernel5_core_before=old_core,package_before=package_before,recovery_sha256=args.recovery_sha,identity_before=state,headroom_before=dict(root=headroom('/'),builds2=headroom(BASE.parent),host=rec['host_free_bytes']),commands=[],scope='Fresh source/O and focused compile only; no full kernel/modules/install/load/boot.');put('result.json',record);deadline=time.monotonic()+args.seconds
 # ext4/cross-device cloning may not support reflink/hardlink. cp's independent
 # byte-copy fallback retains protected source inodes; no hardlink is requested.
 execute('copy-normal-source',['cp','-a','--reflink=auto','--',str(NORMAL/'source'),str(SOURCE)],deadline);hashes(SOURCE,NORMAL_PINS);hashes(SOURCE,BODY_PINS);BUILD.mkdir(mode=0o700);shutil.copyfile(OLD/'build/.config',BUILD/'.config');require(sha(BUILD/'.config')==CONFIG_SHA,'config seed copy mismatch');package=SOURCE/'kernel/kdlock';require(not package.exists(),'new package location already occupied');package.mkdir()
 for name in manifest['files']:
  target=package/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(inp/name,target)
 hashes(package,manifest['files']);installer=package/manifest['installer'];common=['--tree',str(SOURCE),'--build',str(BUILD),'--package',str(package),'--source-identity','Ubuntu linux=7.0.0-38.38 with protected kdlock1 source changes','--package-identity',CORE]
 inspection=execute('integration-inspect',['python3','-B',str(installer),'inspect']+common,deadline);pins=json.loads(inspection.read_text());require(pins['source_files']==NORMAL_PINS and pins['package_files']=={n:h for n,h in manifest['files'].items() if n!=manifest['installer']},'inspected source/package differs from external pins');bound=[]
 for name in ('source-fingerprint','config-sha256','package-fingerprint'):bound+=['--'+name,pins[name.replace('-','_')]]
 execute('integration-plan',['python3','-B',str(installer),'plan']+common+bound,deadline)
 protect=[]
 for p in [NORMAL/'source',NORMAL/'build',OLD/'source',OLD/'build',inp]:protect+=['--protected-tree',str(p)]
 execute('integration-apply',['python3','-B',str(installer),'apply']+common+bound+protect+['--idle-confirmed','--receipt-dir',str(BASE/'receipts/integration-application')],deadline)
 execute('integration-verify',['python3','-B',str(installer),'verify']+common+['--receipt-dir',str(BASE/'receipts/integration-application')],deadline)
 applied=json.loads((BASE/'receipts/integration-application/manifest.json').read_text());require(applied['format']=='kdlock.exact-target-integration.v2' and len(applied['after'])==7,'exact seven-file integration receipt differs')
 make=['make','-C',str(SOURCE),'O='+str(BUILD),'KERNELRELEASE='+RELEASE];execute('olddefconfig',make+['olddefconfig'],deadline);require(sha(BUILD/'.config')==CONFIG_SHA,'olddefconfig changed reviewed configuration');hashes(SOURCE,BODY_PINS)
 execute('focused-objects',make+['-j8','V=1']+['kernel/kdlock/'+u for u in UNITS]+['kernel/fork.o','kernel/exit.o','kernel/locking/rwsem.o','mm/mmap.o','mm/vma.o','mm/mmap_lock.o','mm/util.o','mm/memory.o'],deadline)
 require((BUILD/'include/config/kernel.release').read_text().strip()==RELEASE,'actual output release differs');record['normal_after']=hashes(NORMAL/'source',NORMAL_PINS);record['kernel5_after']=hashes(OLD/'build',OLD_FILES);record['kernel5_core_after']=hashes(OLD/'source/kernel/kdlock',OLD_CORE_PINS);record['package_after']=hashes(inp,manifest['files']);record['body_after']=hashes(SOURCE,BODY_PINS);record['identity_after']=idle();record['headroom_after']=dict(root=headroom('/'),builds2=headroom(BASE.parent));record['config_sha256']=sha(BUILD/'.config');record['target_units']=dict(core=len(UNITS),native=8);record['status']='FOCUSED_COMPILE_COMPLETE';put('result.json',record);print(json.dumps(dict(status=record['status'],receipt=str(OUT/'result.json'),source=str(SOURCE),build=str(BUILD)),indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:
  if record is not None:record['status']='FAILED_OR_INCOMPLETE';record['error']=repr(e);put('result.json',record)
  raise
