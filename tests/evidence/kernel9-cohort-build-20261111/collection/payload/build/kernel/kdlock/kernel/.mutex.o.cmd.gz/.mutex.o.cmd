savedcmd_kernel/kdlock/kernel/mutex.o := gcc -Wp,-MMD,kernel/kdlock/kernel/.mutex.o.d -nostdinc -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include -I./arch/x86/include/generated -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include -I./include -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi -I./include/generated/uapi -include /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler-version.h -include /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kconfig.h -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/ubuntu/include -include /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler_types.h -D__KERNEL__ -fmacro-prefix-map=/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/= -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -mno-sse4a -fcf-protection=none -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -march=x86-64 -mtune=generic -mno-red-zone -mcmodel=kernel -mstack-protector-guard-reg=gs -mstack-protector-guard-symbol=__ref_stack_chk_guard -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -fzero-init-padding-bits=all -fno-stack-clash-protection -fzero-call-used-regs=used-gpr -pg -mrecord-mcount -mfentry -DCC_USING_FENTRY -fmin-function-alignment=16 -fstrict-flex-arrays=3 -fms-extensions -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=1024 -Wno-main -Wno-type-limits -Wno-dangling-pointer -Wvla-larger-than=1 -Wno-pointer-sign -Wcast-function-type -Wno-unterminated-string-initialization -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -g -gdwarf-5 -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/include -include /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/target.h  -fsanitize=bounds-strict -fsanitize=shift -fsanitize=bool -fsanitize=enum   -I/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock -Ikernel/kdlock    -DKBUILD_MODFILE='"kernel/kdlock/kdlock_rebuild"' -DKBUILD_BASENAME='"mutex"' -DKBUILD_MODNAME='"kdlock_rebuild"' -D__KBUILD_MODNAME=kdlock_rebuild -c -o kernel/kdlock/kernel/mutex.o /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/mutex.c  

source_kernel/kdlock/kernel/mutex.o := /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/mutex.c

deps_kernel/kdlock/kernel/mutex.o := \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/CC_HAS_ASSUME) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/FORTIFY_SOURCE) \
    $(wildcard include/config/UBSAN_BOUNDS) \
    $(wildcard include/config/CC_HAS_COUNTED_BY_PTR) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_INTEGER_WRAP) \
    $(wildcard include/config/CFI) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_BROKEN_COUNTED_BY_REF) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler-context-analysis.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler_attributes.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler-gcc.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/target.h \
    $(wildcard include/config/PREEMPT_RT) \
  include/generated/uapi/linux/version.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
    $(wildcard include/config/DEBUG_BUGVERBOSE_DETAILED) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/stringify.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/objtool.h \
    $(wildcard include/config/OBJTOOL) \
    $(wildcard include/config/FRAME_POINTER) \
    $(wildcard include/config/MITIGATION_UNRET_ENTRY) \
    $(wildcard include/config/MITIGATION_SRSO) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/objtool_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/types.h \
  arch/x86/include/generated/uapi/asm/types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/int-ll64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/int-ll64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/bitsperlong.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitsperlong.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/bitsperlong.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/posix_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/stddef.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/stddef.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/posix_types_64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/posix_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/annotate.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/asm.h \
    $(wildcard include/config/KPROBES) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/asm-offsets.h \
  include/generated/asm-offsets.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/extable_fixup_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
  arch/x86/include/generated/asm/rwonce.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/rwonce.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
    $(wildcard include/config/SMP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/once_lite.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/stdarg.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/build_bug.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kern_levels.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/GENDWARFKSYMS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/CALL_PADDING) \
    $(wildcard include/config/MITIGATION_RETHUNK) \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
    $(wildcard include/config/MITIGATION_SLS) \
    $(wildcard include/config/FUNCTION_PADDING_BYTES) \
    $(wildcard include/config/UML) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/ibt.h \
    $(wildcard include/config/X86_KERNEL_IBT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ratelimit_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/bits.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/bits.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/const.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/const.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/bits.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/overflow.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/limits.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/limits.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/limits.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/const.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/param.h \
  arch/x86/include/generated/uapi/asm/param.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/param.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/spinlock_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/qrwlock_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/byteorder.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/byteorder/little_endian.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/byteorder/little_endian.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/swab.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/swab.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/swab.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/byteorder/generic.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/dynamic_debug.h \
    $(wildcard include/config/JUMP_LABEL) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/jump_label.h \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cleanup.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/err.h \
  arch/x86/include/generated/uapi/asm/errno.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/errno.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/errno-base.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/args.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/jump_label.h \
    $(wildcard include/config/HAVE_JUMP_LABEL_HACK) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/nops.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/errno.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/errno.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/DYNAMIC_FTRACE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/align.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/align.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/array_size.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/container_of.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/bitops.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/typecheck.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/kernel.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/sysinfo.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/generic-non-atomic.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/barrier.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/alternative.h \
    $(wildcard include/config/CALL_THUNKS) \
    $(wildcard include/config/MITIGATION_ITS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/barrier.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/X86_CMOV) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/rmwcc.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/sched.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/arch_hweight.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cpufeatures.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/const_hweight.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/instrumented-atomic.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/instrumented.h \
    $(wildcard include/config/DEBUG_ATOMIC) \
    $(wildcard include/config/DEBUG_ATOMIC_LARGEST_ALIGN) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kmsan-checks.h \
    $(wildcard include/config/KMSAN) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/instrumented-non-atomic.h \
    $(wildcard include/config/KCSAN_ASSUME_PLAIN_WRITES_ATOMIC) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/instrumented-lock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/le.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kstrtox.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/math.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/div64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/div64.h \
    $(wildcard include/config/CC_OPTIMIZE_FOR_PERFORMANCE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/minmax.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sprintf.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/trace_printk.h \
    $(wildcard include/config/TRACING) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/instruction_pointer.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/util_macros.h \
    $(wildcard include/config/FOO_SUSPEND) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/wordpart.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_NATIVE) \
    $(wildcard include/config/SCHED_INFO) \
    $(wildcard include/config/SCHEDSTATS) \
    $(wildcard include/config/SCHED_CORE) \
    $(wildcard include/config/FAIR_GROUP_SCHED) \
    $(wildcard include/config/RT_GROUP_SCHED) \
    $(wildcard include/config/RT_MUTEXES) \
    $(wildcard include/config/UCLAMP_TASK) \
    $(wildcard include/config/UCLAMP_BUCKETS_COUNT) \
    $(wildcard include/config/KMAP_LOCAL) \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/MEM_ALLOC_PROFILING) \
    $(wildcard include/config/SCHED_CLASS_EXT) \
    $(wildcard include/config/CGROUP_SCHED) \
    $(wildcard include/config/CFS_BANDWIDTH) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
    $(wildcard include/config/BLK_DEV_IO_TRACE) \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/MEMCG_V1) \
    $(wildcard include/config/LRU_GEN) \
    $(wildcard include/config/COMPAT_BRK) \
    $(wildcard include/config/CGROUPS) \
    $(wildcard include/config/BLK_CGROUP) \
    $(wildcard include/config/PSI) \
    $(wildcard include/config/PAGE_OWNER) \
    $(wildcard include/config/EVENTFD) \
    $(wildcard include/config/ARCH_HAS_CPU_PASID) \
    $(wildcard include/config/X86_BUS_LOCK_DETECT) \
    $(wildcard include/config/TASK_DELAY_ACCT) \
    $(wildcard include/config/STACKPROTECTOR) \
    $(wildcard include/config/ARCH_HAS_SCALED_CPUTIME) \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_GEN) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/POSIX_CPUTIMERS) \
    $(wildcard include/config/POSIX_CPU_TIMERS_TASK_WORK) \
    $(wildcard include/config/KEYS) \
    $(wildcard include/config/SYSVIPC) \
    $(wildcard include/config/DETECT_HUNG_TASK) \
    $(wildcard include/config/IO_URING) \
    $(wildcard include/config/AUDIT) \
    $(wildcard include/config/AUDITSYSCALL) \
    $(wildcard include/config/DETECT_HUNG_TASK_BLOCKER) \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/UBSAN) \
    $(wildcard include/config/UBSAN_TRAP) \
    $(wildcard include/config/COMPACTION) \
    $(wildcard include/config/TASK_XACCT) \
    $(wildcard include/config/CPUSETS) \
    $(wildcard include/config/X86_CPU_RESCTRL) \
    $(wildcard include/config/FUTEX) \
    $(wildcard include/config/COMPAT) \
    $(wildcard include/config/PERF_EVENTS) \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/NUMA_BALANCING) \
    $(wildcard include/config/ARCH_HAS_LAZY_MMU_MODE) \
    $(wildcard include/config/FAULT_INJECTION) \
    $(wildcard include/config/LATENCYTOP) \
    $(wildcard include/config/KUNIT) \
    $(wildcard include/config/FUNCTION_GRAPH_TRACER) \
    $(wildcard include/config/MEMCG) \
    $(wildcard include/config/UPROBES) \
    $(wildcard include/config/BCACHE) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/LIVEPATCH) \
    $(wildcard include/config/SECURITY) \
    $(wildcard include/config/BPF_SYSCALL) \
    $(wildcard include/config/KSTACK_ERASE) \
    $(wildcard include/config/KSTACK_ERASE_METRICS) \
    $(wildcard include/config/RANDOMIZE_KSTACK_OFFSET) \
    $(wildcard include/config/X86_MCE) \
    $(wildcard include/config/KRETPROBES) \
    $(wildcard include/config/RETHOOK) \
    $(wildcard include/config/ARCH_HAS_PARANOID_L1D_FLUSH) \
    $(wildcard include/config/RV) \
    $(wildcard include/config/RV_PER_TASK_MONITORS) \
    $(wildcard include/config/USER_EVENTS) \
    $(wildcard include/config/UNWIND_USER) \
    $(wildcard include/config/SCHED_PROXY_EXEC) \
    $(wildcard include/config/PREEMPTION) \
    $(wildcard include/config/MEM_ALLOC_PROFILING_DEBUG) \
    $(wildcard include/config/SCHED_MM_CID) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/sched.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/current.h \
    $(wildcard include/config/USE_X86_SEG_SUPPORT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/cache.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cache.h \
    $(wildcard include/config/X86_L1_CACHE_SHIFT) \
    $(wildcard include/config/X86_INTERNODE_CACHE_SHIFT) \
    $(wildcard include/config/X86_VSMP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/CC_HAS_NAMED_AS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/percpu.h \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/percpu-defs.h \
    $(wildcard include/config/ARCH_MODULE_NEEDS_WEAK_PER_CPU) \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/processor.h \
    $(wildcard include/config/X86_VMX_FEATURE_NAMES) \
    $(wildcard include/config/X86_IOPL_IOPERM) \
    $(wildcard include/config/VM86) \
    $(wildcard include/config/X86_USER_SHADOW_STACK) \
    $(wildcard include/config/X86_DEBUG_FPU) \
    $(wildcard include/config/PARAVIRT_XXL) \
    $(wildcard include/config/CPU_SUP_AMD) \
    $(wildcard include/config/XEN) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/processor-flags.h \
    $(wildcard include/config/MITIGATION_PAGE_TABLE_ISOLATION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/processor-flags.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mem_encrypt.h \
    $(wildcard include/config/ARCH_HAS_MEM_ENCRYPT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/mem_encrypt.h \
    $(wildcard include/config/X86_MEM_ENCRYPT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cc_platform.h \
    $(wildcard include/config/ARCH_HAS_CC_PLATFORM) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/math_emu.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/ptrace.h \
    $(wildcard include/config/PARAVIRT) \
    $(wildcard include/config/IA32_EMULATION) \
    $(wildcard include/config/X86_DEBUGCTLMSR) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/segment.h \
    $(wildcard include/config/XEN_PV) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/page_types.h \
    $(wildcard include/config/PHYSICAL_START) \
    $(wildcard include/config/PHYSICAL_ALIGN) \
    $(wildcard include/config/DYNAMIC_PHYSICAL_MASK) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/page.h \
    $(wildcard include/config/PAGE_SHIFT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/page_64_types.h \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/RANDOMIZE_BASE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/kaslr.h \
    $(wildcard include/config/RANDOMIZE_MEMORY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/ptrace.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/ptrace-abi.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/paravirt-base.h \
    $(wildcard include/config/PARAVIRT_SPINLOCKS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/proto.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/ldt.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/sigcontext.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cpuid/api.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cpuid/types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/string.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/string_64.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/paravirt.h \
    $(wildcard include/config/DEBUG_ENTRY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/ZERO_CALL_USED_REGS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/desc_defs.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/X86_INTEL_MEMORY_PROTECTION_KEYS) \
    $(wildcard include/config/X86_PAE) \
    $(wildcard include/config/MEM_SOFT_DIRTY) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/PROC_FS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/pgtable_64_types.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/sparsemem.h \
    $(wildcard include/config/SPARSEMEM) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/nospec-branch.h \
    $(wildcard include/config/CALL_THUNKS_DEBUG) \
    $(wildcard include/config/MITIGATION_CALL_DEPTH_TRACKING) \
    $(wildcard include/config/MITIGATION_IBPB_ENTRY) \
    $(wildcard include/config/BPF_JIT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/static_key.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/msr-index.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/unwind_hints.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/orc_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/GEN-for-each-reg.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cpumask.h \
    $(wildcard include/config/FORCE_NR_CPUS) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/atomic.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/atomic.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cmpxchg.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cmpxchg_64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/atomic64_64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/atomic/atomic-long.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/atomic/atomic-instrumented.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/bitmap.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/find.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/string.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/fortify-string.h \
    $(wildcard include/config/CC_HAS_KASAN_MEMINTRINSIC_PREFIX) \
    $(wildcard include/config/GENERIC_ENTRY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/bitmap-str.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cpumask_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/gfp_types.h \
    $(wildcard include/config/KASAN_HW_TAGS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/numa.h \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
    $(wildcard include/config/HAVE_ARCH_NODE_DEV_GROUP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/nodemask.h \
    $(wildcard include/config/HIGHMEM) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/nodemask_types.h \
    $(wildcard include/config/NODES_SHIFT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/random.h \
    $(wildcard include/config/VMGENID) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/list.h \
    $(wildcard include/config/LIST_HARDENED) \
    $(wildcard include/config/DEBUG_LIST) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/random.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/ioctl.h \
  arch/x86/include/generated/uapi/asm/ioctl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/ioctl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/ioctl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/irqnr.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/irqnr.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/frame.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/page.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/page_64.h \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/X86_VSYSCALL_EMULATION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/DEBUG_VM_IRQSOFF) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/range.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/memory_model.h \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/pfn.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/getorder.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/special_insns.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/irqflags.h \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/irqflags_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/irqflags.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/fpu/types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/vmxfeatures.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/vdso/processor.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/shstk.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/personality.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/personality.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/math64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/thread_info.h \
    $(wildcard include/config/ARCH_HAS_PREEMPT_LAZY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/SH) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/restart_block.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/time64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/time64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/time.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/time_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/thread_info.h \
    $(wildcard include/config/X86_FRED) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cpufeature.h \
  arch/x86/include/generated/asm/cpufeaturemasks.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/thread_info_tif.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/preempt.h \
    $(wildcard include/config/PREEMPT_COUNT) \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPT_NONE) \
    $(wildcard include/config/PREEMPT_VOLUNTARY) \
    $(wildcard include/config/PREEMPT) \
    $(wildcard include/config/PREEMPT_LAZY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/preempt.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/smp_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/pid_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sem_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/shm.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/shmparam.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kmsan_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mutex_types.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/osq_lock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/spinlock_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rwlock_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/plist_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/hrtimer_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/timerqueue_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rbtree_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/timer_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/seccomp_types.h \
    $(wildcard include/config/SECCOMP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/refcount_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/resource.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/resource.h \
  arch/x86/include/generated/uapi/asm/resource.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/resource.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/resource.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/latencytop.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/prio.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/signal_types.h \
    $(wildcard include/config/OLD_SIGACTION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/signal.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/signal.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/signal.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/signal-defs.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/siginfo.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/siginfo.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/spinlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/bottom_half.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
    $(wildcard include/config/CSD_LOCK_WAIT_DEBUG) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/smp.h \
    $(wildcard include/config/DEBUG_NMI_SELFTEST) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cpumask.h \
  arch/x86/include/generated/asm/mmiowb.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/spinlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/qspinlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/paravirt-spinlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/qspinlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/qrwlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/qrwlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rwlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/syscall_user_dispatch_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mm_types_task.h \
    $(wildcard include/config/ARCH_WANT_BATCHED_UNMAP_TLB_FLUSH) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/tlbbatch.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/netdevice_xmit.h \
    $(wildcard include/config/NET_ACT_MIRRED) \
    $(wildcard include/config/NET_EGRESS) \
    $(wildcard include/config/NF_DUP_NETDEV) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/task_io_accounting.h \
    $(wildcard include/config/TASK_IO_ACCOUNTING) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/posix-timers_types.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rseq_types.h \
    $(wildcard include/config/RSEQ) \
    $(wildcard include/config/RSEQ_SLICE_EXTENSION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/irq_work_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/workqueue_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/seqlock_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kcsan.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rv.h \
    $(wildcard include/config/RV_LTL_MONITOR) \
    $(wildcard include/config/RV_REACTORS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/uidgid_types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/tracepoint-defs.h \
    $(wildcard include/config/TRACEPOINTS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/unwind_deferred_types.h \
  arch/x86/include/generated/asm/kmap_size.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/kmap_size.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL) \
  include/generated/rq-offsets.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/ext.h \
    $(wildcard include/config/EXT_GROUP_SCHED) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rhashtable-types.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/alloc_tag.h \
    $(wildcard include/config/MEM_ALLOC_PROFILING_ENABLED_BY_DEFAULT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/codetag.h \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/CODE_TAGGING) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mutex.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/debug_locks.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/task.h \
    $(wildcard include/config/HAVE_EXIT_THREAD) \
    $(wildcard include/config/ARCH_WANTS_DYNAMIC_TASK_STRUCT) \
    $(wildcard include/config/HAVE_ARCH_THREAD_STRUCT_WHITELIST) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcupdate.h \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/RCU_STRICT_GRACE_PERIOD) \
    $(wildcard include/config/RCU_LAZY) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/VIRT_XFER_TO_GUEST_WORK) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/context_tracking_irq.h \
    $(wildcard include/config/CONTEXT_TRACKING_IDLE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcutree.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/refcount.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/uaccess.h \
    $(wildcard include/config/ARCH_HAS_SUBPAGE_FAULTS) \
    $(wildcard include/config/HARDENED_USERCOPY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/fault-inject-usercopy.h \
    $(wildcard include/config/FAULT_INJECTION_USERCOPY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/nospec.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ucopysize.h \
    $(wildcard include/config/HARDENED_USERCOPY_DEFAULT_ON) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/uaccess.h \
    $(wildcard include/config/CC_HAS_ASM_GOTO_OUTPUT) \
    $(wildcard include/config/CC_HAS_ASM_GOTO_TIED_OUTPUT) \
    $(wildcard include/config/ARCH_HAS_COPY_MC) \
    $(wildcard include/config/X86_INTEL_USERCOPY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mm_types.h \
    $(wildcard include/config/KDLOCK_MMAP) \
    $(wildcard include/config/HAVE_ALIGNED_STRUCT_PAGE) \
    $(wildcard include/config/SLAB_OBJ_EXT) \
    $(wildcard include/config/HUGETLB_PMD_PAGE_TABLE_SHARING) \
    $(wildcard include/config/SLAB_FREELIST_HARDENED) \
    $(wildcard include/config/USERFAULTFD) \
    $(wildcard include/config/ANON_VMA_NAME) \
    $(wildcard include/config/PER_VMA_LOCK) \
    $(wildcard include/config/SWAP) \
    $(wildcard include/config/HAVE_ARCH_COMPAT_MMAP_BASES) \
    $(wildcard include/config/MEMBARRIER) \
    $(wildcard include/config/FUTEX_PRIVATE_HASH) \
    $(wildcard include/config/ARCH_HAS_ELF_CORE_EFLAGS) \
    $(wildcard include/config/AIO) \
    $(wildcard include/config/MMU_NOTIFIER) \
    $(wildcard include/config/TRANSPARENT_HUGEPAGE) \
    $(wildcard include/config/SPLIT_PMD_PTLOCKS) \
    $(wildcard include/config/HUGETLB_PAGE) \
    $(wildcard include/config/IOMMU_MM_DATA) \
    $(wildcard include/config/KSM) \
    $(wildcard include/config/LRU_GEN_WALKS_MMU) \
    $(wildcard include/config/MM_ID) \
    $(wildcard include/config/CORE_DUMP_DEFAULT_ELF_HEADERS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/auxvec.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/auxvec.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/auxvec.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kref.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rbtree.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/maple_tree.h \
    $(wildcard include/config/MAPLE_RCU_DISABLED) \
    $(wildcard include/config/DEBUG_MAPLE_TREE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rwsem.h \
    $(wildcard include/config/KDLOCK_REBUILD) \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/../../kernel/kdlock/include/kd_linux_rwsem_query.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/../../kernel/kdlock/include/kd_linux_rwsem.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/../../kernel/kdlock/include/kd_mutex_api.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/../../kernel/kdlock/include/kd_linux_rwsem_source.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/completion.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/swait.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/wait.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/uprobes.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
    $(wildcard include/config/NO_HZ_COMMON) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ktime.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/jiffies.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/time.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/time32.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/timex.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/timex.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/timex.h \
    $(wildcard include/config/X86_TSC) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/tsc.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/msr.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/msr.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/shared/msr.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/percpu.h \
    $(wildcard include/config/RANDOM_KMALLOC_CACHES) \
    $(wildcard include/config/PAGE_SIZE_4KB) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/time32.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/time.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/jiffies.h \
  include/generated/timeconst.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/vdso/ktime.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/timekeeping.h \
    $(wildcard include/config/POSIX_AUX_CLOCKS) \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/clocksource_ids.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/seqlock.h \
    $(wildcard include/config/CC_IS_GCC) \
    $(wildcard include/config/GCC_VERSION) \
    $(wildcard include/config/UBSAN_ALIGNMENT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/uprobes.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/notifier.h \
    $(wildcard include/config/TREE_SRCU) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/NEED_SRCU_NMI_SAFE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcu_segcblist.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/srcutree.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/page-flags-layout.h \
  include/generated/bounds.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/percpu_counter.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/mmu.h \
    $(wildcard include/config/MODIFY_LDT_SYSCALL) \
    $(wildcard include/config/ADDRESS_MASKING) \
    $(wildcard include/config/BROADCAST_TLB_FLUSH) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mmap_lock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/mm.h \
    $(wildcard include/config/MMU_LAZY_TLB_REFCOUNT) \
    $(wildcard include/config/ARCH_HAS_MEMBARRIER_CALLBACKS) \
    $(wildcard include/config/ARCH_HAS_SYNC_CORE_BEFORE_USERMODE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/gfp.h \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/ZONE_DEVICE) \
    $(wildcard include/config/CONTIG_ALLOC) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mmzone.h \
    $(wildcard include/config/ARCH_FORCE_MAX_ORDER) \
    $(wildcard include/config/PAGE_BLOCK_MAX_ORDER) \
    $(wildcard include/config/CMA) \
    $(wildcard include/config/MEMORY_ISOLATION) \
    $(wildcard include/config/ZSMALLOC) \
    $(wildcard include/config/UNACCEPTED_MEMORY) \
    $(wildcard include/config/IOMMU_SUPPORT) \
    $(wildcard include/config/LRU_GEN_STATS) \
    $(wildcard include/config/MEMORY_FAILURE) \
    $(wildcard include/config/PAGE_EXTENSION) \
    $(wildcard include/config/DEFERRED_STRUCT_PAGE_INIT) \
    $(wildcard include/config/HAVE_MEMORYLESS_NODES) \
    $(wildcard include/config/SPARSEMEM_EXTREME) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP_PREINIT) \
    $(wildcard include/config/HAVE_ARCH_PFN_VALID) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/list_nulls.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/pageblock-flags.h \
    $(wildcard include/config/HUGETLB_PAGE_SIZE_VARIABLE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/page-flags.h \
    $(wildcard include/config/PAGE_IDLE_FLAG) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_2) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_3) \
    $(wildcard include/config/MIGRATION) \
    $(wildcard include/config/HUGETLB_PAGE_OPTIMIZE_VMEMMAP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/local_lock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/local_lock_internal.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/zswap.h \
    $(wildcard include/config/ZSWAP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/memory_hotplug.h \
    $(wildcard include/config/ARCH_HAS_ADD_PAGES) \
    $(wildcard include/config/MEMORY_HOTREMOVE) \
  arch/x86/include/generated/asm/mmzone.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/mmzone.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/topology.h \
    $(wildcard include/config/USE_PERCPU_NUMA_NODE_ID) \
    $(wildcard include/config/SCHED_SMT) \
    $(wildcard include/config/GENERIC_ARCH_TOPOLOGY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/arch_topology.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/topology.h \
    $(wildcard include/config/X86_LOCAL_APIC) \
    $(wildcard include/config/SCHED_MC_PRIO) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/mpspec.h \
    $(wildcard include/config/EISA) \
    $(wildcard include/config/X86_MPPARSE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/mpspec_def.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/x86_init.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/apicdef.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/topology.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cpu_smt.h \
    $(wildcard include/config/HOTPLUG_SMT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sync_core.h \
    $(wildcard include/config/ARCH_HAS_PREPARE_SYNC_CORE_CMD) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/sync_core.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/coredump.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/smap.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/extable.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/tlbflush.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mmu_notifier.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/interval_tree.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/invpcid.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/pti.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/pgtable.h \
    $(wildcard include/config/DEBUG_WX) \
    $(wildcard include/config/HAVE_ARCH_TRANSPARENT_HUGEPAGE_PUD) \
    $(wildcard include/config/ARCH_SUPPORTS_PMD_PFNMAP) \
    $(wildcard include/config/ARCH_SUPPORTS_PUD_PFNMAP) \
    $(wildcard include/config/HAVE_ARCH_SOFT_DIRTY) \
    $(wildcard include/config/ARCH_ENABLE_THP_MIGRATION) \
    $(wildcard include/config/PAGE_TABLE_CHECK) \
    $(wildcard include/config/X86_SGX) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/pkru.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/fpu/api.h \
    $(wildcard include/config/MATH_EMULATION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/coco.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/pgtable_uffd.h \
    $(wildcard include/config/PTE_MARKER_UFFD_WP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/page_table_check.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/pgtable_64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/fixmap.h \
    $(wildcard include/config/PROVIDE_OHCI1394_DMA_INIT) \
    $(wildcard include/config/X86_IO_APIC) \
    $(wildcard include/config/PCI_MMCONFIG) \
    $(wildcard include/config/ACPI_APEI_GHES) \
    $(wildcard include/config/INTEL_TXT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/vsyscall.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/fixmap.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/pgtable-invert.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/uaccess_64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/runtime-const.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/access_ok.h \
    $(wildcard include/config/ALTERNATE_USER_ADDRESS_SPACE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/signal.h \
    $(wildcard include/config/SCHED_AUTOGROUP) \
    $(wildcard include/config/BSD_PROCESS_ACCT) \
    $(wildcard include/config/TASKSTATS) \
    $(wildcard include/config/STACK_GROWSUP) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rculist.h \
    $(wildcard include/config/PROVE_RCU_LIST) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/signal.h \
    $(wildcard include/config/DYNAMIC_SIGFRAME) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/jobctl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cred.h \
    $(wildcard include/config/MULTIUSER) \
    $(wildcard include/config/USER_NS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/capability.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/capability.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/uidgid.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/highuid.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/key.h \
    $(wildcard include/config/KEY_NOTIFICATIONS) \
    $(wildcard include/config/NET) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sysctl.h \
    $(wildcard include/config/SYSCTL) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/sysctl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/assoc_array.h \
    $(wildcard include/config/ASSOCIATIVE_ARRAY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/user.h \
    $(wildcard include/config/EPOLL) \
    $(wildcard include/config/VFIO_PCI_ZDEV_KVM) \
    $(wildcard include/config/IOMMUFD) \
    $(wildcard include/config/WATCH_QUEUE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ratelimit.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/pid.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/posix-timers.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/alarmtimer.h \
    $(wildcard include/config/RTC_CLASS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/hrtimer.h \
    $(wildcard include/config/HIGH_RES_TIMERS) \
    $(wildcard include/config/TIME_LOW_RES) \
    $(wildcard include/config/TIMERFD) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/hrtimer_defs.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/timerqueue.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcuref.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/interrupt.h \
    $(wildcard include/config/IRQ_FORCED_THREADING) \
    $(wildcard include/config/GENERIC_IRQ_PROBE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/irqreturn.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/hardirq.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/context_tracking_state.h \
    $(wildcard include/config/CONTEXT_TRACKING_USER) \
    $(wildcard include/config/CONTEXT_TRACKING) \
    $(wildcard include/config/RCU_DYNTICKS_TORTURE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ftrace_irq.h \
    $(wildcard include/config/HWLAT_TRACER) \
    $(wildcard include/config/OSNOISE_TRACER) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/vtime.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING) \
    $(wildcard include/config/IRQ_TIME_ACCOUNTING) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/hardirq.h \
    $(wildcard include/config/CPU_MITIGATIONS) \
    $(wildcard include/config/KVM_INTEL) \
    $(wildcard include/config/KVM) \
    $(wildcard include/config/GUEST_PERF_EVENTS) \
    $(wildcard include/config/X86_THERMAL_VECTOR) \
    $(wildcard include/config/X86_MCE_THRESHOLD) \
    $(wildcard include/config/X86_MCE_AMD) \
    $(wildcard include/config/X86_HV_CALLBACK_VECTOR) \
    $(wildcard include/config/HYPERV) \
    $(wildcard include/config/X86_POSTED_MSI) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/irq.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/irq_vectors.h \
    $(wildcard include/config/PCI_MSI) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/sections.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/sections.h \
    $(wildcard include/config/HAVE_FUNCTION_DESCRIPTORS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/mutex.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/mutex_release.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/observation.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/tracepoint.h \
    $(wildcard include/config/HAVE_SYSCALL_TRACEPOINTS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcupdate_trace.h \
    $(wildcard include/config/TASKS_TRACE_RCU_NO_MB) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/static_call.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cpu.h \
    $(wildcard include/config/GENERIC_CPU_DEVICES) \
    $(wildcard include/config/PM_SLEEP_SMP) \
    $(wildcard include/config/PM_SLEEP_SMP_NONZERO_CPU) \
    $(wildcard include/config/ARCH_HAS_CPU_FINALIZE_INIT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/node.h \
    $(wildcard include/config/HMEM_REPORTING) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/device.h \
    $(wildcard include/config/GENERIC_MSI_IRQ) \
    $(wildcard include/config/ENERGY_MODEL) \
    $(wildcard include/config/PINCTRL) \
    $(wildcard include/config/ARCH_HAS_DMA_OPS) \
    $(wildcard include/config/DMA_DECLARE_COHERENT) \
    $(wildcard include/config/DMA_CMA) \
    $(wildcard include/config/SWIOTLB) \
    $(wildcard include/config/SWIOTLB_DYNAMIC) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_DEVICE) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU_ALL) \
    $(wildcard include/config/DMA_OPS_BYPASS) \
    $(wildcard include/config/DMA_NEED_SYNC) \
    $(wildcard include/config/IOMMU_DMA) \
    $(wildcard include/config/PM) \
    $(wildcard include/config/PM_SLEEP) \
    $(wildcard include/config/OF) \
    $(wildcard include/config/DEVTMPFS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/dev_printk.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/energy_model.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kobject.h \
    $(wildcard include/config/UEVENT_HELPER) \
    $(wildcard include/config/DEBUG_KOBJECT_RELEASE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sysfs.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kernfs.h \
    $(wildcard include/config/KERNFS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/idr.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/radix-tree.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/xarray.h \
    $(wildcard include/config/XARRAY_MULTI) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kobject_ns.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/stat.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/stat.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/stat.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/cpufreq.h \
    $(wildcard include/config/CPU_FREQ) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/topology.h \
    $(wildcard include/config/SCHED_CLUSTER) \
    $(wildcard include/config/SCHED_MC) \
    $(wildcard include/config/CPU_FREQ_GOV_SCHEDUTIL) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/idle.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/sd_flags.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ioport.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/klist.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/pm.h \
    $(wildcard include/config/VT_CONSOLE_SLEEP) \
    $(wildcard include/config/CXL_SUSPEND) \
    $(wildcard include/config/PM_CLK) \
    $(wildcard include/config/PM_GENERIC_DOMAINS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/device/bus.h \
    $(wildcard include/config/ACPI) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/device/class.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/device/devres.h \
    $(wildcard include/config/HAS_IOMEM) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/device/driver.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/module.h \
    $(wildcard include/config/MODULES_TREE_LOOKUP) \
    $(wildcard include/config/STACKTRACE_BUILD_ID) \
    $(wildcard include/config/ARCH_USES_CFI_TRAPS) \
    $(wildcard include/config/MODULE_SIG) \
    $(wildcard include/config/KALLSYMS) \
    $(wildcard include/config/BPF_EVENTS) \
    $(wildcard include/config/DEBUG_INFO_BTF_MODULES) \
    $(wildcard include/config/EVENT_TRACING) \
    $(wildcard include/config/MODULE_UNLOAD) \
    $(wildcard include/config/CONSTRUCTORS) \
    $(wildcard include/config/FUNCTION_ERROR_INJECTION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/buildid.h \
    $(wildcard include/config/VMCORE_INFO) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kmod.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/umh.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/elf.h \
    $(wildcard include/config/ARCH_HAVE_EXTRA_ELF_NOTES) \
    $(wildcard include/config/ARCH_USE_GNU_PROPERTY) \
    $(wildcard include/config/ARCH_HAVE_ELF_PROT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/elf.h \
    $(wildcard include/config/X86_X32_ABI) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/ia32.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/compat.h \
    $(wildcard include/config/ARCH_HAS_SYSCALL_WRAPPER) \
    $(wildcard include/config/COMPAT_OLD_SIGACTION) \
    $(wildcard include/config/ODD_RT_SIGACTION) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sem.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/sem.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ipc.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/ipc.h \
  arch/x86/include/generated/uapi/asm/ipcbuf.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/ipcbuf.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/sembuf.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/socket.h \
  arch/x86/include/generated/uapi/asm/socket.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/socket.h \
  arch/x86/include/generated/uapi/asm/sockios.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/sockios.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/sockios.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/uio.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/uio.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/socket.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/if.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/libc-compat.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/hdlc/ioctl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/fs.h \
    $(wildcard include/config/FANOTIFY_ACCESS_PERMISSIONS) \
    $(wildcard include/config/READ_ONLY_THP_FOR_FS) \
    $(wildcard include/config/FS_POSIX_ACL) \
    $(wildcard include/config/CGROUP_WRITEBACK) \
    $(wildcard include/config/IMA) \
    $(wildcard include/config/FILE_LOCKING) \
    $(wildcard include/config/FSNOTIFY) \
    $(wildcard include/config/FS_DAX) \
    $(wildcard include/config/BLOCK) \
    $(wildcard include/config/UNICODE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/fs/super.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/fs/super_types.h \
    $(wildcard include/config/QUOTA) \
    $(wildcard include/config/FS_ENCRYPTION) \
    $(wildcard include/config/FS_VERITY) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/fs_dirent.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/errseq.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/list_lru.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/shrinker.h \
    $(wildcard include/config/SHRINKER_DEBUG) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/list_bl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/bit_spinlock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/uuid.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/percpu-rwsem.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcuwait.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rcu_sync.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/quota.h \
    $(wildcard include/config/QUOTA_NETLINK_INTERFACE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/dqblk_xfs.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/dqblk_v1.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/dqblk_v2.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/dqblk_qtree.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/projid.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/quota.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/unicode.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/dcache.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rculist_bl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/lockref.h \
    $(wildcard include/config/ARCH_USE_CMPXCHG_LOCKREF) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/stringhash.h \
    $(wildcard include/config/DCACHE_WORD_ACCESS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/hash.h \
    $(wildcard include/config/HAVE_ARCH_HASH) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/vfsdebug.h \
    $(wildcard include/config/DEBUG_VFS) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/wait_bit.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kdev_t.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/kdev_t.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/path.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/semaphore.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/fcntl.h \
    $(wildcard include/config/ARCH_32BIT_OFF_T) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/fcntl.h \
  arch/x86/include/generated/uapi/asm/fcntl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/asm-generic/fcntl.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/openat2.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/migrate_mode.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/delayed_call.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/ioprio.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/rt.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/iocontext.h \
    $(wildcard include/config/BLK_ICQ) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/ioprio.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mount.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/mnt_idmapping.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/slab.h \
    $(wildcard include/config/FAILSLAB) \
    $(wildcard include/config/KFENCE) \
    $(wildcard include/config/SLUB_TINY) \
    $(wildcard include/config/SLUB_DEBUG) \
    $(wildcard include/config/SLAB_BUCKETS) \
    $(wildcard include/config/KVFREE_RCU_BATCHED) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/percpu-refcount.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kasan.h \
    $(wildcard include/config/KASAN_STACK) \
    $(wildcard include/config/KASAN_VMALLOC) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kasan-enabled.h \
    $(wildcard include/config/ARCH_DEFER_KASAN) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/kasan-tags.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rw_hint.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/file_ref.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/fs.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/aio_abi.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/unistd.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/unistd.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/uapi/asm/unistd.h \
  arch/x86/include/generated/uapi/asm/unistd_64.h \
  arch/x86/include/generated/asm/unistd_64_x32.h \
  arch/x86/include/generated/asm/unistd_32_ia32.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/compat.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/sched/task_stack.h \
    $(wildcard include/config/DEBUG_STACK_USAGE) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/magic.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/user32.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/compat.h \
    $(wildcard include/config/COMPAT_FOR_U64_ALIGNMENT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/syscall_wrapper.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/user.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/user_64.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/fsgsbase.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/vdso.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/elf.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/uapi/linux/elf-em.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/moduleparam.h \
    $(wildcard include/config/ALPHA) \
    $(wildcard include/config/PPC64) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/rbtree_latch.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/error-injection.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/error-injection.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/module.h \
    $(wildcard include/config/UNWINDER_ORC) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/asm-generic/module.h \
    $(wildcard include/config/HAVE_MOD_ARCH_SPECIFIC) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/device.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/pm_wakeup.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cpuhotplug.h \
    $(wildcard include/config/HOTPLUG_CORE_SYNC_DEAD) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cpuhplock.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/static_call.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/text-patching.h \
    $(wildcard include/config/UML_X86) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/include/linux/cfi.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/arch/x86/include/asm/cfi.h \
    $(wildcard include/config/FINEIBT_BHI) \
    $(wildcard include/config/FUNCTION_PADDING_CFI) \
    $(wildcard include/config/FINEIBT) \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/state.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/../include/kd_regs.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/rw.h \
  /mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/source/kernel/kdlock/kernel/rw_native.h \

kernel/kdlock/kernel/mutex.o: $(deps_kernel/kdlock/kernel/mutex.o)

$(deps_kernel/kdlock/kernel/mutex.o):
