from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/tmp/kdlock-kernel9-resume-20261111-01');out=root/'private-full';out.mkdir()
remote="""from pathlib import Path
import os,sys,tarfile
root=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/private-rwsem-regression-02')
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='ff9d44b5-bcfc-4ec0-ad0c-2e8798bc8f0c'
paths=[]
for sub in ('runtime','runtime-receipts','build-receipts'):
 for p in (root/sub).rglob('*'):
  assert not p.is_symlink()
  if p.is_file():paths.append(p)
assert sum(p.stat().st_size for p in paths)<128*1024**2
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as t:
 for p in sorted(paths):t.add(p,arcname=str(p.relative_to(root)),recursive=False)
"""
(out/'collector.py').write_text(remote)
argv=['ssh','-T','-p','2222','-o','BatchMode=yes','-o','ConnectTimeout=10','root@10.176.26.71','python3','-B','-']
with (out/'runtime.tar.gz').open('xb') as f,(out/'stderr.log').open('xb') as e:
 p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=f,stderr=e,start_new_session=True)
 p.stdin.write(remote.encode());p.stdin.close()
 try:code=p.wait(timeout=90)
 except subprocess.TimeoutExpired:code=None
assert code==0,(code,p.pid)
manifest={}
with tarfile.open(out/'runtime.tar.gz') as t:
 for m in t:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  raw=t.extractfile(m).read();manifest[m.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'bytes':sum(x['bytes'] for x in manifest.values()),'archive_sha256':hashlib.sha256((out/'runtime.tar.gz').read_bytes()).hexdigest()}))
