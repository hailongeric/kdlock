"""Finish only post-install identity and idle checks; preserve the failure."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import os
import runpy
import time

BASE = Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01')
INPUT = BASE / 'install-input-kdrebuild9-cohort-01'
RECEIPTS = BASE / 'receipts/install-kdrebuild9-cohort-01'
OUTPUT = RECEIPTS / 'install'
STAGE = BASE / 'install-stage-kdrebuild9-cohort-01'
RELEASE = '7.0.0-38-kdrebuild9'
CONFIG_SHA = 'ffb28a7a97372053948f95d76026e6ecf0198bcbcadff1eec83954f9f5f44aa3'
INSTALL_SHA = 'c890fc659cae7fa3c9df0277d96cac76523a49351e90dba9bfdb83e7370bbb5f'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def checked(path, expected):
    path = Path(path)
    assert path.resolve(strict=True) == path and path.is_file()
    assert sha(path) == expected, str(path)
    return json.loads(path.read_text())

def save(name, value):
    with (OUTPUT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    fd = os.open(OUTPUT, os.O_RDONLY | os.O_DIRECTORY)
    os.fsync(fd); os.close(fd)

def main():
    import sys
    assert len(sys.argv) == 3 and os.geteuid() == 0
    recovery_path, recovery_sha = sys.argv[1:]
    config = checked(INPUT / 'config.json', CONFIG_SHA)
    assert sha(INPUT / 'install.py') == INSTALL_SHA
    assert sha(INPUT / 'reference-install8.py') == '409f640efa69425ee8b8849c4f1897b9df83e4c1a7eccbea2b596ab7bb99a99b'
    assert sha(INPUT / 'reference-checks8.py') == '1726d01a4794f82ca8cb1a92218a70dd59272fa2e5e8bdd27a266bd31d92a472'
    failure = checked(OUTPUT / 'failure.json', 'c4bababff7ef1525ea5212215915b60661da4508014b284bc510c821c176aa77')
    assert failure['phase'] == 'install' and failure['status'] == 'FAILED_OR_INCOMPLETE_RETAINED'
    assert failure['error'].startswith("RuntimeError('strict idle refused:")
    assert not (OUTPUT / 'install-complete.json').exists()
    verified = checked(RECEIPTS / 'verify/verified-stage.json', 'bff8035d9db84adaf209f5c03946c2f26731dcdd998d7e8fa2253f5267d6e22c')
    commands = sorted(OUTPUT.glob('*-result.json'))
    assert len(commands) == 12
    for path in commands:
        row = json.loads(path.read_text())
        assert row['returncode'] == 0 and row['timed_out'] is False
        assert Path(row['log']).parent == OUTPUT and sha(row['log']) == row['log_sha256']
    assert sha(config['build_driver']) == config['build_driver_sha256']
    native = runpy.run_path(config['build_driver'])
    plan = checked(config['plan_json'], config['plan_sha256'])
    built = checked(config['build_receipt'], config['build_receipt_sha256'])
    final = checked(config['final_identity'], config['final_identity_sha256'])
    native['environment']()
    recovery = native['recovery_check'](SimpleNamespace(recovery_json=recovery_path, recovery_sha256=recovery_sha), plan)
    lib = runpy.run_path(str(INPUT / 'reference-install8.py'))
    checks = runpy.run_path(str(INPUT / 'reference-checks8.py'))
    checks['protected'].__globals__.update(RELEASE=RELEASE, PREVIOUS=())
    assert checks['protected']() == json.loads((RECEIPTS / 'stage/protected-before.json').read_text())
    assert native['candidate_pins'](plan, BASE / 'source') == built['source_after']
    assert native['protected'](plan) == built['protected_after']
    installed = checked(OUTPUT / 'installed.json', '2da3996efcc602502eb4cff73dfbac6cca55c9648c9fd8c314ceead73641c600')
    for row in installed['files']:
        assert Path(row['path']).stat().st_size == row['size'] and sha(row['path']) == row['sha256']
    assert lib['tree_table'](Path('/lib/modules') / RELEASE) == installed['namespace'] == verified['namespace']
    prefix = (RECEIPTS / 'stage/custom.cfg-before').read_bytes()
    suffix = (INPUT / 'candidate-entry.cfg').read_bytes()
    assert (Path('/boot/grub/custom.cfg')).read_bytes() == prefix + suffix
    expected_boot = dict(built['boot_after'])
    for row in installed['files']:
        expected_boot[row['path']] = {'bytes': row['size'], 'sha256': row['sha256']}
    expected_boot['/boot/grub/custom.cfg'] = {'bytes': len(prefix + suffix), 'sha256': hashlib.sha256(prefix + suffix).hexdigest()}
    expected_boot['/lib/modules namespaces'] = sorted([*built['boot_after']['/lib/modules namespaces'], RELEASE])
    assert native['boot_files']() == expected_boot
    native['pins'](BASE / 'build', {name: row['sha256'] for name, row in final['files'].items()})
    assert lib['tree_table'](STAGE / 'limited/lib/modules' / RELEASE) == verified['namespace']
    assert sha(STAGE / ('initrd.img-' + RELEASE)) == verified['initrd']['sha256']
    assert native['available']('/') > verified['budget']['needed']
    assert native['available'](BASE) >= 4 * 1024**3
    samples, clear = [], None
    end = time.monotonic() + 30
    while True:
        sample = native['idle_sample'](plan['normal_identity'], native['NORMAL_MODULE_NAMES'])
        samples.append(sample)
        if sample['busy'] or sample['dthreads']:
            clear = None
        elif clear is None:
            clear = time.monotonic()
        elif time.monotonic() - clear >= 10:
            break
        if time.monotonic() >= end:
            save('install-resume-failed.json', {'status': 'IDLE_NOT_ESTABLISHED', 'samples': samples})
            raise RuntimeError('strict idle did not remain clear for ten seconds')
        time.sleep(1)
    resumed = {'status': 'FINAL_INSTALL_CHECKS_COMPLETE', 'helper_sha256': sha(__file__),
               'original_helper_sha256': INSTALL_SHA, 'original_observer_returncode': 1,
               'original_failure_sha256': sha(OUTPUT / 'failure.json'),
               'verified_stage_sha256': sha(RECEIPTS / 'verify/verified-stage.json'),
               'original_command_count': 12, 'all_original_commands_returned_zero': True,
               'source_build_boot_module_namespace_rechecked': True,
               'strict_idle_samples': samples, 'recovery': recovery,
               'no_install_repeated_and_no_arm_or_module_load': True}
    save('install-resume.json', resumed)
    complete = {'status': 'COMPLETE', 'phase': 'install', 'config_sha256': CONFIG_SHA,
                'helper_sha256': INSTALL_SHA, 'completion_helper_sha256': sha(__file__),
                'completion_resume_sha256': sha(OUTPUT / 'install-resume.json'),
                'original_observer_returncode': 1, 'original_failure_preserved': True,
                'prior_sha256': sha(RECEIPTS / 'verify/verify-complete.json'),
                'entry': 'kdlock-kdrebuild9-cohort-01', 'reboot_performed': False,
                'module_load_performed': False}
    save('install-complete.json', complete)
    print(json.dumps(complete, sort_keys=True))

if __name__ == '__main__':
    main()
