"""Source-host controller for one explicitly selected guest install phase."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import subprocess
import time

ROOT = Path('/tmp/kdlock-kernel9-resume-20261111-01')
PREP = ROOT / 'install-preparation'
REMOTE = '/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/install-input-kdrebuild9-cohort-01'
SSH = ['ssh', '-T', '-p', '2222', '-o', 'BatchMode=yes', '-o',
       'ConnectTimeout=10', 'root@10.176.26.71', 'python3', '-B', '-']

def digest(data):
    return hashlib.sha256(data).hexdigest()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=('stage', 'verify', 'install', 'arm'))
args = parser.parse_args()
output = ROOT / ('phase-' + args.phase)
output.mkdir(mode=0o700)
host_source = (ROOT / 'host/read.py').read_bytes()
host_argv = json.loads((ROOT / 'host/command.json').read_text())['argv']
host = subprocess.run(host_argv, input=host_source, capture_output=True, timeout=50)
(output / 'recovery.json').write_bytes(host.stdout)
(output / 'recovery.stderr').write_bytes(host.stderr)
assert host.returncode == 0, 'read-only recovery check failed'
files = {}
for name in ('install.py', 'reference-install8.py', 'reference-checks8.py',
             'candidate-entry.cfg', 'config.json'):
    data = (PREP / name).read_bytes()
    files[name] = {'sha256': digest(data), 'data': base64.b64encode(data).decode()}
recovery = {'sha256': digest(host.stdout), 'data': base64.b64encode(host.stdout).decode()}
previous = {'verify': 'stage', 'install': 'verify', 'arm': 'install'}.get(args.phase)
prior = None
if previous:
    prior_path = ROOT / ('phase-' + previous) / 'collected' / (previous + '-complete.json')
    prior = digest(prior_path.read_bytes())
payload = {'phase': args.phase, 'remote': REMOTE, 'files': files,
           'recovery': recovery, 'prior_sha256': prior}
encoded = base64.b64encode(json.dumps(payload, sort_keys=True).encode()).decode()
remote_source = '''from pathlib import Path
import ast,base64,hashlib,json,os,runpy,subprocess,time
payload=json.loads(base64.b64decode(PAYLOAD))
root=Path(payload['remote']);phase=payload['phase']
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
driver=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-input-6e486ece-01/build.py')
assert sha(driver)=='0535aa78d56e019b11de988e217416110176645fb9f25fce4dca9427881e0d57'
native=runpy.run_path(str(driver))
expected={'boot':'f1442f01-e060-46fa-a480-da508d7ce8a9','release':'7.0.0-38-kdlock1','taint':'0'}
native['idle'](expected)
assert root.parent.resolve(strict=True)==root.parent
if phase=='stage':
 root.mkdir(mode=0o700)
 for name,row in payload['files'].items():
  assert '/' not in name
  raw=base64.b64decode(row['data']);assert hashlib.sha256(raw).hexdigest()==row['sha256']
  if name.endswith('.py'):ast.parse(raw,filename=name)
  with (root/name).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  (root/name).chmod(0o444)
else:
 assert root.resolve(strict=True)==root
for name,row in payload['files'].items():assert sha(root/name)==row['sha256']
rec=root/('recovery-'+phase+'.json');raw=base64.b64decode(payload['recovery']['data'])
assert hashlib.sha256(raw).hexdigest()==payload['recovery']['sha256']
with rec.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
rec.chmod(0o444)
fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
argv=['/usr/bin/python3','-B',str(root/'install.py'),phase,'--config-json',str(root/'config.json'),
 '--config-sha256',payload['files']['config.json']['sha256'],'--recovery-json',str(rec),
 '--recovery-sha256',payload['recovery']['sha256']]
if payload['prior_sha256']:argv+=['--prior-sha256',payload['prior_sha256']]
record={'phase':phase,'argv':argv,'started_unix':time.time(),'input_pins':{k:v['sha256'] for k,v in payload['files'].items()}}
with (root/('observer-'+phase+'.stdout')).open('xb') as out,(root/('observer-'+phase+'.stderr')).open('xb') as err:
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 record['pid']=child.pid
 try:record['returncode']=child.wait(timeout=900)
 except subprocess.TimeoutExpired:record.update(returncode=None,status='INCOMPLETE_CHILD_RETAINED')
 record['elapsed_seconds']=time.time()-record['started_unix']
with (root/('observer-'+phase+'.json')).open('x') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\\n');f.flush();os.fsync(f.fileno())
records=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/receipts/install-kdrebuild9-cohort-01')/phase
copied={};size=0
if record['returncode'] is not None and records.is_dir():
 for path in sorted(records.iterdir()):
  assert path.is_file() and not path.is_symlink()
  data=path.read_bytes();size+=len(data);assert size<32*1024*1024
  copied[path.name]={'sha256':hashlib.sha256(data).hexdigest(),'data':base64.b64encode(data).decode()}
for name in ('observer-'+phase+'.stdout','observer-'+phase+'.stderr','observer-'+phase+'.json'):
 data=(root/name).read_bytes();size+=len(data);assert size<32*1024*1024
 copied[name]={'sha256':hashlib.sha256(data).hexdigest(),'data':base64.b64encode(data).decode()}
print(json.dumps({'observer':record,'files':copied},sort_keys=True))
'''.replace('PAYLOAD', repr(encoded))
raw = remote_source.encode()
(output / 'dispatch.py').write_bytes(raw)
(output / 'command.json').write_text(json.dumps({'argv': SSH, 'stdin_sha256': digest(raw)}, indent=2) + '\n')
with (output / 'reply.json').open('xb') as out, (output / 'stderr.log').open('xb') as err:
    child = subprocess.Popen(SSH, stdin=subprocess.PIPE, stdout=out, stderr=err, start_new_session=True)
    child.stdin.write(raw)
    child.stdin.close()
    try:
        code = child.wait(timeout=960)
    except subprocess.TimeoutExpired:
        code = None
    record = {'returncode': code, 'pid': child.pid, 'child_retained_on_timeout': code is None}
    (output / 'controller.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
if code != 0:
    print((output / 'stderr.log').read_text(), flush=True)
    raise SystemExit('Guest phase result unavailable; retain state without retry.')
reply = json.loads((output / 'reply.json').read_text())
collected = output / 'collected'
collected.mkdir()
for name, row in reply['files'].items():
    assert '/' not in name
    data = base64.b64decode(row['data'])
    assert digest(data) == row['sha256']
    (collected / name).write_bytes(data)
print(json.dumps(reply['observer']), flush=True)
print((collected / ('observer-' + args.phase + '.stderr')).read_text(), flush=True)
if reply['observer']['returncode'] != 0:
    raise SystemExit('Guest phase failed or remains incomplete; retained.')
