from pathlib import Path
import os,sys,tarfile
root=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01/private-rwsem-regression-02')
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='ff9d44b5-bcfc-4ec0-ad0c-2e8798bc8f0c'
paths=[]
for sub in ('runtime','runtime-receipts','build-receipts'):
 for p in (root/sub).rglob('*'):
  assert not p.is_symlink()
  if p.is_file():paths.append(p)
assert sum(p.stat().st_size for p in paths)<128*1024**2
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as t:
 for p in sorted(paths):t.add(p,arcname=str(p.relative_to(root)),recursive=False)
