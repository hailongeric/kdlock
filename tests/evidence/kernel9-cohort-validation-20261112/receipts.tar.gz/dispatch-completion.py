"""Run one read-only completion check after a retained transient idle failure."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess
import sys

phase = sys.argv[1]
assert phase == 'install'
root = Path('/tmp/kdlock-kernel9-resume-20261111-01')
out = root / (phase + '-resume')
out.mkdir(mode=0o700)
sha = lambda data: hashlib.sha256(data).hexdigest()
host_argv = json.loads((root / 'host/command.json').read_text())['argv']
host = subprocess.run(host_argv, input=(root / 'host/read.py').read_bytes(), capture_output=True, timeout=50)
(out / 'recovery.json').write_bytes(host.stdout)
(out / 'recovery.stderr').write_bytes(host.stderr)
assert host.returncode == 0
files = {name: {'sha256': sha(data), 'data': base64.b64encode(data).decode()}
         for name, data in [('finish-install.py', (root / 'finish-install.py').read_bytes()),
                            ('recovery.json', host.stdout)]}
payload = base64.b64encode(json.dumps(files).encode()).decode()
source = '''from pathlib import Path
import ast,base64,hashlib,json,os,runpy,subprocess
files=json.loads(base64.b64decode(PAYLOAD))
base=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01')
driver=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-input-6e486ece-01/build.py')
assert hashlib.sha256(driver.read_bytes()).hexdigest()=='0535aa78d56e019b11de988e217416110176645fb9f25fce4dca9427881e0d57'
n=runpy.run_path(str(driver));n['idle']({'boot':'f1442f01-e060-46fa-a480-da508d7ce8a9','release':'7.0.0-38-kdlock1','taint':'0'})
root=base/'install-completion-input-01';root.mkdir(mode=0o700)
for name,row in files.items():
 data=base64.b64decode(row['data']);assert hashlib.sha256(data).hexdigest()==row['sha256']
 if name.endswith('.py'):ast.parse(data,filename=name)
 with (root/name).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 (root/name).chmod(0o444)
argv=['/usr/bin/python3','-B',str(root/'finish-install.py'),str(root/'recovery.json'),files['recovery.json']['sha256']]
with (root/'stdout.log').open('xb') as stdout,(root/'stderr.log').open('xb') as stderr:
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=child.wait(timeout=180)
 except subprocess.TimeoutExpired:code=None
value={'argv':argv,'returncode':code,'pid':child.pid,'files':{}}
if code is not None:
 for path in [root/'stdout.log',root/'stderr.log',*(base/'receipts/install-kdrebuild9-cohort-01/install').glob('install-*.json')]:
  data=path.read_bytes();value['files'][path.name]={'sha256':hashlib.sha256(data).hexdigest(),'data':base64.b64encode(data).decode()}
print(json.dumps(value,sort_keys=True))
'''.replace('PAYLOAD', repr(payload))
(out / 'dispatch.py').write_text(source)
argv = ['ssh', '-T', '-p', '2222', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
        'root@10.176.26.71', 'python3', '-B', '-']
(out / 'command.json').write_text(json.dumps({'argv': argv, 'stdin_sha256': sha(source.encode())}, indent=2) + '\n')
with (out / 'reply.json').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, start_new_session=True)
    child.stdin.write(source.encode()); child.stdin.close()
    try:
        code = child.wait(timeout=210)
    except subprocess.TimeoutExpired:
        code = None
print(json.dumps({'ssh_returncode': code, 'ssh_pid': child.pid}), flush=True)
if code != 0:
    print((out / 'stderr.log').read_text())
    raise SystemExit('Completion unavailable; preserve state.')
value = json.loads((out / 'reply.json').read_text())
collected = out / 'collected'; collected.mkdir()
for name, row in value['files'].items():
    assert '/' not in name
    data = base64.b64decode(row['data']); assert sha(data) == row['sha256']
    with (collected / name).open('xb') as stream:
        stream.write(data)
    if name in ('install-resume.json', 'install-complete.json'):
        with (root / 'phase-install/collected' / name).open('xb') as stream:
            stream.write(data)
print(json.dumps({key: value[key] for key in ('returncode', 'pid', 'argv')}), flush=True)
print((collected / 'stderr.log').read_text(), flush=True)
assert value['returncode'] == 0
