"""Build and sign only the frozen, existing private rwsem fixture in kernel9."""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import time
import kernel9_common as c

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--metadata-sha256', required=True)
parser.add_argument('--recovery-sha256', required=True)
args = parser.parse_args()
control = c.ROOT / 'control'
out = c.ROOT / 'build-receipts'
metadata = c.checked(c.ROOT / 'stage-metadata.json', args.metadata_sha256)
config = json.loads((control / 'config.json').read_text())
c.need(c.sha(control/'config.json') == metadata['config_sha256'] and
       c.sha(__file__) == metadata['helper_sha256']['build-private.py'] and
       c.sha(control/'kernel9_common.py') == metadata['helper_sha256']['kernel9_common.py'],
       'frozen helper/config differs')
before = c.idle(0)
native, plan, built, final, proof = c.kernel_inputs(config)
recovery = c.recovery(native, plan, control/'recovery-build.json', args.recovery_sha256)
c.source_inputs()
boot_before = native['boot_files']()
c.need(boot_before == metadata['boot_files'], 'installed boot files changed after staging')
for name, row in metadata['tools'].items():
    c.need(c.sha(Path(row['path']).resolve(strict=True)) == row['sha256'], 'build tool differs: '+name)
out.mkdir(mode=0o700)
result = {'status': 'BUILD_STARTED', 'core_git_head': c.CORE, 'source_git_head': c.CORE,
          'metadata_sha256': args.metadata_sha256, 'config_sha256': metadata['config_sha256'],
          'identity_before': before, 'recovery': recovery, 'commands': [],
          'only_module': 'kd_rwsem_runtime_fixture.ko', 'module_load_performed': False}
c.save(out/'started.json', result)

def command(label, argv, seconds):
    row = {'label': label, 'argv': list(map(str, argv)), 'started_unix': time.time()}
    result['commands'].append(row)
    path = out/(label+'.log')
    env = dict(os.environ, PATH='/usr/sbin:/usr/bin:/sbin:/bin', LANG='C', LC_ALL='C',
               PYTHONDONTWRITEBYTECODE='1')
    with path.open('xb') as stream:
        child = subprocess.Popen(row['argv'], stdin=subprocess.DEVNULL, stdout=stream,
            stderr=subprocess.STDOUT, env=env, start_new_session=True)
        row['pid'] = child.pid
        c.save(out/(label+'-started.json'), row)
        end = time.monotonic()+seconds
        while child.poll() is None:
            if (time.monotonic() >= end or path.stat().st_size > 512*1024**2 or
                    c.available('/') < 1024**3 or c.available(c.BASE) < 4*1024**3):
                row.update(returncode=None, status='INCOMPLETE_CHILD_RETAINED')
                c.save(out/(label+'-result.json'), row)
                raise RuntimeError('observer ended; original child retained: '+label)
            time.sleep(0.25)
        row.update(returncode=child.returncode, elapsed_seconds=time.time()-row['started_unix'])
        stream.flush(); os.fsync(stream.fileno())
    row['log_sha256'] = c.sha(path)
    c.save(out/(label+'-result.json'), row)
    c.need(child.returncode == 0, 'command failed: '+label)
    return path.read_text()

try:
    output = c.ROOT/'module-build'
    output.mkdir(mode=0o700)
    command('rwsem-module', [metadata['tools']['make']['path'], '-C', c.BASE/'source',
        'O='+str(c.BUILD), 'M='+str(c.ROOT/'input/tests/kernel/rwsem/payload'),
        'MO='+str(output), 'KERNELRELEASE='+c.RELEASE, '-j8', 'V=1', 'modules'], 180)
    modules = list(output.rglob('*.ko'))
    unsigned = output/'kd_rwsem_runtime_fixture.ko'
    c.need(modules == [unsigned] and unsigned.is_file(), 'exact single module output differs')
    result['unsigned'] = {'path': str(unsigned), 'bytes': unsigned.stat().st_size,
                          'sha256': c.sha(unsigned)}
    signed_dir = c.ROOT/'signed'; signed_dir.mkdir(mode=0o700)
    signed = signed_dir/unsigned.name
    with unsigned.open('rb') as source, signed.open('xb') as destination:
        shutil.copyfileobj(source, destination); destination.flush(); os.fsync(destination.fileno())
    c.need(c.sha(signed) == result['unsigned']['sha256'], 'unsigned copy differs')
    command('rwsem-sign', [metadata['tools']['sign-file']['path'], 'sha512',
        c.BUILD/'certs/signing_key.pem', c.BUILD/'certs/signing_key.x509', signed], 60)
    fields = {}
    for name in ('vermagic', 'signer', 'sig_key', 'sig_hashalgo', 'depends'):
        fields[name] = command('module-'+name,
            [metadata['tools']['modinfo']['path'], '-F', name, signed], 60).strip()
    c.need(fields['vermagic'].split()[0] == c.RELEASE and fields['signer'] and
           fields['sig_key'] and fields['sig_hashalgo'] == 'sha512' and not fields['depends'],
           'signed module metadata differs')
    c.need(c.sha(unsigned) == result['unsigned']['sha256'], 'unsigned original changed')
    c.source_inputs(); c.kernel_inputs(config)
    c.need(native['boot_files']() == boot_before, 'build changed installed boot files')
    for name, row in metadata['tools'].items():
        c.need(c.sha(Path(row['path']).resolve(strict=True)) == row['sha256'], 'build tool changed: '+name)
    result.update(status='PRIVATE_RWSEM_MODULE_BUILT_SIGNED', identity_after=c.idle(0),
        signed={'path': str(signed), 'bytes': signed.stat().st_size, 'sha256': c.sha(signed), **fields},
        source_preserved=True, kernel16_and_core78_preserved=True, boot_files_preserved=True)
    c.save(out/'result.json', result)
    print(json.dumps({'status': result['status'], 'signed': result['signed']}), flush=True)
except BaseException as error:
    result.update(status='FAILED_OR_INCOMPLETE_RETAINED', error=repr(error))
    c.save(out/'result.json', result)
    raise
