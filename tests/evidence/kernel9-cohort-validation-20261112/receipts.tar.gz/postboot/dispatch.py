from pathlib import Path
import base64,hashlib,json,os,subprocess
base=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01');helper=base/'postboot-input-kdrebuild9-cohort-01/postboot.py';out=base/'receipts/postboot-kdrebuild9-cohort-01'
assert os.uname().release=='7.0.0-38-kdrebuild9'
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='ff9d44b5-bcfc-4ec0-ad0c-2e8798bc8f0c'
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='231a4cea89cd94ac902f2b12aebf7f3ecca0aa2c5b22dbfefe44ae9dbbe3e6af'
argv=['/usr/bin/python3','-B',str(helper),'--output',str(out),'--timeout','45','--max-command-bytes',str(64*1024*1024),'--max-notes-bytes',str(1024*1024)]
with (helper.parent/'postboot.stdout').open('xb') as stdout,(helper.parent/'postboot.stderr').open('xb') as stderr:
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=child.wait(timeout=300)
 except subprocess.TimeoutExpired:code=None
value={'returncode':code,'pid':child.pid,'argv':argv,'files':{}};total=0
if code is not None:
 paths=[helper.parent/'postboot.stdout',helper.parent/'postboot.stderr',helper.parent/'reboot-before.json']
 if out.is_dir():paths+=list(out.iterdir())
 for path in paths:
  assert path.is_file() and not path.is_symlink()
  data=path.read_bytes();total+=len(data);assert total<96*1024*1024
  value['files'][path.name]={'sha256':hashlib.sha256(data).hexdigest(),'data':base64.b64encode(data).decode()}
print(json.dumps(value,sort_keys=True))
