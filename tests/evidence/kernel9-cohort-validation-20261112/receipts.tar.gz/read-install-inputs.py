from pathlib import Path
import datetime
import hashlib
import json
import os
import runpy
import shutil
import subprocess

BASE = Path('/mnt/kdlock-builds2/kdlock-main-kernel9-6e486ece-01')
INPUT = Path('/mnt/kdlock-builds2/kdlock-main-kernel9-input-6e486ece-01')

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def command(argv):
    result = subprocess.run(argv, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, (argv, result.returncode, result.stderr)
    return result.stdout

assert sha(INPUT / 'build.py') == '0535aa78d56e019b11de988e217416110176645fb9f25fce4dca9427881e0d57'
assert sha(INPUT / 'plan.json') == '0df23f4f69069b9b8dfcff3c58b69df9b4b6904f7e2abff3073ee9dd71215408'
native = runpy.run_path(str(INPUT / 'build.py'))
plan = json.loads((INPUT / 'plan.json').read_text())
result_path = BASE / 'receipts/build-01/result.json'
final_path = BASE / 'receipts/build-01/final-identity.json'
built = json.loads(result_path.read_text())
final = json.loads(final_path.read_text())
assert built['status'] == 'KERNEL9_BUILD_AND_LINKED_IDENTITY_COMPLETE'
assert built['final_identity_sha256'] == sha(final_path)
assert final['build_id'] == '8198ffae09db584dce9b71d92b5743a4146ba80a'
initial = native['idle'](plan['normal_identity'])
assert native['candidate_pins'](plan, BASE / 'source') == built['source_after']
assert native['protected'](plan) == built['protected_after']
assert native['boot_files']() == built['boot_after']
native['pins'](BASE / 'build', {n: r['sha256'] for n, r in final['files'].items()})
assert all((BASE / 'build' / n).stat().st_size == r['bytes'] for n, r in final['files'].items())
tools = {}
for name in ('make', 'modinfo', 'readelf', 'modprobe', 'depmod', 'unshare', 'sh', 'env',
             'mkinitramfs', 'lsinitramfs', 'grub-script-check', 'grub-editenv', 'grub-reboot', 'sync'):
    path = Path(shutil.which(name)).resolve(strict=True)
    tools[name] = {'path': str(path), 'sha256': sha(path)}
menus = {}
for name in ('grub.cfg', 'custom.cfg'):
    path = Path('/boot/grub') / name
    assert path.is_file() and not path.is_symlink()
    menus[name] = {'sha256': sha(path), 'bytes': path.stat().st_size,
                   'text': path.read_text()}
names = [Path('/lib/modules/7.0.0-38-kdrebuild9')]
names += [Path('/boot') / (p + '7.0.0-38-kdrebuild9') for p in ('vmlinuz-', 'System.map-', 'config-', 'initrd.img-')]
assert not any(os.path.lexists(p) for p in names)
value = {'status': 'KERNEL9_INSTALL_INPUTS_VERIFIED',
         'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'initial': initial, 'final_idle': native['idle'](plan['normal_identity']),
         'build_receipt': str(result_path), 'build_receipt_sha256': sha(result_path),
         'final_identity': str(final_path), 'final_identity_sha256': sha(final_path),
         'plan_json': str(INPUT / 'plan.json'), 'plan_sha256': sha(INPUT / 'plan.json'),
         'build_driver': str(INPUT / 'build.py'), 'build_driver_sha256': sha(INPUT / 'build.py'),
         'tools': tools, 'menus': menus,
         'grub_environment': command(['grub-editenv', '/boot/grub/grubenv', 'list']),
         'root_source': command(['findmnt', '-no', 'SOURCE,UUID,FSTYPE', '/']),
         'root_free_bytes': native['available']('/'),
         'output_free_bytes': native['available'](BASE),
         'config_bytes_preserved': True, 'linked16_preserved': True,
         'core78_integration8_native_mm11_preserved': True,
         'kernel8_and_normal_preserved': True}
print(json.dumps(value, sort_keys=True))
