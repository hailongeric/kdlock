"""Run only the unchanged four-worker rwsem regression on exact kernel9 inputs."""
from pathlib import Path
import argparse
import json
import os
import subprocess
import time
import kernel9_common as c

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--arguments-sha256', required=True)
parser.add_argument('--recovery-sha256', required=True)
args = parser.parse_args()
control = c.ROOT/'control'
config = c.checked(control/'runtime-arguments.json', args.arguments_sha256)
c.need(c.sha(__file__) == config['supervisor_sha256'] and
       c.sha(control/'kernel9_common.py') == config['common_sha256'], 'exact supervisor/common input differs')
before = c.idle(0)
native, plan, built, final, proof = c.kernel_inputs(config)
recovery = c.recovery(native, plan, control/'recovery-runtime.json', args.recovery_sha256)
source_files = c.source_inputs()
compiled = c.checked(c.ROOT/'build-receipts/result.json', config['module_build_receipt_sha256'])
c.need(compiled['status'] == 'PRIVATE_RWSEM_MODULE_BUILT_SIGNED' and
       compiled['source_git_head'] == compiled['core_git_head'] == c.CORE and
       compiled['identity_after']['boot'] == c.BOOT, 'actual exact module build incomplete')
module = c.ROOT/'signed/kd_rwsem_runtime_fixture.ko'
c.need(c.sha(module) == compiled['signed']['sha256'] == config['compiled_module']['sha256'] and
       module.stat().st_size == config['compiled_module']['bytes'] == compiled['signed']['bytes'],
       'actual signed fixture differs')
argv = config['argv']
python = Path('/mnt/kdlock-builds/venvs/kdlock-translation-7.0-20261027/bin/python3')
c.need(argv[:3] == [str(python), '-B', str(c.ROOT/'input/tests/kernel/rwsem/run_rwsem_runtime_fixture.py')] and
       python.resolve(strict=True) == Path('/usr/bin/python3.14') and
       c.sha(python.resolve()) == '52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41',
       'exact fixture runner/interpreter differs')
for alias in ('/usr/sbin/insmod', '/usr/sbin/rmmod'):
    c.need(c.sha(Path(alias).resolve()) == '6edf62330978627d75d8de7e903f243b6ba765f8b54baa914ec83e21cd85bdc7',
           'module tool changed: '+alias)
fixed = {'--repo': str(c.ROOT/'input'), '--module': str(module),
         '--output': str(c.ROOT/'runtime'), '--expected-release': c.RELEASE,
         '--kernel-elf': str(c.BUILD/'vmlinux'), '--kernel-config': str(c.BUILD/'.config'),
         '--gs-proof-json': str(c.BASE/'receipts/postboot-kdrebuild9-cohort-01/gs-proof.json'),
         '--gs-offset': proof['current_task_gs_offset'], '--dependency-page-limit': '16',
         '--total-source-byte-limit': '131072', '--wire-log-byte-limit': '268435456',
         '--event-capacity': '65536', '--workers': '4', '--iterations': '8', '--deadline': '600.0',
         '--builtin-source-start': hex(final['return_symbols']['its_return_thunk']['address']),
         '--builtin-source-size': str(final['return_symbols']['its_return_thunk']['bytes']),
         '--holder-timeout-ms': '20000', '--runtime-block-visits': '16000000',
         '--reader-learning-passes': '16', '--coordination-spins': '1000000'}
for name, expected in fixed.items():
    c.need(argv.count(name) == 1 and argv[argv.index(name)+1] == expected, 'selected argument differs: '+name)
for name in ('--immutable-text-contract', '--auxiliary-stack-contract'):
    c.need(argv.count(name) == 1, 'declared source/context premise missing: '+name)
c.need(len(argv) == 3 + 2*len(fixed) + 2 and config['observer_seconds'] == 660,
       'unexpected runtime argument or observer extent')
boot_before = native['boot_files']()
out = c.ROOT/'runtime-receipts'
live = c.ROOT/'runtime'
c.need(not out.exists() and not live.exists(), 'fresh runtime output leaves required')
out.mkdir(mode=0o700)
result = {'status': 'STARTED', 'family': 'rwsem', 'source_git_head': c.CORE,
          'kernel_core_git_head': c.CORE, 'arguments_sha256': args.arguments_sha256,
          'identity_before': before, 'recovery': recovery, 'configuration': config,
          'scope': 'Existing protected rwsem 4x8 regression; not deterministic queue-race, MM or performance evidence.'}
c.save(out/'started.json', result)

def dmesg(name):
    path = out/name
    with path.open('xb') as stream:
        child = subprocess.Popen(['/usr/bin/dmesg', '--color=never'], stdout=stream,
            stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
        try:
            code = child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            raise RuntimeError('read-only dmesg observer ended; child retained pid='+str(child.pid))
    c.need(code == 0 and path.stat().st_size <= 32*1024**2, 'dmesg read failed/exceeded bound')
    return path.read_text()

try:
    log_before = dmesg('dmesg-before.log')
    env = dict(os.environ, PATH='/usr/sbin:/usr/bin:/sbin:/bin', **config['environment'])
    row = {'argv': argv, 'started_unix': time.time()}
    result['command'] = row
    log = out/'rwsem.log'
    with log.open('xb') as stream:
        child = subprocess.Popen(argv, cwd=c.ROOT/'input', env=env, stdin=subprocess.DEVNULL,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        row['pid'] = child.pid
        c.save(out/'command-started.json', row)
        end = time.monotonic()+660
        while child.poll() is None:
            if (time.monotonic() >= end or c.available('/') < 1024**3 or
                    c.available(c.BASE) < 4*1024**3 or log.stat().st_size > 32*1024**2):
                row.update(status='INCOMPLETE_CHILD_RETAINED', returncode=None)
                raise RuntimeError('deadline/space/log observer ended; child and controls retained')
            time.sleep(0.25)
        row.update(returncode=child.returncode, elapsed_seconds=time.time()-row['started_unix'])
        stream.flush(); os.fsync(stream.fileno())
    row['log_sha256'] = c.sha(log)
    c.need(child.returncode == 0, 'runner failed; no cleanup inferred')
    value = json.loads((live/'result.json').read_text())
    c.need(value['status'] == 'protected_rwsem_jit_reader_mechanism_pass' and
           value['module_sha256'] == config['compiled_module']['sha256'] and
           value['warm_claim_no_new_facts'] is True and
           value['returned_full_jit_body'] == 'protected_episode_completed' and
           value['full_c_function_jit_return'] == 'outside_protected_episode_scope',
           'protected episode completion/unchanged warm baseline incomplete')
    for name in ('result.json', 'observations-final.bin', 'observations-final.json', 'shutdown-archive.json'):
        c.need((live/name).is_file() and (live/name).stat().st_size > 0, 'final record absent: '+name)
    after = c.idle(4096)
    c.need(after['boot'] == before['boot'] and after['release'] == before['release'] and
           after['modules'] == before['modules'], 'final kernel/module identity differs')
    log_after = dmesg('dmesg-after.log')
    c.need(log_after.startswith(log_before), 'kernel log prefix lost; new-fault check incomplete')
    added = log_after[len(log_before):]
    faults = [line for line in added.splitlines() if any(token in line for token in
        ('BUG:', 'kernel BUG at', 'Oops:', 'general protection fault', 'WARNING: CPU:', 'Kernel panic'))]
    c.need(not faults, 'new kernel fault/warning: '+repr(faults))
    c.need(c.source_inputs() == source_files, 'source members changed')
    c.kernel_inputs(config)
    c.need(c.sha(module) == config['compiled_module']['sha256'] and
           native['boot_files']() == boot_before, 'runtime input or installed boot state changed')
    result.update(status='PRIVATE_RWSEM_COMPLETE', identity_after=after,
        runner_result_sha256=c.sha(live/'result.json'), event_sha256=c.sha(live/'observations-final.bin'),
        event_bytes=(live/'observations-final.bin').stat().st_size,
        archive_sha256=c.sha(live/'shutdown-archive.json'), new_kernel_faults=faults,
        source_kernel_boot_preserved=True, deterministic_race_reproduction=False)
    c.save(out/'result.json', result)
    print(json.dumps({'status': result['status'], 'event_bytes': result['event_bytes'],
                      'runner_result_sha256': result['runner_result_sha256']}), flush=True)
except BaseException as error:
    result.update(status='FAILED_OR_INCOMPLETE_RETAINED', error=repr(error))
    c.save(out/'result.json', result)
    raise
