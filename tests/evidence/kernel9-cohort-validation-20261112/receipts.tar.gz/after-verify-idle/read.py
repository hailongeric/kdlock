from pathlib import Path
import hashlib,json,runpy,time
p=Path('/mnt/kdlock-builds2/kdlock-main-kernel9-input-6e486ece-01/build.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='0535aa78d56e019b11de988e217416110176645fb9f25fce4dca9427881e0d57'
n=runpy.run_path(str(p));expected={'boot':'f1442f01-e060-46fa-a480-da508d7ce8a9','release':'7.0.0-38-kdlock1','taint':'0'}
end=time.monotonic()+30;clear=None;rows=[]
while True:
 s=n['idle_sample'](expected,n['NORMAL_MODULE_NAMES']);rows.append(s)
 if s['busy'] or s['dthreads']:clear=None
 elif clear is None:clear=time.monotonic()
 elif time.monotonic()-clear>=10:
  print(json.dumps({'status':'STRICT_IDLE_TEN_SECONDS','samples':rows},sort_keys=True));break
 if time.monotonic()>=end:
  print(json.dumps({'status':'IDLE_NOT_ESTABLISHED','samples':rows},sort_keys=True));break
 time.sleep(1)
