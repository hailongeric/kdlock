"""Stage the existing rwsem source and read build metadata; no build or load."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess

ROOT = Path('/tmp/kdlock-kernel9-resume-20261111-01')
OUT = ROOT/'private-stage-02'
OUT.mkdir(mode=0o700)
files = {}
for name, path in [(name, ROOT/'private-preparation'/name) for name in
                   ('source.tar', 'source-sha256.json', 'source-state.json', 'config.json')] + [
                   (name, ROOT/name) for name in ('kernel9_common.py', 'build-private.py')]:
    raw = path.read_bytes()
    files[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'data': base64.b64encode(raw).decode()}
encoded = base64.b64encode(json.dumps(files).encode()).decode()
source = '''from pathlib import Path,PurePosixPath
import ast,base64,hashlib,io,json,os,shutil,sys,tarfile
files=json.loads(base64.b64decode(PAYLOAD));data={}
for name,row in files.items():
 raw=base64.b64decode(row['data']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];data[name]=raw
 if name.endswith('.py'):ast.parse(raw,filename=name)
ns={};exec(compile(data['kernel9_common.py'],'kernel9_common.py','exec'),ns)
before=ns['idle'](0);root=ns['ROOT'];assert root.parent.resolve(strict=True)==root.parent
config=json.loads(data['config.json']);native,plan,built,final,proof=ns['kernel_inputs'](config)
assert hashlib.sha256(data['source.tar']).hexdigest()=='86c84337a6f4391a299eed49bbd64f92d1dc2dd63ce94b5b989b6dc71af66e13'
root.mkdir(mode=0o700);control=root/'control';control.mkdir(mode=0o700);(root/'input').mkdir(mode=0o700)
for name in ('source-sha256.json','source-state.json'):
 with (root/name).open('xb') as f:f.write(data[name]);f.flush();os.fsync(f.fileno())
for name in ('kernel9_common.py','build-private.py','config.json'):
 with (control/name).open('xb') as f:f.write(data[name]);f.flush();os.fsync(f.fileno())
 (control/name).chmod(0o444)
expected=json.loads(data['source-sha256.json']);seen=set();total=0
with tarfile.open(fileobj=io.BytesIO(data['source.tar']),mode='r:') as archive:
 for member in archive:
  name=member.name;rel=PurePosixPath(name)
  assert member.isfile() and not rel.is_absolute() and '..' not in rel.parts and name==str(rel) and name in expected and name not in seen
  raw=archive.extractfile(member).read();assert len(raw)==member.size==expected[name]['bytes'] and hashlib.sha256(raw).hexdigest()==expected[name]['sha256']
  path=root/'input'/name;path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  path.chmod(member.mode&0o777);seen.add(name);total+=len(raw)
assert seen==set(expected) and len(seen)==143 and total==1622641
ns['source_inputs']()
tools={}
names={'make':shutil.which('make'),'gcc':shutil.which('x86_64-linux-gnu-gcc'),
       'ld':shutil.which('ld'),'as':shutil.which('as'),'modinfo':shutil.which('modinfo'),
       'sign-file':str(ns['BUILD']/'scripts/sign-file'),
       'python':'/mnt/kdlock-builds/venvs/kdlock-translation-7.0-20261027/bin/python3'}
for name,value in names.items():
 path=Path(value);resolved=path.resolve(strict=True)
 tools[name]={'path':str(path),'resolved':str(resolved),'sha256':ns['sha'](resolved)}
assert tools['python']['resolved']=='/usr/bin/python3.14' and tools['python']['sha256']=='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
metadata={'status':'PRIVATE_RWSEM_SOURCE_STAGED','source_members':143,'source_bytes':total,
          'source_tar_sha256':files['source.tar']['sha256'],'source_manifest_sha256':files['source-sha256.json']['sha256'],
          'config_sha256':files['config.json']['sha256'],'helper_sha256':{n:files[n]['sha256'] for n in ('kernel9_common.py','build-private.py')},
          'tools':tools,'identity_before':before,'identity_after':ns['idle'](0),'boot_files':native['boot_files'](),
          'kernel_build_id':final['build_id'],'public_certificate_sha256':final['files']['certs/signing_key.x509']['sha256'],
          'build_or_module_load_performed':False}
ns['save'](root/'stage-metadata.json',metadata)
raw=(root/'stage-metadata.json').read_bytes();print(json.dumps({'metadata_sha256':hashlib.sha256(raw).hexdigest(),'metadata_base64':base64.b64encode(raw).decode()},sort_keys=True))
'''.replace('PAYLOAD', repr(encoded))
(OUT/'dispatch.py').write_text(source)
argv = ['ssh', '-T', '-p', '2222', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
        'root@10.176.26.71', 'python3', '-B', '-']
(OUT/'command.json').write_text(json.dumps({'argv': argv, 'stdin_sha256': hashlib.sha256(source.encode()).hexdigest()}, indent=2)+'\n')
with (OUT/'reply.json').open('xb') as stdout, (OUT/'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, start_new_session=True)
    child.stdin.write(source.encode()); child.stdin.close()
    try:
        code = child.wait(timeout=180)
    except subprocess.TimeoutExpired:
        code = None
print(json.dumps({'returncode': code, 'pid': child.pid}), flush=True)
if code != 0:
    print((OUT/'stderr.log').read_text()); raise SystemExit('Stage incomplete; retain existing state.')
value = json.loads((OUT/'reply.json').read_text())
raw = base64.b64decode(value['metadata_base64'])
assert hashlib.sha256(raw).hexdigest() == value['metadata_sha256']
(OUT/'stage-metadata.json').write_bytes(raw)
print(json.dumps({'status': json.loads(raw)['status'], 'metadata_sha256': value['metadata_sha256']}), flush=True)
